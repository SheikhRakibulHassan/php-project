<?php 
session_start();
if(!isset($_SESSION["sess_user_name"])){
	header("location:index.php");
} else {
?> 
<!DOCTYPE html>
<html>
<head>
<title>Blood Bank</title>
<link rel="icon" href="images/bicon.jpg" type="image/x-icon">
<link href="css/style.css" rel="stylesheet" type="text/css" />
</head>
<body>
<style>
body {
    background-color:#FCFCFC;
    margin: 4px 4px;
   
}
ul{
    list-style-type: none;
    margin: 0;
    padding: 3 15;
    overflow: hidden;
    background-color: #3F6699;
}

li {
    float: left;
	margin:10px 10px;
}

li a {
    display: block;
    color: white;
	margin:0px 30px;
    text-align: center;
    padding: 10px 20px;
    text-decoration: none;
}

li a:hover {
    background-color: #111;

}
.ta{
	
	float: left;
	margin:10px 1180px -340px 0px;
	text-align: left;
	padding:0px 10px;
	
}
.maindiv{
	
	float: left;
	margin:10px 500px;
	text-align: left;
	padding:10px 100px;
	background:#fff;
	
}


}
input[type=submit]{
    background-color: #4CAF50;
    border: none;
    color: white;
    padding: 8px 16px;
    text-decoration: none;
    margin: 4px 2px;
    cursor: pointer;
}
input[type=text],[type=submit]{
    width: 100%;
    height: 5%;
    border-color: red;
    box-sizing: border-box;
    border: 1px solid red;
    border-radius: 4px;
   background-color: white;
    color: green;
}
table, th, td {

    border: 2px #291F71;
    color: black;
text-decoration: none;
}

table th {
    background-color:#C82586;
    color: black;
}

table{
padding: 10px;
 background-color: #F7F7F8;
color:black;

}

.ta{
	
	float: left;
	margin:10px 1180px -430px 0px;
	text-align: left;
	padding:0px 10px;
	
}

.dropbtn {
    background-color:  #3F6699;
    color: white;
    padding: 10px;
    font-size: 15px;
    border: none;
    cursor: pointer;
}

.dropdown {
  
    display: inline-block;
	margin:10px 0px;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #3F6699;
    min-width: 100px;
}

.dropdown-content a {
    color: white;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
}

.dropdown-content a:hover {background-color: #f1f1f1}

.dropdown:hover .dropdown-content {
    display: block;
}
</style>

<center><img src="image/logo.png" border="" alt="Logo" style="width:800px;height:140px;"></center>

      <h1 style="color:black;text-align: center;">Automated Blood Bank System</h1></center>
    
         <center> 
       <ul>
	   <li><a  href="admin_logout.php">Logout</a></li>
		<li><a  href="view_donner.php">Donner List</a></li>
             <li><a  href="search_blood_group.php">Search A Donner</a></li>
			 <li><a  href="inser_user.php">Insrt User</a></li>
			 <li><a  href="updatephp.php">Manage User</a></li>

		 <div class="dropdown">
            <button class="dropbtn">Information</button>
             <div class="dropdown-content">
                    
                 <a href="admin_patient_view.php">Patient info</a>
                 <a href="transaction.php">Transection</a>
				 <a href="campiagn_view.php">Donate Info</a>
                 <a href="blood_bank.php">Blood Bank</a>
                 
                   </div> 
			</ul></div>
	


	<?php

/* 
        VIEW.PHP
        Displays all data from 'players' table
*/

        // connect to the database
       mysql_connect ("localhost", "root","")  or die (mysql_error());
mysql_select_db ("bbank");

        // get results from database
        $result = mysql_query("SELECT * FROM user_login") 
                or die(mysql_error());  
                
        // display data in table
		echo "<center>";
		echo "<br>";
		echo"<br>";
		echo"<br>";
		echo"<br>";
       echo "<h2><b>User Information</b></h2>";
        
        echo "<table border='1' cellpadding='10'>";
        echo "<tr> <th>ID</th><th>Username</th> <th>Password</th></tr>";

        // loop through results of database query, displaying them in the table
		 while($row = mysql_fetch_array( $result )) {
        
                
                // echo out the contents of each row into a table
                echo "<tr>";
                 echo '<td>' . $row['id'] . '</td>';
				echo '<td>' . $row['user_name'] . '</td>';
                echo '<td>' . $row['password'] . '</td>';
				
				
                
                
                
				//echo '<td><a href="edit_stu_info.php?id=' . $row['id'] . '">Edit</a></td>';
                echo "</tr>"; 
        
}
        // close table>
        echo "</table>";
	
?>
<div class="maindiv">
<div class="divA">

<h3>Update user</h3>
</div>
<div class="divB">

<p>Click On Menu</p>
<?php
$connection = mysql_connect("localhost", "root", "");
$db = mysql_select_db("bbank", $connection);
if (isset($_GET['submit'])) {
$id = $_GET['did'];
$uname = $_GET['dname'];
$pass = $_GET['demail'];

$query = mysql_query("update user_login set
user_name='$uname', password='$pass' where id='$id'", $connection);
}
$query = mysql_query("select * from user_login", $connection);
while ($row = mysql_fetch_array($query)) {
echo "<b><a href='updatephp.php?update={$row['id']}'>{$row['user_name']}</a></b>";
echo "<br />";
}
?>
</div><?php
if (isset($_GET['update'])) {
$update = $_GET['update'];
$query1 = mysql_query("select * from user_login where id=$update", $connection);
while ($row1 = mysql_fetch_array($query1)) {
echo "<form class='form' method='get'>";
echo "<h2>Update Form</h2>";

echo"<input class='input' type='hidden' name='did' value='{$row1['id']}' />";
echo "<label>" . "Username:" . "</label>" . "<br />";
echo"<input class='input' type='text' name='dname' value='{$row1['user_name']}' />";
echo "<br>";
echo "<br>";
echo "<label>" . "Password:" . "</label>" . "<br >";
echo"<input class='input' type='text' name='demail' value='{$row1['password']}' />";
echo "<br />";
echo "<br>";
echo "<input class='submit' type='submit' name='submit' value='update' />";
echo "</form>";
}
}
if (isset($_GET['submit'])) {
echo '<div class="form" id="form3"><br><br><br><br><br><br>
<Span>Data Updated Successfuly......!!</span></div>';
}
?>
<div class="clear"></div>
</div>
<div class="clear"></div>
</div>
</div><?php
mysql_close($connection);
?>







<div class="maindiv">
<div class="divA">
<div class="title">
<h3>Delete User</h2>
</div>
<div class="divB">
<div class="divD">
<p>Click On Menu</p>
<?php
$connection = mysql_connect("localhost", "root", ""); // Eastablishing Connection With Server.
$db = mysql_select_db("bbank", $connection); // Selecting Database From Server.
if (isset($_GET['del'])) {
$del = $_GET['del'];
//SQL query for deletion.
$query1 = mysql_query("delete from user_login where id=$del", $connection);
}
$query = mysql_query("select * from user_login", $connection); // SQL query to fetch data to display in menu.
while ($row = mysql_fetch_array($query)) {
echo "<b><a href=\"updatephp.php?id={$row['id']}\">{$row['user_name']}</a></b>";
echo "<br />";
}
?>
</div><?php
if (isset($_GET['id'])) {
$id = $_GET['id'];
// SQL query to Display Details.
$query1 = mysql_query("select * from user_login where id=$id", $connection);
while ($row1 = mysql_fetch_array($query1)) {
?>
<form class="form">
<h2>---Details---</h2>
<span>Name:</span> <?php echo $row1['user_name']."<br>"; ?>
<span>E-mail:</span> <?php echo $row1['password']."<br>"; ?>
<?php echo "<b><a href=\"updatephp.php?del={$row1['id']}\"><input type=\"button\" class=\"submit\" value=\"Delete\"/></a></b>"; ?>
</form><?php
}
}
// Closing Connection with Server.
mysql_close($connection);
?>

</body>
</html>
<?php
}
?>