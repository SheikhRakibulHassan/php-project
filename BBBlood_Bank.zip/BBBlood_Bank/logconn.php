<?php
if(isset($_POST["submit"])){

if(!empty($_POST['user_name']) && !empty($_POST['passward'])) {
	$user_name=$_POST['user_name'];
	$passward=$_POST['passward'];

	$con=mysql_connect('localhost','root','') or die(mysql_error());
	mysql_select_db('bbank') or die("cannot select DB");

	$query=mysql_query("SELECT * FROM admin_login WHERE user_name='".$user_name."' AND passward='".$passward."'");
	$numrows=mysql_num_rows($query);
	if($numrows!=0)
	{
	while($row=mysql_fetch_assoc($query))
	{
	$dbuser_name=$row['user_name'];
	$dbpassward=$row['passward'];
	}

	if($user_name == $dbuser_name && $passward == $dbpassward)
	{
	session_start();
	$_SESSION['sess_user_name']=$user_name;

	/* Redirect browser */
	header("Location: admin.php");
	}
	} else {
	echo "Invalid username or password!";
	}

} else {
	echo "All fields are required!";
}
}
?>