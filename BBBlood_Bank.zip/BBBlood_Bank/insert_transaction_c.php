<?php

$host="localhost"; // Host name 
$username="root"; // Mysql username 
$password=""; // Mysql password 
$db_name="bbank"; // Database name 
$tbl_name="transaction"; // Table name 

// Connect to server and select database.
mysql_connect("$host", "$username", "$password")or die("cannot connect"); 
mysql_select_db("$db_name")or die("cannot select DB");

// Get values from form 
$d=$_POST['did'];
$e=$_POST['name'];
$c=$_POST['a'];
$id=$_POST['b'];
$name=$_POST['o'];
$type=$_POST['ab'];
$bl=$_POST['aa'];
$am=$_POST['bb'];
$da=$_POST['oo'];
$ab=$_POST['abab'];
$te=$_POST['date'];
// Insert data into mysql 
$sql=mysql_query("INSERT INTO $tbl_name VALUES('$d','$e','$c','$id', '$name','$type','$bl', '$am','$da', '$ab','$te')");
//$result=mysql_query($sql);

// if successfully insert data into database, displays message "Successful".

if($sql){
echo "<li><h1>..Successful..</b><a href='insert_transaction_info.php'><br>Add Another</br></a></li>";
echo "<BR>";
echo "<a href='insert_transaction_info.php'></a>";
echo "<BR>";
}

else {
echo "ERROR";
}
?> 

<?php 
// close connection 
mysql_close();
?>
