 <!DOCTYPE>
<html>
<head>
<title>Blood Bank</title>
 <link rel="icon" href="image/bicon.jpg" type="image/x-icon">
<link href="css/style.css" rel="stylesheet" type="text/css" />
</head>
<body>
<style>
nav{

  background-color: #f2f2f2;
    margin:100px 300px;
}
input[type=submit]{
    background-color: #4CAF50;
    border: none;
    color: white;
    padding: 8px 16px;
    text-decoration: none;
    margin: 4px 2px;
    cursor: pointer;
}
input[type=text],[type=date],[type=option],[type=number],[type=email]{
    width: 50%;
    height: 5%;
    border-color: red;
    box-sizing: border-box;
    border: 1px solid red;
    border-radius: 4px;
   background-color: White;
    color: green;
}
.dropbtn {
    background-color:  #3F6699;
    color: white;
    padding: 10px;
    font-size: 15px;
    border: none;
    cursor: pointer;
}

.dropdown {
  
    display: inline-block;
	margin:10px;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color:#3F6699;
    min-width: 100px;
}

.dropdown-content a {
    color: white;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
}

.dropdown-content a:hover {background-color: #f1f1f1}

.dropdown:hover .dropdown-content {
    display: block;
}

</style>


<center><img src="image/logo.png" border="" alt="Logo" style="width:800px;height:140px;"></center>

      <h1 style="color:black;text-align: center;">Automated Blood Bank System</h1>
     <center> 
       <ul>
		<li><a  href="index.php">Home</a>
             <li><a  href="eligibilty.php">Blood Donation Description</a></li>
              <li><a  href="Donner_reg.php">Application for Donner</a>
           <li><a  href="about_us.php">About Us</a> </li>
			<li><a  href="contact.php">Contact Us</a> </li>
		 <div class="dropdown">
            <button class="dropbtn">Login</button>
             <div class="dropdown-content">
                    
                 <a href="u_cnn.php">User</a>
                 <a href="log.php">Admin</a>
                 
                   </div> 
				
			</ul>
         
      </ul></center>


	   



<center><nav><form id="form_444844" class="appnitro"  method="POST" action="donner_reg_c.php";>
				
<h3>Application for Blood Donner</h3>
<h3>Note: If your live in Dhaka or near Dhaka then only register</h3>
<h4>
Your Id:<br>
<input name="did" type="text" id="did">
<br>
<br>
Your Name:<br>
<input name="dn" type="text" id="dn">
<br>
<br>
Email Id:<br>
<input name="email" type="email" id="email">
<br>
<br>
Your Location:<br>
<input name="area" type="text" id="area">
<br>
<br>
Contact Number:<br>
<input name="cno" type="number" id="cno">
<br>
<br>
Blood group:<br>
<input name="bgrp" type="text" id="bgrp">
<br>
<br>
Blood Donation Date:<br>
<input name="date" type="date" id="date">
<br>
<br>
Sex:<br>
<input name="sex" type="text" id="sex">
<br>
</h4>
<input type="submit" name="Submit" value="Submit">

</form></nav></center>


</body>
</html>
