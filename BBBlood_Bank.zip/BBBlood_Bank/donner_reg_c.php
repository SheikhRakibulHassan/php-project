<?php

$host="localhost"; // Host name 
$username="root"; // Mysql username 
$password=""; // Mysql password 
$db_name="bbank"; // Database name 
$tbl_name="donner_reg"; // Table name 

// Connect to server and select database.
mysql_connect("$host", "$username", "$password")or die("cannot connect"); 
mysql_select_db("$db_name")or die("cannot select DB");

// Get values from form 
$aa=$_POST['did'];
$c=$_POST['dn'];

$name=$_POST['email'];
$bl=$_POST['area'];
$am=$_POST['cno'];
$da=$_POST['bgrp'];
$q=$_POST['date'];
$s=$_POST['sex'];
// Insert data into mysql 
$sql=mysql_query("INSERT INTO $tbl_name VALUES('$aa','$c', '$name','$bl', '$am','$da','$q', '$s')");
//$result=mysql_query($sql);

// if successfully insert data into database, displays message "Successful".

if($sql){
echo "<li><h1>..Successful..</b><a href='Donner_reg.php'><br>Add Another</br></a></li>";
echo "<BR>";
echo "<a href='Donner_reg.php'></a>";
echo "<BR>";
}

else {
echo "ERROR";
}
?> 

<?php 
// close connection 
mysql_close();
?>
