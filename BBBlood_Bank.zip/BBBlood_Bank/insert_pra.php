 <!DOCTYPE>
<html>
<head>
<title>Blood Bank</title>
 <link rel="icon" href="image/bicon.jpg" type="image/x-icon">
<link href="css/style.css" rel="stylesheet" type="text/css" />
</head>
<body>
<style>
nav{

  background-color: #f2f2f2;
    margin:100px 300px;
}
input[type=submit]{
    background-color: #4CAF50;
    border: none;
    color: white;
    padding: 8px 16px;
    text-decoration: none;
    margin: 4px 2px;
    cursor: pointer;
}
input[type=text],[type=date],[type=option],[type=number],[type=email],[type=age]{
    width: 50%;
    height: 5%;
    border-color: red;
    box-sizing: border-box;
    border: 1px solid red;
    border-radius: 4px;
   background-color: White;
    color: green;
}
.ta{
	
	float: left;
	margin:10px 1180px -430px 0px;
	text-align: left;
	padding:0px 10px;
	
}

.dropbtn {
    background-color:  #3F6699;
    color: white;
    padding: 10px;
    font-size: 15px;
    border: none;
    cursor: pointer;
}

.dropdown {
  
    display: inline-block;
	margin:10px 0px;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #3F6699;
    min-width: 100px;
}

.dropdown-content a {
    color: white;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
}

.dropdown-content a:hover {background-color: #f1f1f1}

.dropdown:hover .dropdown-content {
    display: block;
}
</style>


 <center><img src="image/logo.png" border="2" alt="Logo" style="width:800px;height:140px;"></center>

      <h1 style="color:black;text-align: center;">Automated Blood Bank System</h1></center>
    
         <center> 
       <ul>
	   <li><a  href="admin_logout.php">Logout</a></li>
		<li><a  href="view_donner.php">Donner List</a></li>
             <li><a  href="search_blood_group.php">Search A Donner</a></li>
			 <li><a  href="u_transaction_update.php">Transaction Update</a></li>
			 <li><ul>
         <div class="dropdown">
            <button class="dropbtn">Insert Donate info</button>
             <div class="dropdown-content">
                    <a href="insert_adonate.php">A+</a>
                 <a href="insert_bdonate.php">B+</a>
                 <a href="insert_odonate.php">O+</a>
				  <a href="insert_abdonate.php">AB+</a>
                 <a href="insert_aadonate.php">A-</a>
                 <a href="insert_bbdonate.php">B-</a>
				  <a href="insert_oodonate.php">O-</a>
                 <a href="insert_ababdonate.php">AB-</a>
                 
                   </div></ul></li>
		 <div class="dropdown">
            <button class="dropbtn">Information</button>
             <div class="dropdown-content">
                    
                 <a href="insert_transaction_info.php">Insert Transection info</a>
                 <a href="insert_pra.php">insert Patient info</a>
				 <a href="u_blood_bank.php">Blood Bank Info</a>
                 
                   </div> 
			</ul> 
         
      </ul></center>


	   



<center><nav><form id="form_444844" class="appnitro"  method="POST" action="insert_pra_c.php";>
				
<h3>Enter Patient info</h3>
<h4>
Patient Id:<br>
<input name="pid" type="number" id="pid">
<br>
<br>
Patient Name:<br>
<input name="p_name" type="text" id="p_name">
<br>
<br>
Room No:<br>
<input name="bed_no" type="text" id="bed_no">
<br>
<br>
Age:<br>
<input name="age" type="age" id="age">
<br>
<br>
Disease Name:<br>
<input name="disease" type="text" id="disease">
<br>
<br>
Reference Doctor:<br>
<input name="ref_doc" type="text" id="ref_doc">
<br>
</h4>
<input type="submit" name="Submit" value="Submit">

</form></nav></center>


</body>
</html>
