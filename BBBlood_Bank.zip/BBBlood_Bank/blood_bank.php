<?php 
session_start();
if(!isset($_SESSION["sess_user_name"])){
	header("location:index.php");
} else {
?> 
 <!DOCTYPE>
<html>
<head>
<title>Blood Bank</title>
<link rel="icon" href="images/bicon.jpg" type="image/x-icon">
<link href="css/style.css" rel="stylesheet" type="text/css" />
</head>
<body>
<style>
.ta{
	
	float: left;
	margin:10px 1180px -340px 0px;
	text-align: left;
	padding:0px 10px;
	
}

.ta{
	
	float: left;
	margin:10px 1180px -430px 0px;
	text-align: left;
	padding:0px 10px;
	
}

.dropbtn {
    background-color:  #3F6699;
    color: white;
    padding: 10px;
    font-size: 15px;
    border: none;
    cursor: pointer;
}

.dropdown {
  
    display: inline-block;
	margin:10px 0px;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #3F6699;
    min-width: 100px;
}

.dropdown-content a {
    color: white;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
}

.dropdown-content a:hover {background-color: #f1f1f1}

.dropdown:hover .dropdown-content {
    display: block;
}
</style>

<center><img src="image/logo.png" border="" alt="Logo" style="width:800px;height:140px;"></center>

      <h1 style="color:black;text-align: center;">Automated Blood Bank System</h1></center>
    
         <center> 
       <ul>
	   <li><a  href="admin_logout.php">Logout</a></li>
		<li><a  href="view_donner.php">Donner List</a></li>
             <li><a  href="search_blood_group.php">Search A Donner</a></li>
			 <li><a  href="inser_user.php">Insrt User</a></li>
			 <li><a  href="updatephp.php">Manage User</a></li>

		 <div class="dropdown">
            <button class="dropbtn">Information</button>
             <div class="dropdown-content">
                    
                 <a href="admin_patient_view.php">Patient info</a>
                 <a href="transaction.php">Transection</a>
				 <a href="campiagn_view.php">Donate Info</a>
                 <a href="blood_bank.php">Blood Bank</a>
                 
                   </div> 
			</ul></div>
<?php	
$a=0;	

//A+
	mysql_connect ("localhost", "root","")  or die (mysql_error());
mysql_select_db ("bbank");

        // get results from database
        $result = mysql_query("SELECT * FROM a_positive") 
                or die(mysql_error()); 
				
				 while($row = mysql_fetch_array( $result )) {
					 
					$a +=$row['amnt'];
				 
					 }

$b=0;	


	mysql_connect ("localhost", "root","")  or die (mysql_error());
mysql_select_db ("bbank");

        // get results from database
        $result = mysql_query("SELECT * FROM blood_bank") 
                or die(mysql_error()); 
				
				 while($row = mysql_fetch_array( $result )) {
					 
					$b +=$row['a_p'];
				 
					 }
					 $aa=0;	


	mysql_connect ("localhost", "root","")  or die (mysql_error());
mysql_select_db ("bbank");

        // get results from database
        $result = mysql_query("SELECT * FROM transaction") 
                or die(mysql_error()); 
				
				 while($row = mysql_fetch_array( $result )) {
					 
					$aa +=$row['a_p'];
				 
					 }
					 
					

//B+	
$c=0;	


	mysql_connect ("localhost", "root","")  or die (mysql_error());
mysql_select_db ("bbank");

        // get results from database
        $result = mysql_query("SELECT * FROM b_positive") 
                or die(mysql_error()); 
				
				 while($row = mysql_fetch_array( $result )) {
					 
					$c +=$row['amnt'];
				 
					 }
					 
$d=0;	


	mysql_connect ("localhost", "root","")  or die (mysql_error());
mysql_select_db ("bbank");

        // get results from database
        $result = mysql_query("SELECT * FROM blood_bank") 
                or die(mysql_error()); 
				
				 while($row = mysql_fetch_array( $result )) {
					 
					$d +=$row['b_p'];
				 
					 }
					 $bb=0;	


	mysql_connect ("localhost", "root","")  or die (mysql_error());
mysql_select_db ("bbank");

        // get results from database
        $result = mysql_query("SELECT * FROM transaction") 
                or die(mysql_error()); 
				
				 while($row = mysql_fetch_array( $result )) {
					 
					$aa +=$row['b_p'];
				 
					 }
		//O+			 
					 
					 $e=0;	


	mysql_connect ("localhost", "root","")  or die (mysql_error());
mysql_select_db ("bbank");

        // get results from database
        $result = mysql_query("SELECT * FROM o_positive") 
                or die(mysql_error()); 
				
				 while($row = mysql_fetch_array( $result )) {
					 
					$e +=$row['amnt'];
				 
					 }
$f=0;	


	mysql_connect ("localhost", "root","")  or die (mysql_error());
mysql_select_db ("bbank");

        // get results from database
        $result = mysql_query("SELECT * FROM blood_bank") 
                or die(mysql_error()); 
				
				 while($row = mysql_fetch_array( $result )) {
					 
					$f +=$row['o_p'];
				 
					 }
					 $cc=0;	


	mysql_connect ("localhost", "root","")  or die (mysql_error());
mysql_select_db ("bbank");

        // get results from database
        $result = mysql_query("SELECT * FROM transaction") 
                or die(mysql_error()); 
				
				 while($row = mysql_fetch_array( $result )) {
					 
					$aa +=$row['o_p'];
				 
					 }
					 
					 
					 //AB+
					 
$g=0;	


	mysql_connect ("localhost", "root","")  or die (mysql_error());
mysql_select_db ("bbank");

        // get results from database
        $result = mysql_query("SELECT * FROM ab_positive") 
                or die(mysql_error()); 
				
				 while($row = mysql_fetch_array( $result )) {
					 
					$g +=$row['amnt'];
				 
					 }
$h=0;	


	mysql_connect ("localhost", "root","")  or die (mysql_error());
mysql_select_db ("bbank");

        // get results from database
        $result = mysql_query("SELECT * FROM blood_bank") 
                or die(mysql_error()); 
				
				 while($row = mysql_fetch_array( $result )) {
					 
					$h +=$row['ab_p'];
				 
					 }	
					 $dd=0;	


	mysql_connect ("localhost", "root","")  or die (mysql_error());
mysql_select_db ("bbank");

        // get results from database
        $result = mysql_query("SELECT * FROM transaction") 
                or die(mysql_error()); 
				
				 while($row = mysql_fetch_array( $result )) {
					 
					$dd +=$row['ab_p'];
				 
					 }

//A-
$i=0;
	mysql_connect ("localhost", "root","")  or die (mysql_error());
mysql_select_db ("bbank");

        // get results from database
        $result = mysql_query("SELECT * FROM a_negetive") 
                or die(mysql_error()); 
				
				 while($row = mysql_fetch_array( $result )) {
					 
					$i +=$row['amnt'];
				 
					 }

$j=0;	


	mysql_connect ("localhost", "root","")  or die (mysql_error());
mysql_select_db ("bbank");

        // get results from database
        $result = mysql_query("SELECT * FROM blood_bank") 
                or die(mysql_error()); 
				
				 while($row = mysql_fetch_array( $result )) {
					 
					$j +=$row['a_n'];
				 
					 }
					 $ee=0;	


	mysql_connect ("localhost", "root","")  or die (mysql_error());
mysql_select_db ("bbank");

        // get results from database
        $result = mysql_query("SELECT * FROM transaction") 
                or die(mysql_error()); 
				
				 while($row = mysql_fetch_array( $result )) {
					 
					$ee +=$row['a_n'];
				 
					 }
					

//B-	
$k=0;	


	mysql_connect ("localhost", "root","")  or die (mysql_error());
mysql_select_db ("bbank");

        // get results from database
        $result = mysql_query("SELECT * FROM b_negetive") 
                or die(mysql_error()); 
				
				 while($row = mysql_fetch_array( $result )) {
					 
					$k +=$row['amnt'];
				 
					 }
$l=0;	


	mysql_connect ("localhost", "root","")  or die (mysql_error());
mysql_select_db ("bbank");

        // get results from database
        $result = mysql_query("SELECT * FROM blood_bank") 
                or die(mysql_error()); 
				
				 while($row = mysql_fetch_array( $result )) {
					 
					$l +=$row['b_n'];
				 
					 }
					 $ff=0;	


	mysql_connect ("localhost", "root","")  or die (mysql_error());
mysql_select_db ("bbank");

        // get results from database
        $result = mysql_query("SELECT * FROM transaction") 
                or die(mysql_error()); 
				
				 while($row = mysql_fetch_array( $result )) {
					 
					$ff +=$row['b_n'];
				 
					 }
		//O-		 
					 
					 $m=0;	


	mysql_connect ("localhost", "root","")  or die (mysql_error());
mysql_select_db ("bbank");

        // get results from database
        $result = mysql_query("SELECT * FROM o_negetive") 
                or die(mysql_error()); 
				
				 while($row = mysql_fetch_array( $result )) {
					 
					$m +=$row['amnt'];
				 
					 }
$n=0;	


	mysql_connect ("localhost", "root","")  or die (mysql_error());
mysql_select_db ("bbank");

        // get results from database
        $result = mysql_query("SELECT * FROM blood_bank") 
                or die(mysql_error()); 
				
				 while($row = mysql_fetch_array( $result )) {
					 
					$n +=$row['o_n'];
				 
					 }
					 $gg=0;	


	mysql_connect ("localhost", "root","")  or die (mysql_error());
mysql_select_db ("bbank");

        // get results from database
        $result = mysql_query("SELECT * FROM transaction") 
                or die(mysql_error()); 
				
				 while($row = mysql_fetch_array( $result )) {
					 
					$gg +=$row['o_n'];
				 
					 }
					 
					 
					 //AB-
					 
$o=0;	


	mysql_connect ("localhost", "root","")  or die (mysql_error());
mysql_select_db ("bbank");

        // get results from database
        $result = mysql_query("SELECT * FROM ab_negetive") 
                or die(mysql_error()); 
				
				 while($row = mysql_fetch_array( $result )) {
					 
					$o +=$row['amnt'];
				 
					 }
$p=0;	


	mysql_connect ("localhost", "root","")  or die (mysql_error());
mysql_select_db ("bbank");

        // get results from database
        $result = mysql_query("SELECT * FROM blood_bank") 
                or die(mysql_error()); 
				
				 while($row = mysql_fetch_array( $result )) {
					 
					$p +=$row['ab_n'];
				 
					 }
					 $hh=0;	


	mysql_connect ("localhost", "root","")  or die (mysql_error());
mysql_select_db ("bbank");

        // get results from database
        $result = mysql_query("SELECT * FROM transaction") 
                or die(mysql_error()); 
				
				 while($row = mysql_fetch_array( $result )) {
					 
					$aa +=$row['ab_n'];
				 
					 }
					 
					
             $q=$a+$b-$aa;
             $r=$c+$d-$bb;
			 $s=$e+$f-$cc;
			 $t=$g+$h-$dd;
			 $u=$i+$j-$ee;
			 $v=$k+$l-$ff;
			 $x=$m+$n-$gg;
			 $y=$o+$p-$hh;
              echo "<center>";
			   echo "<p><b>Showing Blood Amount</b></p>";
			  echo "<nav>";
        
        echo "<table border='1' cellpadding='10'>";
		  
        echo "<tr> <th>Blood Group</th> <th>Blood Amount(Bags)</th></tr>";
			 echo "<tr>";
                echo '<td>' ."A+" . '</td>';
				echo'<td>'.$q.'</td>';
				echo "</tr>";
				  echo"<tr>";
               echo '<td>' ."B+" . '</td>';
				   echo'<td>'.$r.'</td>';
				
                echo "</tr>"; 
				echo "<tr>";
                echo '<td>' ."O+" . '</td>';
				echo'<td>'.$s.'</td>';
				echo "</tr>";
				  echo"<tr>";
               echo '<td>' ."AB+" . '</td>';
				   echo'<td>'.$t.'</td>';
				
                echo "</tr>"; 
				echo "<tr>";
                echo '<td>' ."A-" . '</td>';
				echo'<td>'.$u.'</td>';
				echo "</tr>";
				  echo"<tr>";
               echo '<td>' ."B-" . '</td>';
				   echo'<td>'.$v.'</td>';
				
                echo "</tr>"; 
				echo "<tr>";
                echo '<td>' ."O-" . '</td>';
				echo'<td>'.$x.'</td>';
				echo "</tr>";
				  echo"<tr>";
               echo '<td>' ."AB-" . '</td>';
				   echo'<td>'.$y.'</td>';
				
                echo "</tr>"; 
        		 echo "</nav>";
        
        ?>
		
		

</body>
</html>
<?php
}
?>