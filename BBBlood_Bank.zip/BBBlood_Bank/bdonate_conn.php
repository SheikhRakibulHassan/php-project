<?php

$host="localhost"; // Host name 
$username="root"; // Mysql username 
$password=""; // Mysql password 
$db_name="bbank"; // Database name 
$tbl_name="b_positive"; // Table name 

// Connect to server and select database.
mysql_connect("$host", "$username", "$password")or die("cannot connect"); 
mysql_select_db("$db_name")or die("cannot select DB");

// Get values from form 
$c=$_POST['cam'];
$id=$_POST['Did'];
$type=$_POST['cn'];
$bl=$_POST['Blood_group'];
$am=$_POST['amount'];
$da=$_POST['Date'];
// Insert data into mysql 
$sql=mysql_query("INSERT INTO $tbl_name VALUES('$c','$id','$type','$bl', '$am','$da')");
//$result=mysql_query($sql);

// if successfully insert data into database, displays message "Successful".

if($sql){
echo "<li><h1>..Successful..</b><a href='insert_bdonate.php'><br>Add Another</br></a></li>";
echo "<BR>";
echo "<a href='insert_aadonate.php'></a>";
echo "<BR>";
}

else {
echo "ERROR";
}
?> 

<?php 
// close connection 
mysql_close();
?>
