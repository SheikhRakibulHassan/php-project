<?php 
session_start();
if(!isset($_SESSION["sess_user_name"])){
	header("location:index.php");
} else {
?> 
 <!DOCTYPE>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Blood Bank</title>
<link rel="icon" href="image/bicon.jpg" type="image/x-icon">
<link href="css/style.css" rel="stylesheet" type="text/css" />
</head>
<body>
<style>
.ta{
	
	float: left;
	margin:10px 1180px -340px 0px;
	text-align: left;
	padding:0px 10px;
	
}
nav{

  background-color: #f2f2f2;
    margin:100px 300px;
}
input[type=submit]{
    background-color: #4CAF50;
    border: none;
    color: white;
    padding: 8px 16px;
    text-decoration: none;
    margin: 4px 2px;
    cursor: pointer;
}
input[type=text],[type=date],[type=option] {
    width: 50%;
    height: 5%;
  
    box-sizing: border-box;
    border: none;
    background-color: #3CBC8D;
    color: white;
}
.dropbtn {
    background-color:  #3F6699;
    color: white;
    padding: 10px;
    font-size: 15px;
    border: none;
    cursor: pointer;
}

.dropdown {
  
    display: inline-block;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #3F6699;
    min-width: 160px;
}

.dropdown-content a {
    color: white;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
}

.dropdown-content a:hover {background-color: #f1f1f1}

.dropdown:hover .dropdown-content {
    display: block;
}



</style>


<center><img src="image/logo.png" border="" alt="Logo" style="width:800px;height:140px;"></center>

      <h1 style="color:black;text-align: center;">Automated Blood Bank System</h1></center>
    
         <center> 
       <ul>
	   <li><a  href="admin_logout.php">Logout</a></li>
		<li><a  href="view_donner.php">Donner List</a></li>
             <li><a  href="search_blood_group.php">Search A Donner</a></li>
			 <li><a  href="u_transaction_update.php">Transaction Update</a></li>
			 <li><ul>
         <div class="dropdown">
            <button class="dropbtn">Insert Donate info</button>
             <div class="dropdown-content">
                    <a href="insert_adonate.php">A+</a>
                 <a href="insert_bdonate.php">B+</a>
                 <a href="insert_odonate.php">O+</a>
				  <a href="insert_abdonate.php">AB+</a>
                 <a href="insert_aadonate.php">A-</a>
                 <a href="insert_bbdonate.php">B-</a>
				  <a href="insert_oodonate.php">O-</a>
                 <a href="insert_ababdonate.php">AB-</a>
                 
                   </div></ul></li>
		 <div class="dropdown">
            <button class="dropbtn">Information</button>
             <div class="dropdown-content">
                    
                 <a href="insert_transaction_info.php">Insert Transection info</a>
                 <a href="insert_pra.php">Insert Patient info</a>
				 <a href="u_blood_bank.php">Blood Bank Info</a>
                 
                   </div> 
			</ul> 
         
      </ul></div>


	   



<center><nav><form id="form_444844" class="appnitro"  method="POST" action="bbdonate_conn.php";>
				
<h3>Donate Info</h3>
<h3>B-</h3>
No:<br>
<input name="cam" type="text"  >
</br>

Donner name:<br>
<input name="Did" type="text" >
</br>

Contact Number:<br>
<input name="cn" type="text">
</br>

Blood group:<br>
<input name="Blood_group" type="text">
</br>

Quntity(Bags):<br>
<input name="amount" type="text">
</br>
Date:<br>
<input name="Date" type="text" >
</br>
<input type="submit" name="Submit" value="Submit">

</form></nav></center>


</body>
</html>
<?php
}
?>