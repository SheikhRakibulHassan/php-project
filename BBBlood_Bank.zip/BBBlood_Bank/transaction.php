<?php 
session_start();
if(!isset($_SESSION["sess_user_name"])){
	header("location:index.php");
} else {
?> 
 <!DOCTYPE>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Blood Bank</title>
<link rel="icon" href="images/bicon.jpg" type="image/x-icon">
<link href="css/style.css" rel="stylesheet" type="text/css" />
</head>
<body>
<style>
.ta{
	
	float: left;
	margin:10px 1180px -430px 0px;
	text-align: left;
	padding:0px 10px;
	
}

.ta{
	
	float: left;
	margin:10px 1180px -430px 0px;
	text-align: left;
	padding:0px 10px;
	
}

.dropbtn {
    background-color:  #3F6699;
    color: white;
    padding: 10px;
    font-size: 15px;
    border: none;
    cursor: pointer;
}

.dropdown {
  
    display: inline-block;
	margin:10px 0px;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #3F6699;
    min-width: 100px;
}

.dropdown-content a {
    color: white;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
}

.dropdown-content a:hover {background-color: #f1f1f1}

.dropdown:hover .dropdown-content {
    display: block;
}
</style>

<center><img src="image/logo.png" border="" alt="Logo" style="width:800px;height:140px;"></center>

      <h1 style="color:black;text-align: center;">Automated Blood Bank System</h1></center>
    
         <center> 
       <ul>
	   <li><a  href="admin_logout.php">Logout</a></li>
		<li><a  href="view_donner.php">Donner List</a></li>
             <li><a  href="search_blood_group.php">Search A Donner</a></li>
			 <li><a  href="inser_user.php">Insrt User</a></li>
			 <li><a  href="updatephp.php">Manage User</a></li>

		 <div class="dropdown">
            <button class="dropbtn">Information</button>
             <div class="dropdown-content">
                    
                 <a href="admin_patient_view.php">Patient info</a>
                 <a href="transaction.php">Transection</a>
				 <a href="campiagn_view.php">Donate Info</a>
                 <a href="blood_bank.php">Blood Bank</a>
                 
                   </div> 
			</ul></div>
	  
	  
	  <?php

/* 
        VIEW.PHP
        Displays all data from 'players' table
*/

        // connect to the database
       mysql_connect ("localhost", "root","")  or die (mysql_error());
mysql_select_db ("bbank");

        // get results from database
        $result = mysql_query("SELECT * FROM transaction") 
                or die(mysql_error());  
                
        // display data in table
		echo "<center>";
		echo "<br>";
		echo"<br>";
		echo"<br>";
		echo"<br>";
       echo "<p><b>Transaction Information</b></p>";
        
        echo "<table border='1' cellpadding='10'>";
        echo "<tr> <th>Patient ID</th><th>Patient Name</th><th>A+</th><th>B+</th><th>O+</th><th>AB+</th><th>A-</th><th>B-</th><th>O-</th><th>AB-</th><th>Date</th></tr>";

        // loop through results of database query, displaying them in the table
		 while($row = mysql_fetch_array( $result )) {
        
                
                // echo out the contents of each row into a table
                echo "<tr>";
				echo '<td>' . $row['pid'] . '</td>';
				 echo '<td>' . $row['p_name'] . '</td>';
				 echo '<td>' . $row['a_p'] . '</td>';
				 echo '<td>' . $row['b_p'] . '</td>';
				 echo '<td>' . $row['o_p'] . '</td>';
				 echo '<td>' . $row['ab_p'] . '</td>';
				 echo '<td>' . $row['a_n'] . '</td>';
				 echo '<td>' . $row['b_n'] . '</td>';
				  echo '<td>' . $row['o_n'] . '</td>';
				   echo '<td>' . $row['ab_n'] . '</td>';
				 echo '<td>' . $row['date'] . '</td>';
               
				
				
                
                
                
				//echo '<td><a href="edit_stu_info.php?id=' . $row['id'] . '">Edit</a></td>';
                echo "</tr>"; 
        
}
        // close table>
        echo "</table>";
	
?>



</body>
</html>
<?php
}
?>