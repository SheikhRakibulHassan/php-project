 <!DOCTYPE>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Blood Bank</title>
 <link rel="icon" href="images/bicon.jpg" type="image/x-icon">

<link href="css/style.css" rel="stylesheet" type="text/css" />
</head>
<body>
<style>

.dropbtn {
    background-color:  #3F6699;
    color: white;
    padding: 10px;
    font-size: 15px;
    border: none;
    cursor: pointer;
}

.dropdown {
  
    display: inline-block;
	margin:10px 0px;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #3F6699;
    min-width: 100px;
}

.dropdown-content a {
    color: white;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
}

.dropdown-content a:hover {background-color: #f1f1f1}

.dropdown:hover .dropdown-content {
    display: block;
}


</style>

<center><img src="image/logo.png" border="" alt="Logo" style="width:800px;height:140px;"></center>

      <h1 style="color:black;text-align: center;">Automated Blood Bank System</h1>
      <center> 
       <ul>
		<li><a  href="index.php">Home</a>
             <li><a  href="eligibilty.php">Blood Donation Description</a></li>
              <li><a  href="Donner_reg.php">Application for Donner</a>
           <li><a  href="about_us.php">About Us</a> </li>
			<li><a  href="contact.php">Contact Us</a> </li>
		 <div class="dropdown">
            <button class="dropbtn">Login</button>
             <div class="dropdown-content">
                    
                 <a href="u_cnn.php">User</a>
                 <a href="log.php">Admin</a>
                 
                   </div> 
				
			</ul>
         
      </ul></center>
	  
	  <h1>Blood Donation: Who Can Give Blood</h1>
	  <h3>You are not eligible to donate blood if you:</h3>

	  <a>1.You must be at least 17 years old to donate to the general blood supply.</a><br>
	  <a>2.Have ever used self-injected drugs (non-prescription)</a><br>
	  <a>3.Had hepatitis</a><br>
	   <a>4.Are in a high-risk group for AIDS</a><br>
	  <a>5.You must weigh at least 110 pounds to be eligible for blood donation for your own safety.</a><br>
	  <a>6.High Blood Pressure Acceptable as long as your blood pressure is below 180 systolic (first number) and below 100 diastolic (second number) at the time of donation.</a><br>
	   <br><center><div class="contentsection templete"> 
      <img src="image/aaaa.JPG" alt="" style="width:400px;height:300px"> 
      <img src="image/aaa.JPG" alt="" style="width:400px;height:300px">
      <img src="image/aa.JPG" alt="" style="width:400px;height:300px">
      </div></center>
	  </html>
