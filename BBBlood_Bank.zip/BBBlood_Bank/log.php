<!doctype html>
<html>
<title>Blood Bank</title>
<link rel="icon" href="images/bicon.jpg" type="image/x-icon">
<style>
body {
    background-color:#FCFCFC;
    margin: 4px 4px;
   
}
ul{
    list-style-type: none;
    margin: 0;
    padding: 3 15;
    overflow: hidden;
    background-color: #3F6699;
	
}

li {
    float: left;
	margin:10px 10px;
}

li a {
    display: block;
    color: white;
	margin:0px 30px;
    text-align: center;
    padding: 10px 20px;
    text-decoration: none;
}

li a:hover {
    background-color: #111;

}

nav {
    
    background-color: #f2f2f2;
    margin:100px 250px;
  
}




input[type=text], input[type=password] {
    width: 100%;
    padding: 12px 50px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    box-sizing: border-box;
}

input[type=submit]{
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    width: 10%;
}


.imgcontainer {
    text-align: center;
    margin: 24px 0 12px 0;
}

img.avatar {
    width: 20%;
    border-radius: 10%;
}
table ,tr, td{
    border: 2px solid #f2f2f2;
    color: black;
	margin: 0px 200px;
text-decoration: none;
}
.dropbtn {
    background-color:  #3F6699;
    color: white;
    padding: 10px;
    font-size: 15px;
    border: none;
    cursor: pointer;
}

.dropdown {
  
    display: inline-block;
	margin:10px 0px;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color:#3F6699;
    min-width: 80px;
}

.dropdown-content a {
    color: white;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
}

.dropdown-content a:hover {background-color: #FCFCFC}

.dropdown:hover .dropdown-content {
    display: block;
}


</style>

<center><img src="image/logo.png" border="" alt="Logo" style="width:800px;height:140px;"></center>

     <h1 style="color:black;text-align: center;">Automated Blood Bank System</h1>
     <center> 
       <ul>
		<li><a  href="index.php">Home</a>
             <li><a  href="eligibilty.php">Blood Donation Description</a></li>
              <li><a  href="Donner_reg.php">Application for Donner</a>
           <li><a  href="about_us.php">About Us</a> </li>
			<li><a  href="contact.php">Contact Us</a> </li>
		 <div class="dropdown">
            <button class="dropbtn">Login</button>
             <div class="dropdown-content">
                    
                 <a href="u_cnn.php">User</a>
                 <a href="log.php">Admin</a>
                 
                   </div> 
				
			</ul>
         
      </ul></center>

<nav><center><h2>Admin Login</h2></center>
<form action="logconn.php" method="post">
<nav class="imgcontainer">
    <img src="image/ffff.png" style="width:300px;height:200px;" alt="Avatar" class="avatar">
<table>

<body>
<tr>
<td ><b>username</b></td>
<td><b>:</b></td>
<td > <input name="user_name"type="text"></td>
</tr>
</body>
<body>
<tr>
<td ><b>password</b></td>
<td><b>:</b></td>
<td > <input name="passward"type="password"></td>
</tr>
</body>


</table>
<input type="submit"name="submit"value="login">

</center>
</html>