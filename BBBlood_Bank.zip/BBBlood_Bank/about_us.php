 <!DOCTYPE>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Blood Bank</title>
 <link rel="icon" href="images/bicon.jpg" type="image/x-icon">

<link href="css/style.css" rel="stylesheet" type="text/css" />
</head>
<body>
<style>

.dropbtn {
    background-color:  #3F6699;
    color: white;
    padding: 10px;
    font-size: 15px;
    border: none;
    cursor: pointer;
}

.dropdown {
  
    display: inline-block;
	margin:10px 0px;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #3F6699;
    min-width: 100px;
}

.dropdown-content a {
    color: white;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
}

.dropdown-content a:hover {background-color: #f1f1f1}

.dropdown:hover .dropdown-content {
    display: block;
}


</style>

<center><img src="image/logo.png" border="" alt="Logo" style="width:800px;height:140px;"></center>

      <h1 style="color:black;text-align: center;">Automated Blood Bank System</h1>
     <center> 
       <ul>
		<li><a  href="index.php">Home</a>
             <li><a  href="eligibilty.php">Blood Donation Description</a></li>
              <li><a  href="Donner_reg.php">Application for Donner</a>
           <li><a  href="about_us.php">About Us</a> </li>
			<li><a  href="contact.php">Contact Us</a> </li>
		 <div class="dropdown">
            <button class="dropbtn">Login</button>
             <div class="dropdown-content">
                    
                 <a href="u_cnn.php">User</a>
                 <a href="log.php">Admin</a>
                 
                   </div> 
				
			</ul>
         
      </ul></center>

	   
	
<center><h4>Ahsania Mission Cancer and General Hospital, Uttara, Dhaka</h4><br></center>
<a>Building on the ideas of the founder Sufi Saint Hazrat Khan Bahadur Ahsanullah (Rahmatullah Alaihee),
 Dhaka Ahsania Mission embarked on establishing a modern cancer hospital where world-class treatment will be available.
 Ahsania Mission Cancer and General Hospital is one of the major projects to fight cancer in Bangladesh. </a>

<center><br><body onload="startTime();">
<img id="img1" style="width:800px;height:400px"/>

<script >
var imgArray = new Array("image/ccc.jpg","image/cc.jpg","image/cccc.jpg","image/ccccc.jpg");
var imgCount = 0;
function startTime() {

    if(imgCount == imgArray.length) {
        imgCount = 0;
    }

    document.getElementById("img1").src = imgArray[imgCount];
    imgCount++;

    setTimeout("startTime()", 3000);
}
</script>
</body></center>
<p>
Dhaka Ahsania Mission as part of the total project took the initiative in 2001 to open a Cancer detection & Treatment Center at Mirpur, Dhaka.<br>
 In course of its progress it is now a 42 bed Cancer Hospital with required operation facilities, Chemotherapy, X-Ray and Imaging facilities.<br> A team of experienced and dedicated cancer specialists and general physicians are working there to provide health service at a reasonably low cost.<br> Here free services are offered to poor and ultra - poor patients.<br> Since 2001 the hospital has continued to provide health care services, especially to cancer patients.<br> 

Ultimately the dream materialized into reality and a plan was made to construct a 500 bed Cancer Hospital at a staggering cost of 4189.<br>14 million taka (US$ 53.70 million).<br> The fifteen story hospital designed by a US based architectural firm "Design Alliance of Bultimore", got started its construction with foundation laid by the then Prime Minister of Bangladesh on 10th July 2004 on a 3 acre land at the bank of the river Turag in Plot No.<br> 3, Embankment Driveway at Sector-10 of Uttara Model Town in the Capital.<br> The location is about 5 km from Zia International Airport.<br> The construction work of the hospital, having the design of a 15 storied building with 450,000 sft floor spaces, started in July 2005.<br> In the meantime the super-structure of this fifteen-storey hospital building (including 2 basements) has already been completed.<br> However, due to non-availability of adequate fund, the hospital could not be completed in a single phase and as such the hospital is now being made functional in three phases. 
</p>
</form></div></center>


</body>
</html>
