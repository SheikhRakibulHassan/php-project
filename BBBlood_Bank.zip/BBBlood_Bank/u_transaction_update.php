<?php 
session_start();
if(!isset($_SESSION["sess_user_name"])){
	header("location:index.php");
} else {
?>
 <!DOCTYPE>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Blood Bank</title>
<link rel="icon" href="images/bicon.jpg" type="image/x-icon">
<link href="css/style.css" rel="stylesheet" type="text/css" />
</head>
<body>
<style>
.ta{
	
	float: left;
	margin:10px 1180px -430px 0px;
	text-align: left;
	padding:0px 10px;
	
}

.dropbtn {
    background-color:  #333;
    color: white;
    padding: 10px;
    font-size: 15px;
    border: none;
    cursor: pointer;
}

.dropdown {
  
    display: inline-block;
	margin:10px 0px;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #333;
    min-width: 100px;
}

.dropdown-content a {
    color: white;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
}

.dropdown-content a:hover {background-color: #f1f1f1}

.dropdown:hover .dropdown-content {
    display: block;
}
.dropbtn {
    background-color:  #333;
    color: white;
    padding: 10px;
    font-size: 15px;
    border: none;
    cursor: pointer;
}

.dropdown {
  
    display: inline-block;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: red;
    min-width: 160px;
}

.dropdown-content a {
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
}

.dropdown-content a:hover {background-color: #f1f1f1}

.dropdown:hover .dropdown-content {
    display: block;
}
nav{
	
	float: left;
	margin:10px 1180px -340px 0px;
	text-align: left;
	padding:0px 10px;
	
}
.maindiv{
	
	float: left;
	margin:10px 500px;
	text-align: left;
	padding:10px 100px;
	background:#fff;
	
}
</style>

<center><img src="image/logo.png" border="" alt="Logo" style="width:800px;height:140px;"></center>

      <h1 style="color:black;text-align: center;">Automated Blood Bank System</h1></center>
    
         <center> 
       <ul>
	   <li><a  href="admin_logout.php">Logout</a></li>
		<li><a  href="view_donner.php">Donner List</a></li>
             <li><a  href="search_blood_group.php">Search A Donner</a></li>
			 <li><a  href="u_transaction_update.php">Transaction Update</a></li>
			 <li><ul>
         <div class="dropdown">
            <button class="dropbtn">Insert Donate info</button>
             <div class="dropdown-content">
                    <a href="insert_adonate.php">A+</a>
                 <a href="insert_bdonate.php">B+</a>
                 <a href="insert_odonate.php">O+</a>
				  <a href="insert_abdonate.php">AB+</a>
                 <a href="insert_aadonate.php">A-</a>
                 <a href="insert_bbdonate.php">B-</a>
				  <a href="insert_oodonate.php">O-</a>
                 <a href="insert_ababdonate.php">AB-</a>
                 
                   </div></ul></li>
		 <div class="dropdown">
            <button class="dropbtn">Information</button>
             <div class="dropdown-content">
                    
                 <a href="insert_transaction_info.php">Insert Transection info</a>
                 <a href="insert_pra.php">Insert Patient info</a>
				 <a href="u_blood_bank.php">Blood Bank Info</a>
                 
                   </div> 
			</ul> 
         
      </ul>


<div class="maindiv">
<div class="divA">

<h3>Update user</h3>
</div>
<div class="divB">

<p>Click On Menu</p>
<?php
$connection = mysql_connect("localhost", "root", "");
$db = mysql_select_db("bbank", $connection);
if (isset($_GET['submit'])) {
$id = $_GET['did'];
$pname = $_GET['dname'];
$a = $_GET['aa'];
$b = $_GET['bb'];
$c = $_GET['cc'];
$d = $_GET['dd'];
$e = $_GET['ee'];
$f = $_GET['ff'];
$g = $_GET['gg'];
$h = $_GET['hh'];
$i = $_GET['ii'];

$query = mysql_query("update transaction set
p_name='$pname', a_p='$a', a_n='$b', b_p='$c', b_n='$d', o_p='$e', o_n='$f', ab_p='$g', b_n='$h', date='$' where pid='$id'", $connection);
}
$query = mysql_query("select * from transaction", $connection);
while ($row = mysql_fetch_array($query)) {
echo "<b><a href='u_transaction_update.php?update={$row['pid']}'>{$row['pid']}</a></b>";
echo "<br />";
}
?>
</div><?php
if (isset($_GET['update'])) {
$update = $_GET['update'];
$query1 = mysql_query("select * from transaction where pid=$update", $connection);
while ($row1 = mysql_fetch_array($query1)) {
echo "<form class='form' method='get'>";
echo "<h2>Update Form</h2>";

echo"<input class='input' type='hidden' name='did' value='{$row1['pid']}' />";
echo "<label>" . "Patient Name:" . "</label>" . "<br />";
echo"<input class='input' type='text' name='dname' value='{$row1['p_name']}' />";
echo "<br>";
echo "<label>" . "A+:" . "</label>" . "<br />";
echo"<input class='input' type='text' name='aa' value='{$row1['a_p']}' />";
echo "<br>";
echo "<label>" . "A-:" . "</label>" . "<br />";
echo"<input class='input' type='text' name='bb' value='{$row1['a_n']}' />";
echo "<br>";
echo "<label>" . "B+:" . "</label>" . "<br />";
echo"<input class='input' type='text' name='cc' value='{$row1['b_p']}' />";
echo "<br>";
echo "<label>" . "B-:" . "</label>" . "<br />";
echo"<input class='input' type='text' name='dd' value='{$row1['b_n']}' />";
echo "<br>";
echo "<label>" . "O+:" . "</label>" . "<br />";
echo"<input class='input' type='text' name='ee' value='{$row1['o_p']}' />";
echo "<br>";
echo "<label>" . "O-:" . "</label>" . "<br />";
echo"<input class='input' type='text' name='ff' value='{$row1['o_n']}' />";
echo "<br>";
echo "<label>" . "AB+:" . "</label>" . "<br />";
echo"<input class='input' type='text' name='gg' value='{$row1['ab_p']}' />";
echo "<br>";
echo "<label>" . "AB-:" . "</label>" . "<br />";
echo"<input class='input' type='text' name='hh' value='{$row1['ab_n']}' />";
echo "<br>";
echo "<label>" . "Date:" . "</label>" . "<br >";
echo"<input class='input' type='text' name='ii' value='{$row1['date']}' />";
echo "<br />";
echo "<br>";
echo "<input class='submit' type='submit' name='submit' value='update' />";
echo "</form>";
}
}
if (isset($_GET['submit'])) {
echo '<div class="form" id="form3"><br><br><br><br><br><br>
<Span>Data Updated Successfuly......!!</span></div>';
}
?>
<div class="clear"></div>
</div>
<div class="clear"></div>
</div>
</div><?php
mysql_close($connection);
?>
</html>
<?php
}
?>