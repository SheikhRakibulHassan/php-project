<?php 
session_start();
unset($_SESSION['sess_user_name']);
session_destroy();
header("location:user_prof.php");
?>
