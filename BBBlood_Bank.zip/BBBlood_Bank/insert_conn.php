<?php

$host="localhost"; // Host name 
$username="root"; // Mysql username 
$password=""; // Mysql password 
$db_name="bbank"; // Database name 
$tbl_name="user_login"; // Table name 

// Connect to server and select database.
mysql_connect("$host", "$username", "$password")or die("cannot connect"); 
mysql_select_db("$db_name")or die("cannot select DB");

// Get values from form 

$id=$_POST['d'];
$name=$_POST['un'];
$type=$_POST['pass'];

// Insert data into mysql 
$sql=mysql_query("INSERT INTO $tbl_name VALUES('$id', '$name','$type')");
//$result=mysql_query($sql);

// if successfully insert data into database, displays message "Successful".

if($sql){
echo "<li><center><h1>...........Congratulation..........</b><a href='inser_user.php'><br>Add Another</br></a></center></li>";
echo "<BR>";
echo "<a href='inser_user.php'></a>";
echo "<BR>";


}

else {
echo "ERROR";
}
?> 

<?php 
// close connection 
mysql_close();
?>
