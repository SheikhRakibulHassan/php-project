 <!DOCTYPE>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Blood Bank</title>
 <link rel="icon" href="images/bicon.jpg" type="image/x-icon">
<link href="css/style.css" rel="stylesheet" type="text/css" />
</head>
<body>
<style>

.dropbtn {
    background-color:  #3F6699;
    color: white;
    padding: 10px;
    font-size: 15px;
    border: none;
    cursor: pointer;
}

.dropdown {
  
    display: inline-block;
	margin:10px 0px;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #3F6699;
    min-width: 100px;
}

.dropdown-content a {
    color: white;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
}

.dropdown-content a:hover {background-color: #f1f1f1}

.dropdown:hover .dropdown-content {
    display: block;
}


</style>

<center><img src="image/logo.png" border="" alt="Logo" style="width:800px;height:140px;"></center>

       <h1 style="color:black;text-align: center;">Automated Blood Bank System</h1>
     <center> 
       <ul>
		<li><a  href="index.php">Home</a>
             <li><a  href="eligibilty.php">Blood Donation Description</a></li>
              <li><a  href="Donner_reg.php">Application for Donner</a>
           <li><a  href="about_us.php">About Us</a> </li>
			<li><a  href="contact.php">Contact Us</a> </li>
		 <div class="dropdown">
            <button class="dropbtn">Login</button>
             <div class="dropdown-content">
                    
                 <a href="u_cnn.php">User</a>
                 <a href="log.php">Admin</a>
                 
                   </div> 
				
			</ul>
         
      </ul></center>

	   
	
	

<center><img src="image/sd.jpg"alt="Hospital"  border="" style="width:1350px;height:450px;"></center>

</form></div></center>


</body>
</html>
