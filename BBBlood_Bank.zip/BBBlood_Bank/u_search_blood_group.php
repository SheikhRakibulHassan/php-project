<?php 
session_start();
if(!isset($_SESSION["sess_user_name"])){
	header("location:index.php");
} else {
?> 
<!DOCTYPE>
<html>
<head>
<link href="css/style.css" rel="stylesheet" type="text/css" />
<title>Blood Bank</title>
  <link rel="icon" href="images/bicon.jpg" type="image/x-icon">

</head>
<body>
<style>
.ta{
	
	float: left;
	margin:10px 1180px -340px 0px;
	text-align: left;
	padding:0px 10px;
	
}
.dropbtn {
    background-color:  #333;
    color: white;
    padding: 10px;
    font-size: 15px;
    border: none;
    cursor: pointer;
}

.dropdown {
  
    display: inline-block;
	margin:10px 0px;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: red;
    min-width: 160px;
}

.dropdown-content a {
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
}

.dropdown-content a:hover {background-color: #f1f1f1}

.dropdown:hover .dropdown-content {
    display: block;
}
nav{

  background-color: #f2f2f2;
     padding: 10px 10px;
    margin:100px 400px;
}
input[type=submit]{
     width: 20%;
    background-color: #4CAF50;
    border: none;
    color: white;
    padding: 8px 16px;
    text-decoration: none;
    margin: 4px 2px;
    cursor: pointer;
}
input[type=option],[type=text]{
    width: 60%;
    height: 4%;
    border-color: red;
    box-sizing: border-box;
    border: 1px solid red;
    border-radius: 4px;
   background-color: White;
    color: green;
}


</style>

<center><img src="image/b.jpg" border="" alt="Logo" style="width:150px;height:140px;"></center>

      <h1 style="color:black;text-align: center;">Ahsania Mission Blood Bank</h1></center>
    
       <ul id="a" >
		<li><a  href="index.php">Home</a>
             <li><a  href="u_view_donner.php">Donner List</a>
              <li><a  href="donner_reg.php">Be A Donner</a>
             <li><a  href="u_search_blood_group.php">Search A Donner</a>
               <li><a  href="u_logout.php">Logout</a> 
                 
         
      </ul>
	 <div class="ta"><ul id="b">
              <li><a  href="insert_transaction_info.php">Insert Transection info</a>
			   <li><a  href="u_transaction_update.php">Transaction Update</a>
             <li><a  href="patient_view.php">Patient info</a>
			 <li><a  href="u_blood_bank.php">Blood Bank Info</a>
                <li>
			  <div class="dropdown">
            <button class="dropbtn">Insert Donate info</button>
             <div class="dropdown-content">
                    <a href="insert_adonate.php">A+</a>
                 <a href="insert_bdonate.php">B+</a>
                 <a href="insert_odonate.php">O+</a>
				  <a href="insert_abdonate.php">AB+</a>
                 <a href="insert_aadonate.php">A-</a>
                 <a href="insert_bbdonate.php">B-</a>
				  <a href="insert_oodonate.php">O-</a>
                 <a href="insert_ababdonate.php">AB-</a>
                 
                   </div> 
				
			</ul>
         
      </ul></div>
	  <br>
	<br>
<nav>
     <center><h3>Search By Blood Group</h3></center>
    <form action="u_search_blood_group_c.php" method="post">
	   <center> Blood Gruop: <input type="text" name="term" /><br /> </center>
<br>
	 
    <center><input type="submit" name="submit" /></center>
    </form>
 </nav>
 <nav id="01">
     <center><h3>Search By Area</h3></center>
    <form action="u_search_area_c.php" method="post">
    <center> Area: <input type="text" name="term" /><br /> </center>
	 
    <center><input type="submit" name="submit" /></center>
    </form>
 </nav>
 
</html>
<?php
}
?>