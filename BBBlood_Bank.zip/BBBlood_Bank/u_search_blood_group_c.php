 <?php 
session_start();
if(!isset($_SESSION["sess_user_name"])){
	header("location:index.php");
} else {
?> 
 <!DOCTYPE>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Blood Bank</title>
<link rel="icon" href="images/bicon.jpg" type="image/x-icon">
<link href="css/style.css" rel="stylesheet" type="text/css" />
</head>
<body>
<style>
.ta{
	
	float: left;
	margin:10px 1180px -340px 0px;
	text-align: left;
	padding:0px 10px;
	
}
.dropbtn {
    background-color:  #333;
    color: white;
    padding: 10px;
    font-size: 15px;
    border: none;
    cursor: pointer;
}

.dropdown {
  
    display: inline-block;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: red;
    min-width: 160px;
}

.dropdown-content a {
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
}

.dropdown-content a:hover {background-color: #f1f1f1}

.dropdown:hover .dropdown-content {
    display: block;
}


table ,td {
    background-color: white;
	margin:2px 400px;
    color: black;
	
}

table ,th {
    background-color: blue;
	margin:2px 400px;
    color: white;
	
}
table{
 width: 50%;
 table-layout: fixed;
 border-color:#000000;
padding: 1px 5px;
 background-color: #f1f1c1;
color: white;
margin:10px 100px;

}



</style>

<center><img src="image/b.jpg" border="" alt="Logo" style="width:150px;height:140px;"></center>

      <h1 style="color:black;text-align: center;">Ahsania Mission Blood Bank</h1></center>
    
       <ul id="a" >
		<li><a  href="index.php">Home</a>
             <li><a  href="u_view_donner.php">Donner List</a>
              <li><a  href="donner_reg.php">Be A Donner</a>
             <li><a  href="u_search_blood_group.php">Search A Donner</a>
               <li><a  href="u_logout.php">Logout</a> 
                 
         
      </ul>
	<div class="ta"><ul id="b">
              <li><a  href="insert_transaction_info.php">Insert Transection info</a>
			   <li><a  href="u_transaction_update.php">Transaction Update</a>
             <li><a  href="patient_view.php">Patient info</a>
			 <li><a  href="u_blood_bank.php">Blood Bank Info</a>
                <li>
			  <div class="dropdown">
            <button class="dropbtn">Insert Donate info</button>
             <div class="dropdown-content">
                    <a href="insert_adonate.php">A+</a>
                 <a href="insert_bdonate.php">B+</a>
                 <a href="insert_odonate.php">O+</a>
				  <a href="insert_abdonate.php">AB+</a>
                 <a href="insert_aadonate.php">A-</a>
                 <a href="insert_bbdonate.php">B-</a>
				  <a href="insert_oodonate.php">O-</a>
                 <a href="insert_ababdonate.php">AB-</a>
                 
                   </div> 
				
			</ul>
         
      </ul></div>
<?php
mysql_connect ("localhost", "root","")  or die (mysql_error());
mysql_select_db ("bbank");
 
$term = $_POST['term'];

 
$sql = mysql_query("select * from donner_reg where b_group like '%$term%'");
echo "<center>";
   echo "<table border='5' border-color='white' cellpadding='10'>";
echo"<tr><th>Donner Name</th><th>Area</th><th>Contact Number</th><th>Blood Group</th><th>Sex</th><th>Last Date of Donate</th></tr>";
echo"</center>";
 
while ($row = mysql_fetch_array($sql)){

   // echo 'ID: '.$row['ID'];
   // echo '<br/> ID: '.$row['id'];
   echo"<center>";
   echo "<table border='5' border-color='white' cellpadding='10'>";
   echo "<tr>";
  echo '<td>'.$row['d_name'] . '</td>';
 
 echo '<td>'. $row['area'].'</td>';
 echo'<td>'. $row['c_number'].'</td>';
 echo'<td>'. $row['b_group'].'</td>';
 echo'<td>'. $row['sex']. '</td>';
echo'<td>'. $row['l_date'].'</td>';

  echo "<tr>";
  echo"</table>";
	
}

 
?>
	</body>
	</html>
<?php
}
?>
