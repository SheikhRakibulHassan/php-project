<?php 
session_start();
if(!isset($_SESSION["sess_user_name"])){
	header("location:index.php");
} else {
?>
 <!DOCTYPE>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Blood Bank</title>
<link rel="icon" href="images/bicon.jpg" type="image/x-icon">
<link href="css/style.css" rel="stylesheet" type="text/css" />
</head>
<body>
<style>
.ta{
	
	float: left;
	margin:10px 1180px -340px 0px;
	text-align: left;
	padding:0px 10px;
	
}
.maindiv{
	
	float: left;
	margin:10px 500px;
	text-align: left;
	padding:10px 100px;
	background:#fff;
	
}
</style>

<center><img src="image/b.jpg" border="" alt="Logo" style="width:150px;height:140px;"></center>

            <h1 style="color:black;text-align: center;">Ahsania Mission Blood Bank</h1></center>
    
       <ul id="a" >
		<li><a  href="index.php">Home</a>
             <li><a  href="view_donner.php">Donner List</a>
              <li><a  href="donner_reg.php">Be A Donner</a>
             <li><a  href="search_blood_group.php">Search A Donner</a>
               <li><a  href="admin_logout.php">Logout</a> 
                 
         
      </ul>
	 <div class="ta"><ul id="b">
	 <li><a  href="update_admin_prof.php">Update profile</a>
	 <li><a  href="inser_user.php">Insrt User</a>
		<li><a  href="updatephp.php">Manage User</a>
		 <li><a  href="admin_patient_view.php">Patient info</a>
              <li><a  href="transaction.php">Transection </a>
              <li><a  href="campiagn_view.php">Donate Info</a>  
                <li><a  href="blood_bank.php">Blood Bank</a> 
         
      </ul></div>

<div class="maindiv">
<div class="divA">

<h3>Update user</h3>
</div>
<div class="divB">

<p>Click On Menu</p>
<?php
$connection = mysql_connect("localhost", "root", "");
$db = mysql_select_db("bbank", $connection);
if (isset($_GET['submit'])) {
$id = $_GET['did'];
$uname = $_GET['dname'];
$pass = $_GET['demail'];

$query = mysql_query("update admin_login set
user_name='$uname', passward='$pass' where id='$id'", $connection);
}
$query = mysql_query("select * from admin_login", $connection);
while ($row = mysql_fetch_array($query)) {
echo "<b><a href='update_admin_prof.php?update={$row['id']}'>{$row['user_name']}</a></b>";
echo "<br />";
}
?>
</div><?php
if (isset($_GET['update'])) {
$update = $_GET['update'];
$query1 = mysql_query("select * from admin_login where id=$update", $connection);
while ($row1 = mysql_fetch_array($query1)) {
echo "<form class='form' method='get'>";
echo "<h2>Update Form</h2>";

echo"<input class='input' type='hidden' name='did' value='{$row1['id']}' />";
echo "<label>" . "Username:" . "</label>" . "<br />";
echo"<input class='input' type='text' name='dname' value='{$row1['user_name']}' />";
echo "<br>";
echo "<br>";
echo "<label>" . "Password:" . "</label>" . "<br >";
echo"<input class='input' type='text' name='demail' value='{$row1['passward']}' />";
echo "<br />";
echo "<br>";
echo "<input class='submit' type='submit' name='submit' value='update' />";
echo "</form>";
}
}
if (isset($_GET['submit'])) {
echo '<div class="form" id="form3"><br><br><br><br><br><br>
<Span>Data Updated Successfuly......!!</span></div>';
}
?>
<div class="clear"></div>
</div>
<div class="clear"></div>
</div>
</div><?php
mysql_close($connection);
?>
</html>
<?php
}
?>