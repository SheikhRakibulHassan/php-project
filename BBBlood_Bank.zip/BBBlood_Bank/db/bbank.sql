-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Sep 03, 2018 at 02:07 PM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 5.6.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bbank`
--

-- --------------------------------------------------------

--
-- Table structure for table `ab_negetive`
--

CREATE TABLE `ab_negetive` (
  `cid` int(100) NOT NULL,
  `dname` varchar(100) NOT NULL,
  `c_number` int(100) NOT NULL,
  `b_grp` varchar(100) NOT NULL,
  `amnt` int(100) NOT NULL,
  `date` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ab_negetive`
--

INSERT INTO `ab_negetive` (`cid`, `dname`, `c_number`, `b_grp`, `amnt`, `date`) VALUES
(1, 'Fahad', 2147483647, 'AB-', 2, '2016-4-4'),
(2, 'Isteak', 167452839, 'AB-', 1, '2016-5-7');

-- --------------------------------------------------------

--
-- Table structure for table `ab_positive`
--

CREATE TABLE `ab_positive` (
  `cid` int(100) NOT NULL,
  `dname` varchar(100) NOT NULL,
  `c_number` int(100) NOT NULL,
  `b_grp` varchar(100) NOT NULL,
  `amnt` int(100) NOT NULL,
  `date` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ab_positive`
--

INSERT INTO `ab_positive` (`cid`, `dname`, `c_number`, `b_grp`, `amnt`, `date`) VALUES
(1, 'Max', 16784539, 'AB+', 2, '2016-4-4'),
(2, 'Jony', 1678444454, 'AB+', 3, '2016-5-7');

-- --------------------------------------------------------

--
-- Table structure for table `admin_login`
--

CREATE TABLE `admin_login` (
  `id` int(100) NOT NULL,
  `user_name` varchar(10) NOT NULL,
  `passward` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_login`
--

INSERT INTO `admin_login` (`id`, `user_name`, `passward`) VALUES
(1, 'rakib', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `a_negetive`
--

CREATE TABLE `a_negetive` (
  `cid` int(100) NOT NULL,
  `dname` varchar(100) NOT NULL,
  `c_number` int(100) NOT NULL,
  `b_grp` varchar(100) NOT NULL,
  `amnt` int(100) NOT NULL,
  `date` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `a_negetive`
--

INSERT INTO `a_negetive` (`cid`, `dname`, `c_number`, `b_grp`, `amnt`, `date`) VALUES
(1, 'Tony', 2147483647, 'A-', 1, '2016-12-14'),
(2, 'Kony', 191256568, 'A-', 2, '2016-4-4');

-- --------------------------------------------------------

--
-- Table structure for table `a_positive`
--

CREATE TABLE `a_positive` (
  `cid` int(200) NOT NULL,
  `dname` varchar(100) NOT NULL,
  `c_number` int(100) NOT NULL,
  `b_grp` varchar(100) NOT NULL,
  `amnt` int(100) NOT NULL,
  `date` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `a_positive`
--

INSERT INTO `a_positive` (`cid`, `dname`, `c_number`, `b_grp`, `amnt`, `date`) VALUES
(1, 'Lew', 193457756, 'A+', 1, '2016-12-14'),
(2, 'Kew', 1678444454, 'A+', 2, '2016-12-07');

-- --------------------------------------------------------

--
-- Table structure for table `blood_bank`
--

CREATE TABLE `blood_bank` (
  `iid` int(20) NOT NULL,
  `a_p` int(10) NOT NULL,
  `a_n` int(50) NOT NULL,
  `b_p` int(50) NOT NULL,
  `b_n` int(50) NOT NULL,
  `o_n` int(50) NOT NULL,
  `o_p` int(100) NOT NULL,
  `ab_p` int(100) NOT NULL,
  `ab_n` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `b_negetive`
--

CREATE TABLE `b_negetive` (
  `cid` int(100) NOT NULL,
  `dname` varchar(100) NOT NULL,
  `c_number` int(100) NOT NULL,
  `b_grp` varchar(100) NOT NULL,
  `amnt` int(100) NOT NULL,
  `date` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `b_negetive`
--

INSERT INTO `b_negetive` (`cid`, `dname`, `c_number`, `b_grp`, `amnt`, `date`) VALUES
(1, 'Jothi', 1568789776, 'B-', 1, '2016-4-4'),
(2, 'Bithi', 1673534634, 'B-', 2, '2016-5-7');

-- --------------------------------------------------------

--
-- Table structure for table `b_positive`
--

CREATE TABLE `b_positive` (
  `cid` int(100) NOT NULL,
  `dname` varchar(100) NOT NULL,
  `c_number` int(100) NOT NULL,
  `b_grp` varchar(100) NOT NULL,
  `amnt` int(100) NOT NULL,
  `date` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `b_positive`
--

INSERT INTO `b_positive` (`cid`, `dname`, `c_number`, `b_grp`, `amnt`, `date`) VALUES
(1, 'Jojo', 1766534654, 'B+', 1, '2016-4-4'),
(2, 'Mojo', 156878767, 'B+', 2, '2016-5-6');

-- --------------------------------------------------------

--
-- Table structure for table `donner_reg`
--

CREATE TABLE `donner_reg` (
  `id` int(250) NOT NULL,
  `d_name` varchar(50) NOT NULL,
  `d_email` varchar(50) NOT NULL,
  `area` varchar(50) NOT NULL,
  `c_number` int(50) NOT NULL,
  `b_group` varchar(50) NOT NULL,
  `l_date` varchar(100) NOT NULL,
  `sex` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `donner_reg`
--

INSERT INTO `donner_reg` (`id`, `d_name`, `d_email`, `area`, `c_number`, `b_group`, `l_date`, `sex`) VALUES
(1, 'Emo', 'Emo@gmail.com', 'Uttara', 1568789776, 'AB+', '2016-3-4', 'Female'),
(2, 'Mon', 'mon@gmail.com', 'Dhanmondi', 1673534634, 'O+', '2016-6-5', 'Female'),
(12, 'dsf', 'dsd@aa', 'dsd', 323, 'dd', '2017-11-16', 'dasds'),
(32, 'fsdf', 'sfsd', 'sdf', 22, 'fc', 'fsf', 'fsf'),
(434, 'fsdf', 'fsdf@fsdfs', 'sfs', 3434, 'vdsv', '2017-11-16', 'df'),
(435, 'ffff', 'fggd@ffd', 'ff', 0, 'cdv', '2017-11-23', 'sfsf'),
(456, 'fdfg', 'gdgd@fdf', 'dfgd', 332, 'csxc', '2017-11-23', 'fsfs'),
(1111, 'Rakib', '34444ffg@ssd', 'dfdsf', 11111, 'r', '2017-02-18', 'fsfdf'),
(3234, 'fsfs', 'ffff@sfsf', 'sfsdf', 4242, '0', '2017-12-25', 'dffd'),
(7665, 'hihijsd', 'djsjs@jshj', 'hbsjbcjh', 7667, 'o', '2017-02-19', 'usdush'),
(7777, 'vvvbv ', 'hvb vbn', 'ghvghvh', 0, '0', '', 'jhjhb'),
(23423, 'ccs', 'scsd@fff', 'dd', 32, 'sf', '2017-11-08', 'dddd'),
(76786, 'fygyg', 'bvb@bb', ' bbnb ', 44545, 'nmbm', '2017-12-18', 'ugyug'),
(345345, 'vvvbv ', 'hvb vbn', 'ghvghvh', 54545646, '0', '', 'jhjhb');

-- --------------------------------------------------------

--
-- Table structure for table `o_negetive`
--

CREATE TABLE `o_negetive` (
  `cid` int(100) NOT NULL,
  `dname` varchar(100) NOT NULL,
  `c_number` int(100) NOT NULL,
  `b_grp` varchar(100) NOT NULL,
  `amnt` int(100) NOT NULL,
  `date` varchar(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `o_negetive`
--

INSERT INTO `o_negetive` (`cid`, `dname`, `c_number`, `b_grp`, `amnt`, `date`) VALUES
(1, 'Jojo', 2147483647, 'O-', 1, '2016-4-5'),
(2, 'Mojo', 1673534634, 'O-', 2, '2016-5-9');

-- --------------------------------------------------------

--
-- Table structure for table `o_positive`
--

CREATE TABLE `o_positive` (
  `cid` int(100) NOT NULL,
  `dname` varchar(100) NOT NULL,
  `c_number` int(100) NOT NULL,
  `b_grp` varchar(100) NOT NULL,
  `amnt` int(100) NOT NULL,
  `date` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `o_positive`
--

INSERT INTO `o_positive` (`cid`, `dname`, `c_number`, `b_grp`, `amnt`, `date`) VALUES
(1, 'Rotna', 2147483647, 'O+', 1, '2016-12-14'),
(2, 'Padma', 176989399, 'O+', 2, '2016-12-12'),
(4545, 'njnj', 878, 'n n', 4, '3466');

-- --------------------------------------------------------

--
-- Table structure for table `patient`
--

CREATE TABLE `patient` (
  `pid` int(250) NOT NULL,
  `p_name` varchar(50) NOT NULL,
  `bed_no` int(200) NOT NULL,
  `age` int(50) NOT NULL,
  `disease` varchar(50) NOT NULL,
  `ref_doc` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `patient`
--

INSERT INTO `patient` (`pid`, `p_name`, `bed_no`, `age`, `disease`, `ref_doc`) VALUES
(1, 'asif', 502, 23, 'cancer', 'shakil'),
(2, 'Tajnin', 23, 45, 'Typhoid', 'Dr.Shah'),
(3, 'Emo', 34, 34, 'Appandicites', 'Dr.Rahman'),
(3432, 'fsfs', 44, 0, 'dsd', 'dsd');

-- --------------------------------------------------------

--
-- Table structure for table `transaction`
--

CREATE TABLE `transaction` (
  `pid` int(250) NOT NULL,
  `p_name` varchar(100) NOT NULL,
  `a_p` int(100) NOT NULL,
  `a_n` int(100) NOT NULL,
  `b_p` int(100) NOT NULL,
  `b_n` int(100) NOT NULL,
  `o_p` int(100) NOT NULL,
  `o_n` int(100) NOT NULL,
  `ab_p` int(100) NOT NULL,
  `ab_n` int(100) NOT NULL,
  `date` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transaction`
--

INSERT INTO `transaction` (`pid`, `p_name`, `a_p`, `a_n`, `b_p`, `b_n`, `o_p`, `o_n`, `ab_p`, `ab_n`, `date`) VALUES
(1, 'asif', 1, 0, 0, 0, 0, 0, 0, 0, '2016-3-8'),
(2, 'Tajnin', 0, 0, 0, 1, 0, 0, 0, 0, '2016-3-5'),
(1111, 'ttt', 3, 0, 0, 0, 0, 0, 0, 0, '244');

-- --------------------------------------------------------

--
-- Table structure for table `user_login`
--

CREATE TABLE `user_login` (
  `id` int(11) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `password` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_login`
--

INSERT INTO `user_login` (`id`, `user_name`, `password`) VALUES
(1, 'mim', 12345);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ab_negetive`
--
ALTER TABLE `ab_negetive`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `ab_positive`
--
ALTER TABLE `ab_positive`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `admin_login`
--
ALTER TABLE `admin_login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `a_negetive`
--
ALTER TABLE `a_negetive`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `a_positive`
--
ALTER TABLE `a_positive`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `blood_bank`
--
ALTER TABLE `blood_bank`
  ADD UNIQUE KEY `iid` (`iid`);

--
-- Indexes for table `b_negetive`
--
ALTER TABLE `b_negetive`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `b_positive`
--
ALTER TABLE `b_positive`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `donner_reg`
--
ALTER TABLE `donner_reg`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `o_negetive`
--
ALTER TABLE `o_negetive`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `o_positive`
--
ALTER TABLE `o_positive`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `patient`
--
ALTER TABLE `patient`
  ADD PRIMARY KEY (`pid`);

--
-- Indexes for table `transaction`
--
ALTER TABLE `transaction`
  ADD PRIMARY KEY (`pid`);

--
-- Indexes for table `user_login`
--
ALTER TABLE `user_login`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `blood_bank`
--
ALTER TABLE `blood_bank`
  MODIFY `iid` int(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `donner_reg`
--
ALTER TABLE `donner_reg`
  MODIFY `id` int(250) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=345346;
--
-- AUTO_INCREMENT for table `patient`
--
ALTER TABLE `patient`
  MODIFY `pid` int(250) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3433;
--
-- AUTO_INCREMENT for table `user_login`
--
ALTER TABLE `user_login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
