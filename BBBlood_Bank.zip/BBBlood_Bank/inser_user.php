<?php 
session_start();
if(!isset($_SESSION["sess_user_name"])){
	header("location:index.php");
} else {
?> 
 <!DOCTYPE>
<html>
<head>
<title>Blood Bank</title>
 <link rel="icon" href="images/bicon.jpg" type="image/x-icon">
<link href="css/style.css" rel="stylesheet" type="text/css" />
</head>
<body>
<style>
#c{

  background-color: #f2f2f2;
    margin:100px 300px;
}
input[type=submit]{
    background-color: #4CAF50;
    border: none;
    color: white;
    padding: 8px 16px;
    text-decoration: none;
    margin: 4px 2px;
    cursor: pointer;
}
input[type=text],[type=date],[type=option]{
    width: 50%;
    height: 5%;
    border-color: red;
    box-sizing: border-box;
    border: 1px solid red;
    border-radius: 4px;
   background-color: White;
    color: green;
}
.ta{
	
	float: left;
	margin:10px 1180px -340px 0px;
	text-align: left;
	padding:0px 10px;
	
}

.ta{
	
	float: left;
	margin:10px 1180px -430px 0px;
	text-align: left;
	padding:0px 10px;
	
}

.dropbtn {
    background-color:  #3F6699;
    color: white;
    padding: 10px;
    font-size: 15px;
    border: none;
    cursor: pointer;
}

.dropdown {
  
    display: inline-block;
	margin:10px 0px;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #3F6699;
    min-width: 100px;
}

.dropdown-content a {
    color: white;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
}

.dropdown-content a:hover {background-color: #f1f1f1}

.dropdown:hover .dropdown-content {
    display: block;
}
</style>

<center><img src="image/logo.png" border="" alt="Logo" style="width:800px;height:140px;"></center>

      <h1 style="color:black;text-align: center;">Automated Blood Bank System</h1></center>
    
         <center> 
       <ul>
	   <li><a  href="admin_logout.php">Logout</a></li>
		<li><a  href="view_donner.php">Donner List</a></li>
             <li><a  href="search_blood_group.php">Search A Donner</a></li>
			 <li><a  href="inser_user.php">Insrt User</a></li>
			 <li><a  href="updatephp.php">Manage User</a></li>

		 <div class="dropdown">
            <button class="dropbtn">Information</button>
             <div class="dropdown-content">
                    
                 <a href="admin_patient_view.php">Patient info</a>
                 <a href="transaction.php">Transection</a>
				 <a href="campiagn_view.php">Donate Info</a>
                 <a href="blood_bank.php">Blood Bank</a>
                 
                   </div> 
			</ul></div>




<center><div id="c"><form id="form_444844" class="appnitro"  method="POST" action="insert_conn.php";>
				
<h3>Be A Donner</h3>
<h4>
Id:<br>
<input name="d" type="text" id="d">
<br>
User Name:<br>
<input name="un" type="text" id="un">
<br>
Paswword:<br>
<input name="pass" type="text" id="pass">
<br>

</h4>
<input type="submit" name="Submit" value="Submit">

</form></div></center>




</body>
</html>
<?php
}
?>