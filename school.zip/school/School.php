<!Doctype html>
<html>
<head>
<title>Automatic Result System</title>
<link rel="stylesheet" href="School.css">

</head>
<body>
<div class="navsection templete"><ul>
  <li><a href="Home.php">Home</a></li>
   <li><a href="About.php">About Us</a></li>
   <li><a href="Contact.php">Contact</a></li>
     <li><a href="Home.php">Log Out</a></li>
  </ul>
  </div>
  <div>

<div class="panel-heading"><h2> Main Module </h2>
</div>

<div class="bb">
<center style="margin-left:5px">
	
 <a href="Registry.php" type="button" class="" style="color:white;background-color:#269abc;bolder-color:#1b6d85;padding:9px 46px;">Registry</a><br>
 <a href="Teacher.php" type="button" class="" style="color:white;background-color:#269abc;bolder-color:#1b6d85;padding:9px 46px;">Teacher</a>
 <br>
 
 <a href="Student.php" type="button" class="" style="color:white;background-color:#269abc;bolder-color:#1b6d85;padding:9px 46px;">Student</a>


</div>
</div>









<body>