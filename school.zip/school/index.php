<!Doctype html>
<html>
<head>
<title>Automatic Result System</title>
<link rel="stylesheet" href="Login.css">
</head>
<body>

<div class="navsection templete"><ul>
  <li><a href="Home.php">Home</a></li>
  <li><a href="About.php">About Us</a></li>
  <li><a href="Publish_Result.php">Result</a></li> 
   
  </ul>
  </div>
  <div class="form-control">
<form action="logincon2.php" method="post">


                         <center>
						 <h2 style="padding:0px;margin-left:0px;font-size:25px;font-family:arial;"> Login For Admin</h2>
						 <hr width="30%" size="3" >
						<br>
						<br>
						<input type="text" name="name" id="name" class="form-control" placeholder="Enter User Name" />

                    <br>
					<br>
                     <input type="password" name="password" id="password" class="form-control" placeholder="password" />

                    <br>
					<br>
					

                 <input type="submit" value="Login" />            
                 <br>
				 <br>
                  </center>

                    

                        
                   
                </form>
				</div>
				</body>