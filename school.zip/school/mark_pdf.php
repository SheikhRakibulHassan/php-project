<?php
require_once('functions/dbconfig.php');
	require_once('functions/functions.php');
			
		$obj = new cls_func();
		require('fpdf/fpdf.php');
		require('fpdf/rotation.php');


class PDF extends PDF_Rotate
{
function Header()
{
	//Put the watermark
	//$this->SetFont('Arial','B',50);
	//$this->SetTextColor(255,192,203);
	//$this->RotatedText(65,190,'A p p r o v e d',45);
}
function RotatedText($x, $y, $txt, $angle)
{
	//Text rotated around its origin
	$this->Rotate($angle,$x,$y);
	$this->Text($x,$y,$txt);
	$this->Rotate(0);
}
}

//$pdf = new FPDF();
$pdf=new PDF();
$pdf->AddPage();



$iubat='EVERGREEN HIGH SCHOOL' ;				

		
		
	    $pdf-> Cell(65);
        $pdf->SetFont('Times','',10);
        $pdf->Write(5, 'Founded 2002 by Nur Alam');
		$pdf->Ln();
		$pdf-> Cell(55);
		$pdf->SetFont('Times','',15);
		$pdf->Write(5, $iubat);
		$pdf->Ln();
		$pdf-> Cell(50);
		$pdf->SetFont('Times','',8);
		$pdf->Write(4, '    road no-15,house-03, Sector 12, Uttara Model Town, Dhaka 1230, Bangladesh');
		$pdf->Ln();
		$pdf-> Cell(30);
		$pdf->SetFont('Times','',8);
		$pdf->Write(4,'Phone: 01752063078, 01737298985, 2520582-70, Fax: 782 2622,');
		$pdf-> Cell(20);
		$pdf->SetFont('Times','',8);
		$pdf->Write(5, '___________________________________________________________________________________________________________________________________');
		$pdf->Ln();
		$pdf->Ln();
		
		$pdf-> Cell(80);
		$pdf->SetFont('Times','U',10);
		$pdf->Write(5, 'Publish Result');
		$pdf->Ln();

		$pdf->Ln(2);			


$pdf-> Cell(11);
		$pdf->SetFont('Times','B',8);
		$pdf->Cell(6,6,'SL',1);
		$pdf->Cell(20,6,'Teacher Name',1);
		$pdf->Cell(8,6,'Class',1);
		$pdf->Cell(10,6,'Roll No',1);
		$pdf->Cell(20,6,'Student Name',1);
		$pdf->Cell(15,6,'Subject',1);
		$pdf->Cell(20,6,'1st Term',1);
		$pdf->Cell(20,6,'2nd Term',1);
		$pdf->Cell(15,6,'Final',1);
		$pdf->Cell(15,6,'Totall',1);
		$pdf->Cell(10,6,'Grade',1);
		$pdf->Cell(10,6,'Status',1);
		$pdf->Ln();

					$qry = $obj->view_st_info2();
					
 
					$sl=1;
					while($rec = $qry->fetch_assoc())
                     {
						$pdf-> Cell(11);
						$pdf->SetFont('Times','',8);
						$pdf->Cell(6,6,$sl,1);
						$pdf->Cell(20,6,$rec['tname'],1);
						$pdf->Cell(8,6,$rec['class'],1);
						$pdf->Cell(10,6,$rec['roll'],1);
						$pdf->Cell(20,6,$rec['sname'],1);
						$pdf->Cell(15,6,$rec['subject'],1);
						$pdf->Cell(20,6,$rec['1st'],1);
						$pdf->Cell(20,6,$rec['2nd'],1);
						$pdf->Cell(15,6,$rec['final'],1);
						$pdf->Cell(15,6,$rec['totall'],1);
						$pdf->Cell(10,6,$rec['grade'],1);
						$pdf->Cell(10,6,$rec['status'],1);
						

						$sl++;
						$pdf->Ln();
						}      
                

		
		$pdf->Ln();
		$pdf->Ln();	
		
		$pdf->Output();



?>