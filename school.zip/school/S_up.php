
<?php
require_once('functions/dbconfig.php');        
  require_once('functions/functions.php');                       
  $obj = new cls_func();
    
  $qry=$obj->edit_st_info($_GET['id']);
  $row=$qry->fetch_assoc();
  
  if (isset($_POST['submit']))
  {

    $Name= addslashes("$_POST[name]");
    $Roll = addslashes("$_POST[roll]");
    $Password= addslashes("$_POST[password]");
    $Class = addslashes("$_POST[class]");
    $Father = addslashes("$_POST[father]");
	$Mother= addslashes("$_POST[mother]");
    $Contact= addslashes("$_POST[contact]");
    $Address = addslashes("$_POST[address]");
    

    $qry = $obj->data_update($Name,$Roll,$Password,$Class,$Father,$Mother,$Contact,$Address);
      if ($qry){
        echo "Successfully Updated".'</br><a href = "S_update.php"><input type = "button" value = "View" ></a>';
          exit();
      }
      else{
        echo "not posted!";
        }
  }
?>


<!DOCTYPE html>
<html>

<body>



<?php
$qry1=$obj->edit_st_info($_GET['id']);
$rec=$qry1->fetch_assoc();

?>
<form enctype="multipart/form-data" method="post" class="form-horizontal">
 <center>
<h2>Student Update</h2>
<hr width="50%" size="3" />
  
<table style="width:30%" >

  <tr>
    <td>Student Name</td>
    <td><input id="name" name="name" type="text" value="<?php echo $rec['name']; ?>" </td>
  </tr>
  <tr>
    <td>Roll NO</td>
    <td><input id="roll" name="roll" type="text" value="<?php echo $rec['roll']; ?>"  readonly></td>
  </tr>
  <tr>
    <td>Password</td>
    <td><input id="password" name="password" value="<?php echo $rec['password']; ?>" type="text" ></td>
  </tr>
    <tr>
    <td>Class</td>
    <td><input id="class" name="class" value="<?php echo $rec['class']; ?>" type="text"></td>
  </tr>
  <tr>
    <td>Father Name</td>
    <td><input id="father" name="father" value="<?php echo $rec['father']; ?>" type="text"></td>
  </tr>
  <tr>
    <td>Mother Name</td>
    <td><input id="mother" name="mother" value="<?php echo $rec['mother']; ?>" type="text" ></td>
  </tr>
    <tr>
    <td>Contact Number</td>
    <td><input id="contact" name="contact" value="<?php echo $rec['contact']; ?>" type="text"></td>
  </tr>
  <tr>
    <td>Address</td>
    <td><input id="address" name="address" value="<?php echo $rec['address']; ?>" type="text"></td>
  </tr>
  <tr>
  <td></td>
  <td>
  <button id="submit" name="submit" class="btn btn-primary">Update</button>
  <a href = "S_update.php"><input type = "button" value = "Cancel" ></a>
  </td>
  </tr>
</table>
</center>
</form>


  





</body>
</html>

