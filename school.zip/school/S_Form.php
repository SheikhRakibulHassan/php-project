

        <div >
		<center>
            <h2>ADMISSION FORM OF STUDENT</h2>
			<hr width="50%" size="3" />
        </center>
		</div>

        <div  Style="margin:50;padding:10;outline:0;margin-top:5;margin-left:200;
   font-family:arial;font-size:17px;line-height:18px;color:#000;background-size:600px;">
           

                <form id="form_444844" class="appnitro" method="POST" action="insert_student.php";>
                  Name:<br>
				  <input type="text" name="name" id="name">
                   <br><br>
                   Roll No:<br>
                   <input type="text" maxlength="8" name="roll" id="roll">
				   <br><br>
				   Password:<br>
                   <input type="password" maxlength="8" name="password" id="password">
				   <br><br>
				   Class:<br>
                   <input type="text" name="class" id="class">
				   <br><br>
				   Father Name:<br>
                   <input type="text" name="father" id="father">
				   <br><br>
				   Mother Name:<br>
                   <input type="text" name="mother" id="mother">
				   <br><br>
				   Contact No:<br>
                   <input type="number" max="100000000000" name="contact" id="contact">
				   <br><br>
				   Address:<br>
                   <input type="address" name="address" id="address">
                   <br><br>
                     <input type="submit" name="Submit" value="Submit">
					</form>
					<center>
                    <a href="Registry.php"  style="color:white;background-color:#00bfff;bolder-color:#1b6d85;padding:9px 54px;font-size:15px;">Go To Back</a>
					</center>
                    
					

