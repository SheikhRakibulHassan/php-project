 <div >
		<center>
            <h2> FORM OF TEACHER</h2>
			<hr width="50%" size="3" />
        </center>
		</div>

        <div  Style="margin:50;padding:0;outline:10;margin-left:200;margin-top:2;
   font-family:arial;font-size:17px;line-height:18px;color:#000;background-size:900px;">
           

                <form id="form_444844" class="appnitro" method="POST" action="insert_mark.php";>
                  Teacher Name:<br>
				  <input type="text" name="tname" id="tname">
                   <br><br>
                   Class:<br>
                   <input type="text" name="class" id="class">
				   <br><br>
				   Roll:<br>
                   <input type="text" name="roll" id="roll">
				   <br><br>
				   Student Name:<br>
                   <input type="text" name="sname" id="sname">
				   <br><br>
				   Subject:<br>
                   <input type="text" name="subject" id="subject">
                   <br><br>
				   1st Term:<br>
                   <input type="text" name="1st" id="1st">
                   <br><br>
				    2nd Term:<br>
                   <input type="text" name="2nd" id="2nd">
                   <br><br>
				   Final:<br>
                   <input type="text" name="final" id="final">
                   <br><br>
                     <input type="submit" name="Submit"  value="Submit">
                    </form>
                    <a href="Teacher.php" style="color:white;background-color:#00bfff;bolder-color:#1b6d85;padding:9px 54px;font-size:15px;">Go To Back </a>
					
                    
					</div>
