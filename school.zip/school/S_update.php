<?php 
  
  require_once('functions/dbconfig.php');        
  require_once('functions/functions.php');           
  $obj = new cls_func();
    
  $qry=$obj->view_st_info();

  
  $i=0;
?>

<!DOCTYPE html>
<html>

<body >
<style>
.ta{
	
	float: left;
	margin:10px 1180px -430px 0px;
	text-align: left;
	padding:0px 30px;
	
}

table ,td {
    background-color: white;
	margin:2px 400px;
    color: black;
	
}

table ,th {
    background-color: blue;
	margin:2px 400px;
    color: white;
	
}
table{
 width: 90%;
 table-layout: fixed;
 border-color:#000000;
padding: 1px 5px;
 background-color: #f1f1c1;
color: white;
margin:2px 100px;

}



</style>




 
              
      
           

  <h1 style="padding:15px;margin-left:500px;font-size:25px;font-family:arial;">Student Information</h1>
  	<table>
  <tr>
    <th>Student Name</th>
    <th>Roll No</th> 
    <th>Password</th>
    <th>Class</th>
    <th>Father Name</th>
	<th>Mother Name</th>
	<th>Contact Number</th>
	<th>Address</th>
  </tr>
  <?php
  while($rec=$qry->fetch_assoc())							
						{
  ?>
  <tr>
    <td><?php echo $rec['name']; ?></td>
    <td><?php echo $rec['roll']; ?></td>
    <td><?php echo $rec['password']; ?></td>
    <td><?php echo $rec['class']; ?></td>
    <td><?php echo $rec['father']; ?></td>
	<td><?php echo $rec['mother']; ?></td>
    <td><?php echo $rec['contact']; ?></td>
    <td><?php echo $rec['address']; ?></td>


  </tr>
      <td><a href='S_up.php?id=<?php echo $rec['roll']?>'> Edit</a></td>
    <td><a href='S_delete.php?id=<?php echo $rec['roll']?>'> Delete</a></td>
<?php
$i++;
						}
?>
</table>
</br>


  <center><a href = "Registry.php"><input type = "button" value = "Back"></a></center>
 


</body>
</html>