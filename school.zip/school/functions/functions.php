<?php
class cls_func{
	
	public function con(){
		$connect = new dbconfig();
		return $connect->connection();
	}

	

//Admin Logout Session
		
	public function view_st_info(){
		$result = $this->con()->query("Select * from student");
		return $result;
	}
	public function view_st_info1(){
		$result = $this->con()->query("Select * from teacher");
		return $result;
	}
	
	public function view_st_info2(){
		$result = $this->con()->query("Select * from mark");
		return $result;
	}
	


	public function data_update($Name,$Roll,$Password,$Class,$Father,$Mother,$Contact,$Address){
		$result = $this->con()->query("UPDATE student set name='$Name', roll='$Roll', password='$Password',class='$Class', father='$Father',mother='$Mother',contact='$Contact',
		address='$Address' where roll='$Roll'");
		return $result;
	}

	public function data_update1($Name,$Id,$Password,$Contact,$Address){
		$result = $this->con()->query("UPDATE teacher set name='$Name', id='$Id',password='$Password', contact='$Contact', address='$Address' where id='$Id'");
		return $result;
	}
	public function data_update2($Teacher,$Class,$Roll,$Student,$Subject,$st,$nd,$Finals){
		$Totall=$st+$nd+$Finals;
        if($Totall>=80 && $Totall<100){
	      $Grade='A';
	      $Status='Very Good Result';
        }
        if($Totall>=70 && $Totall<80){
	      $Grade='B';
	      $Status='Good Result';
        }
        if($Totall>=60 && $Totall<70){
	      $Grade='C';
	      $Status='Poor Result';
        }
        if($Totall>=50 && $Totall<60){
	      $Grade='D';
	      $Status='Very Poor Result';
        }
        if($Totall>=0 && $Totall<50){
	      $Grade='F';
	      $Status='Very Bad Result';
        }
		$result = $this->con()->query("UPDATE mark set tname='$Teacher',class='$Class',roll='$Roll', sname='$Student', subject='$Subject',1st='$st',2nd='$nd',final='$Finals',totall='$Totall', grade='$Grade',status='$Status' where roll='$Roll'");
		return $result;
	}

    public function edit_st_info($Roll){
		$result = $this->con()->query("Select * from student where roll='$Roll'");
		return $result;
	}
	 public function edit_st_info1($id){
		$result = $this->con()->query("Select * from teacher where id='$id'");
		return $result;
	}
	public function edit_st_info2($Roll){
		$result = $this->con()->query("Select * from mark where roll='$Roll'");
		return $result;
	}


	public function delete_st_info($Roll){
		$result = $this->con()->query("delete from student where roll='$Roll'");
		return $result;
	}
    public function delete_st_info1($id){
		$result = $this->con()->query("delete from teacher where id='$id'");
		return $result;
	}
	public function delete_st_info2($Roll){
		$result = $this->con()->query("delete from mark where roll='$Roll'");
		return $result;
	}
}
	?>