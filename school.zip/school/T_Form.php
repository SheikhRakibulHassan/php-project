  <div >
		<center>
            <h2> FORM OF TEACHER</h2>
			<hr width="50%" size="3" />
        </center>
		</div>

        <div  Style="margin:50;padding:0;outline:10;margin-left:200;margin-top:2;
   font-family:arial;font-size:17px;line-height:18px;color:#000;background-size:900px;">
           

                <form id="form_444844" class="appnitro" method="POST" action="insert_teacher.php";>
                  Name:<br>
				  <input type="text" name="name" id="name">
                   <br><br>
                   Id No:<br>
                   <input type="text" maxlength="8" name="id" id="id">
				   <br><br>
				   Password:<br>
                   <input type="password" maxlength="8" name="password" id="password">
				   <br><br>
				   Contact:<br>
                   <input type="number" max="100000000000" name="contact" id="contact">
				   <br><br>
				   Address:<br>
                   <input type="Address" name="address" id="address">
				   
                   <br><br>
                     <input type="submit" name="Submit"  value="Submit">
					 </form>
					 <center>
					 <a href="Registry.php"  style="color:white;background-color:#00bfff;bolder-color:#1b6d85;padding:9px 54px;font-size:15px;">Go To Back</a>
                    </center>
					
                    
					</div>
