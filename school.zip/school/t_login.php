<?php

if(!empty($_POST['name']) && !empty($_POST['password'])) {
	$user_name=$_POST['name'];
	$passward=$_POST['password'];

	$con=mysql_connect('localhost','root','') or die(mysql_error());
	mysql_select_db('school') or die("cannot select DB");

	$query=mysql_query("SELECT * FROM teacher WHERE name='".$user_name."' AND password='".$passward."'");
	$numrows=mysql_num_rows($query);
	if($numrows!=0)
	{
	while($row=mysql_fetch_assoc($query))
	{
	$dbuser_name=$row['name'];
	$dbpassward=$row['password'];
	}

	if($user_name == $dbuser_name && $passward == $dbpassward)
	{
	
	/* Redirect browser */
	header("Location: Teacher.php");
	}
	} else {
	echo "Invalid username or password!";
	}

} else {
	echo "All fields are required!";
}

?>