<!Doctype html>
<html>
<div >
		<center>
              <div >
		<center>
            <h1> View Teacher's Profile</h1>
			<hr width="50%" size="3" />
        </center>
		</div>
		<div>
		<form action="T_search.php" method="post">
		Teacher's id:
		<input type="text" placeholder="Search...."maxlength="20" name="id" id="id"Style="padding:1%;">
		<input type="submit" value="Go!" style="padding:1%;background:green;color:white;">
		
		</Form>
		<a href="Teacher.php"  style="color:white;background-color:#00bfff;bolder-color:#1b6d85;margin-left:450px;position:fixed;top:600px;padding:9px 54px;font-size:15px;">Go To Back</a>
		</div>
		</html>