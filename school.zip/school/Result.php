<!Doctype html>
<html>
<div >
		<center>
              <div >
		<center>
            <h1> View Student's Results</h2>
			<hr width="50%" size="3" />
        </center>
		</div>
		<div>
		<form action="M_view.php" method="post">
		Student's id:
		<input type="text" placeholder="Search...."maxlength="20" name="roll" id="roll"Style="padding:.5%;">
		<input type="submit" value="Go!" style="padding:.5%;background:green;color:white;">
		
		</Form>
		<a href="Student.php"  style="color:white;background-color:#00bfff;bolder-color:#1b6d85;margin-left:450px;position:fixed;top:600px;padding:9px 54px;font-size:15px;">Go To Back</a>
		</div>
		</html>