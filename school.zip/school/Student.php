<!Doctype html>
<html>
<head>
<title>Automatic Result System</title>
<link rel="stylesheet" href="School.css">
</head>
<body>
<div class="navsection templete"><ul>
  <li><a href="Home.php">Home</a></li>
   <li><a href="About.php">About Us</a></li>

     <li><a href="Home.php">Log Out</a></li>
  </ul>
  </div>
 <center> <h2 style="padding:15px;font-size:25px;font-family:arial;">Field of Student<h2></center>
  <hr width="30%" size="3" /><div>
 <br>
<center style="margin-left:20px">


 <a href="S_View.php" type="button" class="btn btn-info active" style="color:white;background-color:#269abc;bolder-color:#1b6d85;padding:9px 46px;font-size:15px;">View Profile</a>
 <br>
 <a href="Result.php" type="button" class="btn btn-info active" style="color:white;background-color:#269abc;bolder-color:#1b6d85;padding:9px 46px;font-size:15px;">See Result</a>

</div>
</body>