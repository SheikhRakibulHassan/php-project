<!Doctype html>
<html>
<head>
<title>Automatic Result System</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<div class="headersection templete">
<h2><div id="logo"> <img src="pic.png" alt="" />EVERGREEN HIGH SCHOOL</h2>
</div>
</div>
<div class="navsection templete" ><ul  list-style-type: none;
    margin: 0;
    overflow: hidden;>
  <li><a href="Home.php"style="color:white">Home</a></li>
   <li><a href="About.php"style="color:white">About Us</a></li>
   <li><a href="Publish_Result.php"style="color:white">Result</a></li>  
  
   <div class="dropdown">
            <button class="dropbtn"style="color:white">Login</button>
             <div class="dropdown-content">
			 
                  <a href="Login.php"style="color:white">Registry</a>  
                 <a href="TLogin.php"style="color:white">Teacher</a>
                 <a href="SLogin.php"style="color:white">Student</a>
				 
                   </div>
  </ul>
  </div> 
</div>
<div>

</body>
</html>