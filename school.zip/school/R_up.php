
<?php
require_once('functions/dbconfig.php');        
  require_once('functions/functions.php');                       
  $obj = new cls_func();
    
  $qry=$obj->edit_st_info2($_GET['id']);
  $row=$qry->fetch_assoc();
  
  if (isset($_POST['submit']))
  {

    $Teacher= addslashes("$_POST[tname]");
    $Class = addslashes("$_POST[class]");
    $Roll= addslashes("$_POST[roll]");
    $Student = addslashes("$_POST[sname]");
    $Subject = addslashes("$_POST[subject]");
	$ta="1st";
	$fa="2nd";
	$st= addslashes("$_POST[$ta]");
    $nd= addslashes("$_POST[$fa]");
    $Finals = addslashes("$_POST[final]");
    $qry = $obj->data_update2($Teacher,$Class,$Roll,$Student,$Subject,$st,$nd,$Finals);
      if ($qry){
        echo "Successfully Updated".'</br><a href = "Resul_update.php"><input type = "button" value = "View" ></a>';
          exit();
      }
      else{
        echo "not posted!";
        }
  }
?>


<!DOCTYPE html>
<html>

<body>



<?php
$qry1=$obj->edit_st_info2($_GET['id']);
$rec=$qry1->fetch_assoc();

?>
<form enctype="multipart/form-data" method="post" class="form-horizontal">
 <center>
<h2>Student Update</h2>
<hr width="50%" size="3" />
  
<table style="width:30%" >

  <tr>
    <td>Teacher Name</td>
    <td><input id="tname" name="tname" type="text" value="<?php echo $rec['tname']; ?>" ></td>
  </tr>
  <tr>
    <td>Class</td>
    <td><input id="class" name="class" type="text" value="<?php echo $rec['class']; ?>"  ></td>
  </tr>
  <tr>
    <td>Roll NO</td>
    <td><input id="roll" name="roll" value="<?php echo $rec['roll']; ?>" type="text" readonly></td>
  </tr>
    <tr>
    <td>Student Name</td>
    <td><input id="sname" name="sname" value="<?php echo $rec['sname']; ?>" type="text"></td>
  </tr>
  <tr>
    <td>Subject</td>
    <td><input id="subject" name="subject" value="<?php echo $rec['subject']; ?>" type="text"></td>
  </tr>
  <tr>
    <td>1st Term</td>
    <td><input id="1st" name="1st" value="<?php echo $rec['1st']; ?>" type="text" ></td>
  </tr>
    <tr>
    <td>2nd Term</td>
    <td><input id="2nd" name="2nd" value="<?php echo $rec['2nd']; ?>" type="text"></td>
  </tr>
  <tr>
    <td>Final</td>
    <td><input id="final" name="final" value="<?php echo $rec['final']; ?>" type="text"></td>
  </tr>
  <tr>
  <td></td>
  <td>
  <button id="submit" name="submit" class="btn btn-primary">Update</button>
  <a href = "Resul_update.php"><input type = "button" value = "Cancel" ></a>
  </td>
  </tr>
</table
</center>
</form>

