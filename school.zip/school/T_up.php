
<?php
require_once('functions/dbconfig.php');        
  require_once('functions/functions.php');                       
  $obj = new cls_func();
    
  $qry=$obj->edit_st_info1($_GET['id']);
  $row=$qry->fetch_assoc();
  
  if (isset($_POST['submit']))
  {

    $Name= addslashes("$_POST[name]");
    $Id = addslashes("$_POST[id]");
    $Password= addslashes("$_POST[password]");
    $Contact = addslashes("$_POST[contact]");
    $Address = addslashes("$_POST[address]");
    

    $qry = $obj->data_update1($Name,$Id,$Password,$Contact,$Address);
      if ($qry){
        echo "Successfully Updated".'</br><a href = "T_update.php"><input type = "button" value = "View" ></a>';
          exit();
      }
      else{
        echo "not posted!";
        }
  }
?>


<!DOCTYPE html>
<html>

<body>



<?php
$qry1=$obj->edit_st_info1($_GET['id']);
$rec=$qry1->fetch_assoc();

?>
<form enctype="multipart/form-data" method="post" class="form-horizontal">
 <center>
<h2>Teacher Update</h2>
<hr width="50%" size="3" />
  
<table style="width:30%" >

  <tr>
    <td>Teacher Name</td>
    <td><input id="name" name="name" type="text" value="<?php echo $rec['name']; ?>" </td>
  </tr>
  <tr>
    <td>Id</td>
    <td><input id="id" name="id" type="text" value="<?php echo $rec['id']; ?>"  readonly></td>
  </tr>
  <tr>
    <td>Password</td>
    <td><input id="password" name="password" value="<?php echo $rec['password']; ?>" type="text" ></td>
  </tr>
    <tr>
    <td>Contact Number</td>
    <td><input id="contact" name="contact" value="<?php echo $rec['contact']; ?>" type="text"></td>
  </tr>
  <tr>
    <td>Address</td>
    <td><input id="address" name="address" value="<?php echo $rec['address']; ?>" type="text"></td>
  </tr>
  <tr>
  <td></td>
  <td>
  <button id="submit" name="submit" class="btn btn-primary">Update</button>
  <a href = "T_update.php"><input type = "button" value = "Cancel" ></a>
  </td>
  </tr>
</table>
</center>
</form>


  





</body>
</html>

