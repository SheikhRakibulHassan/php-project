<!DOCTYPE>
<html>
<body>
<style>
.ta{
	
	float: left;
	margin:10px 1180px -340px 0px;
	text-align: left;
	padding:0px 10px;
	
}
.dropbtn {
    background-color:  #333;
    color: white;
    padding: 10px;
    font-size: 15px;
    border: none;
    cursor: pointer;
}

.dropdown {
  
    display: inline-block;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: red;
    min-width: 160px;
}

.dropdown-content a {
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
}

.dropdown-content a:hover {background-color: #f1f1f1}

.dropdown:hover .dropdown-content {
    display: block;
}
</style>




<?php

/* 
        VIEW.PHP
        Displays all data from 'players' table
*/

        // connect to the database
       mysql_connect ("localhost", "root","")  or die (mysql_error());
mysql_select_db ("school");

        // get results from database
        $result = mysql_query("SELECT * FROM mark") 
                or die(mysql_error());  
            
        // display data in table
		echo "<center>";
		echo "<br>";
		echo"<br>";
		echo"<br>";
		echo"<br>";
       echo "<p><b>Publish Result</b></p>";
        
echo "<table border='5' border-color='white' cellpadding='10'>";
echo"<tr><th>Teacher Name</th><th>Class</th><th>Roll No</th><th>Student Name</th><th>Subject Name</th><th>1st Term</th><th>2nd Term</th><th>Final</th><th>Totall</th><th>Grade</th><th>Status</th></tr>";

        // loop through results of database query, displaying them in the table
		 while($row = mysql_fetch_array( $result )) {
        
               
                // echo out the contents of each row into a table
                echo "<tr>";
				echo '<td>'.$row['tname'] . '</td>';
				 echo '<td>'. $row['class'].'</td>';
                      echo '<td>'. $row['roll'].'</td>';
                      echo'<td>'. $row['sname'].'</td>';
                          echo'<td>'. $row['subject'].'</td>';
                            echo'<td>'. $row['1st']. '</td>';
							echo'<td>'. $row['2nd'].'</td>';
                            echo'<td>'. $row['final']. '</td>';
							echo'<td>'. $row['totall']. '</td>';
							echo'<td>'. $row['grade'].'</td>';
                            echo'<td>'. $row['status']. '</td>';
                 
                                   echo "<tr>";
                            
				
				
                
                
                
				//echo '<td><a href="edit_stu_info.php?id=' . $row['id'] . '">Edit</a></td>';
                echo "</tr>"; 
        
}
        // close table>
        echo "</table>";
	
?>
<a href="mark_pdf.php" >PDF</a>
<a href="Registry.php" >Back</a>
</body>
</html>
<?php
?>