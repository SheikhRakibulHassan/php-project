<!Doctype html>
<html>
<head>
<title>Automatic Result System</title>
<link rel="stylesheet" href="Login.css">
</head>
<body>

<div class="navsection templete"><ul>
  <li><a href="Home.php">Home</a></li>
  <li><a href="About.php">About Us</a></li>
   
   <div class="dropdown">
            <button class="dropbtn">Login</button>
             <div class="dropdown-content">
                    
                 <a href="TLogin.php">Teacher</a>
                 <a href="SLogin.php">Student</a>
				 <a href="Login.php">Registry</a>
                  
                   </div>
  </ul>
  </div>
  <div class="form-control">
<form action="logincon.php" method="post">


                         <center>
						 <h2 style="padding:0px;margin-left:0px;font-size:25px;font-family:arial;"> Login For Registry</h2>
						 <hr width="30%" size="3" >
						<br>
						<br>
						<input type="text" name="name" id="name" class="form-control" placeholder="Enter User Name" />

                    <br>
					<br>
                     <input type="password" name="password" id="password" class="form-control" placeholder="password" />

                    <br>
					<br>
					

                 <input type="submit" value="Login" />            
                 <br>
				 <br>
                  </center>

                    

                        
                   
                </form>
				</div>
				</body>