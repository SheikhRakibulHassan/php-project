<!Doctype html>
<html>
<head>
<title>Automatic Result System</title>
<link rel="stylesheet" href="School.css">
</head>
<body>
<div class="navsection templete"><ul>
  <li><a href="Home.php">Home</a></li>
   <li><a href="About.php">About Us</a></li>
     <li><a href="Home.php">Log Out</a></li>
  </ul>
  </div>
  
 <center> <h2 style="padding:15px;font-size:25px;font-family:arial;">Field of Registry</h2>
   <hr width="50%" size="3" ></center>
</div>
 
<center style="margin-left:20px">

 <a href="S_Form.php" type="button" class="btn btn-info active" style="color:white;background-color:#269abc;bolder-color:#1b6d85;padding:9px 46px;font-size:15px;">Eroll New Student</a>
 <br>
 <a href="T_Form.php" type="button" class="btn btn-info active" style="color:white;background-color:#269abc;bolder-color:#1b6d85;padding:9px 46px;font-size:15px;">Eroll New Faculty</a>
 <br>
  <a href="T_update.php" type="button" class="btn btn-info active" style="color:white;background-color:#269abc;bolder-color:#1b6d85;padding:9px 46px;font-size:15px;">Update Faculty</a>
 <br>
 <a href="S_update.php" type="button" class="btn btn-info active" style="color:white;background-color:#269abc;bolder-color:#1b6d85;padding:9px 46px;font-size:15px;">Update  Student</a>
 <br>
 <a href="Publish_Result.php" type="button" class="btn btn-info active" style="color:white;background-color:#269abc;bolder-color:#1b6d85;padding:9px 46px;font-size:15px;">Publish Result</a>

</center>
</body>
