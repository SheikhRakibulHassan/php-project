<!Doctype html>
<html>
<head>
<title>Automatic Result System</title>
<link rel="stylesheet" href="Login.css">
</head>
<body>
<style>

.dropbtn {
    background-color:  #75a3a3;
    color: white;
	position: 50px;
    padding: 0px 80px;
    font-size: 17px;
    border: none;
    cursor: pointer;
}

.dropdown {
  
    display: inline-block;
	margin:10px 0px;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #75a3a3;
    min-width: 80px;
}

.dropdown-content a {
    color: white;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
}

.dropdown-content a:hover {background-color: #e69900}

.dropdown:hover .dropdown-content {
    display: block;
}


</style>
<div class="navsection templete"><ul>
  <li><a href="Home.php">Home</a></li>
   <li><a href="About.php">About Us</a></li>
  
   <div class="dropdown">
            <button class="dropbtn">Login</button>
             <div class="dropdown-content">
                    
                 <a href="TLogin.php">Teacher</a>
                 <a href="SLogin.php">Student</a>
				 <a href="Login.php">Regestry</a>
                 
                   </div>
  </ul>
  </div>
  <div class="form-control">
<form action="s_login.php" method="post">


                         <center>
						 <h2 style="padding:0px;margin-left:0px;font-size:25px;font-family:arial;"> Login For Student</h2>
						 <hr width="30%" size="3" >
						<br>
						<br>
						<input type="text" name="name" id="name" class="form-control" placeholder="Enter User Name" />

                    <br>
					<br>
                     <input type="password" name="password" id="password" class="form-control" placeholder="password" />

                    <br>
					<br>
					

                 <input type="submit" value="Login" />            
                 <br>
				 <br>
                  </center>

                    

                        
                   
                </form>
				</div>
				</body>