
 <!DOCTYPE>
<html>

<body>
<style>
.ta{
	
	float: left;
	margin:10px 1180px -430px 0px;
	text-align: left;
	padding:0px 10px;
	
}

table ,td {
    background-color: white;
	margin:2px 400px;
    color: black;
	
}

table ,th {
    background-color: blue;
	margin:2px 400px;
    color: white;
	
}
table{
 width: 50%;
 table-layout: fixed;
 border-color:#000000;
padding: 1px 5px;
 background-color: #f1f1c1;
color: white;
margin:2px 100px;

}



</style>


<?php
mysql_connect ("localhost", "root","")  or die (mysql_error());
mysql_select_db ("school");
 
$Id = $_POST['id'];

 
$sql = mysql_query("select * from teacher where id like '%$Id%'");
echo "<center>";
   echo "<table border='5' border-color='white' cellpadding='10'>";
echo"<tr><th>Teacher Name</th><th>id</th><th>Contact Number</th><th>Address</th></tr>";
echo"</center>";
 
while ($row = mysql_fetch_array($sql)){

   // echo 'ID: '.$row['ID'];
   // echo '<br/> ID: '.$row['id'];
   echo"<center>";
   echo "<table border='5' border-color='white' cellpadding='10'>";
   echo "<tr>";
  echo '<td>'.$row['name'] . '</td>';
 
 echo '<td>'. $row['id'].'</td>';
 echo'<td>'. $row['contact'].'</td>';
 echo'<td>'. $row['address'].'</td>';



  echo "<tr>";
  echo"</table>";
	
}

 
?>
<a href="Teacher.php" >Go To Back</a>
	</body>
	</html>
