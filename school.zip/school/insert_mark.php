<?php

$host="localhost"; // Host name 
$username="root"; // Mysql username 
$password=""; // Mysql password 
$db_name="school"; // Database name 
$tbl_name="mark"; // Table name 

// Connect to server and select database.
mysql_connect("$host", "$username", "$password")or die("cannot connect"); 
mysql_select_db("$db_name")or die("cannot select DB");

// Get values from form 

$TName=$_POST['tname'];
$Class=$_POST['class'];
$Roll=$_POST['roll'];
$SName=$_POST['sname'];
$Subject=$_POST['subject'];
$st=$_POST['1st'];
$nd=$_POST['2nd'];
$Final=$_POST['final'];
$Totall=$st+$nd+$Final;
if($Totall>=80 && $Totall<100){
	$Grade='A';
	$Status='Very Good Result';
}
if($Totall>=70 && $Totall<80){
	$Grade='B';
	$Status='Good Result';
}
if($Totall>=60 && $Totall<70){
	$Grade='C';
	$Status='Poor Result';
}
if($Totall>=50 && $Totall<60){
	$Grade='D';
	$Status='Very Poor Result';
}
if($Totall>=0 && $Totall<50){
	$Grade='F';
	$Status='Fail';
}

// Insert data into mysql 
$sql=mysql_query("INSERT INTO $tbl_name VALUES('$TName', '$Class','$Roll','$SName','$Subject','$st', '$nd','$Final','$Totall','$Grade','$Status')");
//$result=mysql_query($sql);

// if successfully insert data into database, displays message "Successful".

if($sql){
echo "<li><center><h1>...........Congratulation..........</b><a href='Grade.php'><br>Add Another</br></a></center></li>";
echo "<BR>";
echo "<a href='Grade.php'></a>";
echo "<BR>";


}

else {
echo "ERROR";
}
?> 

<?php 
// close connection 
mysql_close();
?>
