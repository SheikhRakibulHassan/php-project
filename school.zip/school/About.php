<!Doctype html>
<html>
<head>
<title>Automatic Result System</title>
</head>
<body>
<div>
<center><h2 style="font-size:30px;">Welcome to Evergreen High School</h2><hr width="60%" size="3"color="red" /></center>
</div>
<div>
<center><img src="22.png" alt=""style="width:500px;height:350px"/></center>
</div>
<hr width="60%" size="3"color="red" />
<div><center><p style= padding:0px;"><h2>Location</h2>
<hr width="10%" size="1"color="black" />

House# 03 ; Road# 15 ; Sector# 12 ; Uttara
Dhaka, Bangladesh 
<br>
<h2 style="">Mission</h2>
<hr width="10%" size="1"color="black" />

   The mission is to provide a challenging, internationally based education that teaching lifelong learners in a multi-cultural setting. 
   <br>
<h2>Vision</h2>
<hr width="10%" size="1"color="black" />

   The vision is for all of their students to reach their full potential and positively impact their world.

</center>
<p>
<center><a href="Home.php" type="button" class="btn btn-info active" style="color:white;background-color:#269abc;bolder-color:#1b6d85;padding:9px 46px;font-size:15px;">Back</a></center>
</div>