
 <!DOCTYPE>
<html>

<body>
<style>
.ta{
	
	float: left;
	margin:10px 1180px -430px 0px;
	text-align: left;
	padding:0px 30px;
	
}

table ,td {
    background-color: white;
	margin:2px 400px;
    color: black;
	
}

table ,th {
    background-color: blue;
	margin:2px 400px;
    color: white;
	
}
table{
 width: 90%;
 table-layout: fixed;
 border-color:#000000;
padding: 1px 5px;
 background-color: #f1f1c1;
color: white;
margin:2px 100px;

}



</style>


<?php
mysql_connect ("localhost", "root","")  or die (mysql_error());
mysql_select_db ("school");
 
$Id = $_POST['roll'];

 
$sql = mysql_query("select * from student where roll like '%$Id%'");
echo "<center>";
   echo "<table border='5' border-color='white' cellpadding='10'>";
echo"<tr><th>Student Name</th><th>Roll No</th><th>Password</th><th>Class</th><th>Father Name</th><th>Mother Name</th><th>Contact No</th><th>Address</th></tr>";
echo"</center>";
 
while ($row = mysql_fetch_array($sql)){

   // echo 'ID: '.$row['ID'];
   // echo '<br/> ID: '.$row['id'];
   echo"<center>";
   echo "<table border='5' border-color='white' cellpadding='10'>";
   echo "<tr>";
  echo '<td>'.$row['name'] . '</td>';
 
 echo '<td>'. $row['roll'].'</td>';
 echo'<td>'. $row['password'].'</td>';
 echo'<td>'. $row['class'].'</td>';
echo '<td>'. $row['father'].'</td>';
 echo'<td>'. $row['mother'].'</td>';
 echo'<td>'. $row['contact'].'</td>';
  echo'<td>'. $row['address'].'</td>';

  echo "<tr>";
  echo"</table>";
	
}

 
?>
<a href="student.php" >Go To Back</a>
	</body>
	</html>
