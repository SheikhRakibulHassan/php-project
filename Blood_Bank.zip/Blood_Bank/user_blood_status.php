 <?php
 
$db_name="bloodbank";
$host_username="root";
$host_password="";
$host="localhost";

   
    $doner=$_GET['id'];
	
	
	
	$query2="SELECT * FROM `bloodstatus` WHERE d_id='".$doner."' ";
    $search_result2 =filtertable($query2);

function filtertable($query){
	$connect= mysqli_connect("localhost","root","","bloodbank");
	$filter_result=mysqli_query($connect,$query);
	return $filter_result;
}




?>
 <!DOCTYPE>
<html>
<head>
<title>Blood Bank</title>
 <link rel="icon" href="image/bicon.jpg" type="image/x-icon">
<link href="css/style.css" rel="stylesheet" type="text/css" />
</head>
<center><img src="image/blood4.jpg" border="" alt="Logo" style="width:900px;height:140px;"></center>

      <h1 style="color:black;text-align: center;">Automated Blood Bank System</h1>
     <center> 
       <ul>
		<li><a  href="index.php">Home</a>
             <li><a  href="search.php">Search Donners</a></li>
              <li><a  href="Donner_reg.php">Register As Donor</a>
            <li><a  href="p_request.php">Request Blood</a> </li>
		   <li><a  href="eligibilty.php">Blood Tips</a> </li>
			<li><a  href="contact.php">Contact Us</a> </li>
		 <div class="dropdown">
            <button class="dropbtn">Login</button>
             <div class="dropdown-content">
                    
                 <a href="login.php">Donor</a>
                 <a href="login2.php">Admin</a>
                 <a href="login3.php">Organization</a>
                   </div> 
				
			</ul>
         
      </ul></center>




<article >	   
<center>
<h2>Doner Blood Report</h2><br>
<table>
<tr>
      
      <th>Doner ID</th>
	  <th>Doner Name</th>
	  <th>Syphilis</th>
      <th>HBV</th>
      <th>HIV</th>
	  <th>HCV</th>
	  <th>HEV</th>
	  <th>HTLV</th>
      <th>Malaria</th>
     
</tr> 
<?php while($rall=mysqli_fetch_array($search_result2)){?>
<tr> 
<td> <?php echo $rall['d_id'];?></td>
<td> <?php echo $rall['d_name'];?></td>
<td> <?php echo $rall['syphilis'];?></td>
<td> <?php echo $rall['hbv'];?></td>
<td> <?php echo $rall['hiv'];?></td>
<td> <?php echo $rall['hcv'];?></td>
<td> <?php echo $rall['hev'];?></td>
<td> <?php echo $rall['htlv'];?></td>
<td> <?php echo $rall['malaria'];?></td>
</tr>
<?php }?>
</table></center>
<center><a href='Search.php?id=<?php echo $row['id']?>'>Back</a></td></center>
</article >
</body>
</html>