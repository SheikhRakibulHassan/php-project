 <!DOCTYPE>
<html>
<head>
<title>Blood Bank</title>
 <link rel="icon" href="image/bicon.jpg" type="image/x-icon">
<link href="css/style.css" rel="stylesheet" type="text/css" />
</head>
<body>



<center><img src="image/blood4.jpg" border="" alt="Logo" style="width:900px;height:140px;"></center>

      <h1 style="color:black;text-align: center;">Automated Blood Bank System</h1>
     <center> 
       <ul>
		<li><a  href="index.php">Home</a>
             <li><a  href="search.php">Search Donners</a></li>
              <li><a  href="Donner_reg.php">Register As Donor</a>
            <li><a  href="p_request.php">Request Blood</a> </li>
		   <li><a  href="eligibilty.php">Blood Tips</a> </li>
			<li><a  href="contact.php">Contact Us</a> </li>
		 <div class="dropdown">
            <button class="dropbtn">Login</button>
             <div class="dropdown-content">
                    
                 <a href="login.php">Donor</a>
                 <a href="login2.php">Admin</a>
                 <a href="login3.php">Organization</a>
                   </div> 
				
			</ul>
         
      </ul></center>


	   



<center><nav><form id="form_444844" class="appnitro"  method="POST" action="s_view.php";>
				
<h3>Searching for Blood Donner</h3>
<h3>Note: Please before searching by Division first word should be capital </h3>
<h4>
Blood Group:<br><select name="did">
<option value="A+">A+</option>
<option value="A-">A-</option>
<option value="B+">B+</option>
<option value="B-">B-</option>
<option value="O+">O+</option>
<option value="O-">O-</option>
<option value="AB+">AB+</option>
<option value="AB-">AB-</option>
</select>
<br>
<br>
Division:<br><select name="dn">
<option value="Dhaka">Dhaka</option>
<option value="Sylhet">Sylhet</option>
<option value="Mymensingh">Mymensingh</option>
<option value="Chittagong">Chittagong</option>
<option value="Barisal">Barisal</option>
<option value="Khulna">Khulna</option>
<option value="Rajshahi">Rajshahi</option>
<option value="Rangpur">Rangpur</option>
</select>
<br>
</h4>
<input type="submit" name="search" value="Search">

</form></nav></center>


</body>
</html>
