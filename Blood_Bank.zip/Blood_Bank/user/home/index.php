 <!DOCTYPE>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Blood Bank</title>
 <link rel="icon" href="../../images/bicon.jpg" type="image/x-icon">
<link href="../../css/style.css" rel="stylesheet" type="text/css" />
</head>
<body>


<center><img src="../../image/logo.png" border="" alt="Logo" style="width:800px;height:140px;"></center>

       <h1 style="color:black;text-align: center;">Automated Blood Bank System</h1>
     <center> 
       <ul>
		<li><a  href="index.php">Home</a>
             <li><a  href="search.php">Search Donners</a></li>
              <li><a  href="Donner_reg.php">Register As Donor</a>
           <li><a  href="p_request.php">Request Blood</a> </li>
		   <li><a  href="eligibilty.php">Blood Tips</a> </li>
			<li><a  href="contact.php">Contact Us</a> </li>
		 <li><a  href="../../index.php">Log Out</a> </li> 
				
			</ul>
         
      </ul></center>

	   
	
	

<center><img src="../../image/im-3.jpg"alt="Hospital"  border="" style="width:1350px;height:450px;"></center>

</form></div></center>


</body>
</html>
