 <!DOCTYPE>
 <?php
$db_name="bloodbank";
$host_username="root";
$host_password="";
$host="localhost";

function filtertable($query){
	$connect= mysqli_connect("localhost","root","","bloodbank");
	$filter_result=mysqli_query($connect,$query);
	return $filter_result;
}


	$user_name=$_GET['id'];
	
	$query="SELECT * FROM donner WHERE id='".$user_name."'";
	$search_result =filtertable($query);
  $row = mysqli_fetch_array($search_result);
    $name=$row['name'];
	$pas=$row['password'];
	$img=$row['image'];
	$id=$row['id'];
	$div=$row['division'];
	$em=$row['email'];
	$loc=$row['location'];
	$num=$row['c_number'];
	$gro=$row['b_group'];
	$da=$row['l_date'];
	$ag=$row['age'];
	$se=$row['sex'];
	
?>
<html>
<head>
<title>Blood Bank</title>
 <link rel="icon" href="../../image/bicon.jpg" type="image/x-icon">
<link href="../../css/style.css" rel="stylesheet" type="text/css" />
</head>
<body>

<center><img src="../../image/logo.png" border="" alt="Logo" style="width:800px;height:140px;"></center>

      <h1 style="color:black;text-align: center;">Automated Blood Bank System</h1>
     <center> 
       <ul>
		<li><a  href="index.php">Home</a>
             <li><a  href="search.php">Search Donners</a></li>
              <li><a  href="Donner_reg.php">Register As Donor</a>
            <li><a  href="p_request.php">Request Blood</a> </li>
		   <li><a  href="eligibilty.php">Blood Tips</a> </li>
			<li><a  href="contact.php">Contact Us</a> </li>
		 <li><a  href="../../index.php">Log Out</a> </li>
			</ul>
         
      </ul></center>


	   



<center><nav><form id="form_444844" class="appnitro"  method="POST" action="connection/donner_reg_c_c.php";>
				
<h3>Application for Blood Donner</h3>
<h3>Note: If your live in Bangladesh then only register</h3>
<h4>
Doner Id:<br>
<input name="did" type="text" id="did" value="<?php echo "$id";?> " readonly>
<br>
<br>
Doner Name:<br>
<input name="dn" type="text" id="dn" value="<?php echo "$name";?>" readonly>
<br>
<br>
Request Id:<br>
<input name="ddd" type="text" id="dn" value="<?php echo uniqid();?>" readonly>
<br>
<br>
Request Name:<br>
<input name="email" type="text" id="email">
<br>
<br>
Location:<br>
<input name="area" type="text" id="area">
<br>
<br>
Contact Number:<br>
<input name="cno" type="number" id="cno">
<br>
<br>
Requer Blood:<br>
<input name="bgrp" type="text" id="bgrp" value="<?php echo "$gro";?>" readonly>
<br>
<br>
Blood Request Date:<br>
<input name="date" type="date" id="date">
<br>
<br>
Age:<br>
<input name="bbb" type="text" id="bgrp">
<br>
<br>
Sex:<br>
<input value= "Male" name="sex" type="checkbox" id="sex">Male
<input value= "Female" name="sex" type="checkbox" id="sex">Female
<input value= "Others" name="sex" type="checkbox" id="sex">Others
<br>
</h4>
<input type="submit" name="Submit" value="Submit">

</form></nav></center>


</body>
</html>

