 <!DOCTYPE>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Blood Bank</title>
 <link rel="icon" href="../../images/bicon.jpg" type="image/x-icon">

<link href="../../css/style.css" rel="stylesheet" type="text/css" />
</head>
<body>


<center><img src="image/logo.png" border="" alt="Logo" style="width:800px;height:140px;"></center>

      <h1 style="color:black;text-align: center;">Automated Blood Bank System</h1>
       <center> 
       <ul>
		<li><a  href="index.php">Home</a>
             <li><a  href="search.php">Search Donners</a></li>
              <li><a  href="Donner_reg.php">Register As Donor</a>
            <li><a  href="p_request.php">Request Blood</a> </li>
		   <li><a  href="eligibilty.php">Blood Tips</a> </li>
			<li><a  href="contact.php">Contact Us</a> </li>
		 <li><a  href="../../index.php">Log Out</a> </li>
				
			</ul>
         
      </ul></center>
	  
	  <h1>Blood Donation: Who Can Give Blood</h1>
	  <h3>You are not eligible to donate blood if you:</h3>

	  <a>1.You must be at least 17 years old to donate to the general blood supply.</a><br>
	  <a>2.Have ever used self-injected drugs (non-prescription)</a><br>
	  <a>3.Had hepatitis</a><br>
	   <a>4.Are in a high-risk group for AIDS</a><br>
	  <a>5.You must weigh at least 110 pounds to be eligible for blood donation for your own safety.</a><br>
	  <a>6.High Blood Pressure Acceptable as long as your blood pressure is below 180 systolic (first number) and below 100 diastolic (second number) at the time of donation.</a><br>
	   <br><center><div class="contentsection templete"> 
      <img src="image/aaaa.JPG" alt="" style="width:400px;height:300px"> 
      <img src="image/aaa.JPG" alt="" style="width:400px;height:300px">
      <img src="image/aa.JPG" alt="" style="width:400px;height:300px">
      </div></center>
	  </html>
