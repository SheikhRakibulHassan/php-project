<?php

$db_name="bloodbank";
$host_username="root";
$host_password="";
$host="localhost";

function filtertable($query){
	$connect= mysqli_connect("localhost","root","","bloodbank");
	$filter_result=mysqli_query($connect,$query);
	return $filter_result;
}

    $user_name=$_GET['id'];

	$query2="SELECT * FROM donner WHERE id='".$user_name."'";
	$search_result2 =filtertable($query2);
    $rol = mysqli_fetch_array($search_result2);
    $name=$rol['name'];
    $id=$rol['id'];
    $gro=$rol['b_group'];

	$query="SELECT * FROM admin ";
	$search_result =filtertable($query);
    $row = mysqli_fetch_array($search_result);
    $a_name=$row['a_name'];
	$a_id=$row['a_id'];
	$div=$row['a_ocupation'];
	$em=$row['a_email'];
	$num=$row['a_number'];
	
	$da=$row['d_birth'];
	$se=$row['a_sex'];
	
?>
<!DOCTYPE>
<html>
<head>
<title>Blood Bank</title>
<link rel="icon" href="image/bicon.jpg" type="image/x-icon">
<link href="../css/style2.css" rel="stylesheet" type="text/css" />
</head>
<body>

<div class="header">
 <a href='login.php'><img ' class="img-1" src="../connection/images/<?php echo $rol['image'];?>" ></a>
</div>
<center><h1>Welcome <?php echo "$name";?> </h1> </center>

    <nav>
       <ul>
		<li><a  href="home/index.php">Home</a></li>
		<li><a  href="user_account2.php?id=<?php echo $id?>">Profile</a></li>
        <li><a  href="user_admin.php?id=<?php echo $id?>">Admin Information</a></li>
        <li><a  href="user_overal_request.php?id=<?php echo $id?>">Pending Request</a>
		<li><a  href="view_accpect_request.php?id=<?php echo $id?>">View Accepted Request</a> </li>
		<li><a  href="edit_user_account.php?id=<?php echo $user_name?>">Edit Account</a> </li>
	    <li><a  href="user_blood_status.php?id=<?php echo $user_name?>">Blood Status</a> </li> 
	    <li><a  href="../index.php">Logout</a> </li> 
		</ul>
         
      </ul>
    </nav>
	
<article >
<table>

<h2>Basic Information</h2>
<?php
if($gro=="AB+" || $gro=="AB-"){?>
<div class="Menu">
 <h4 class="fornt"><?php echo "$gro";?><h4>
</div>
<?php }
else {?>

<div class="Menu">
 <h4 class="for" ><?php echo "$gro";?><h4>
</div>
<?php } ?>

<tr>
      <td>Admin Full Name</td>
      <td><?php echo "$a_name";?></td>
</tr>

<tr>
      <td>Contact Number</td>
      <td><?php echo "$num";?></td>
</tr>

<tr>
      <td>Email Address</td>
      <td><?php echo "$em";?></td>
</tr>

<tr>
      <td>Admin Id</td>
      <td><?php echo "$a_id";?></td>
</tr>
 


</table ><br>

<br><table>

<h2>Additional Information</h2>

<tr>
      <td>Occupation</td>
      <td><?php echo " $div.";?></td>
</tr>

<tr>
      <td>Date of birth</td>
      <td><?php echo "$da";?></td>
</tr>

<tr>
      <td>Gender</td>
      <td><?php echo "$se";?></td>
</tr>

 
</table>
             



  </article >
 
</body>
</html>
	   



