<?php
	
	function filtertable($query){
	$connect= mysqli_connect("localhost","root","","bloodbank");
	$filter_result=mysqli_query($connect,$query);
	return $filter_result;
}
	
	$db = mysqli_connect('localhost', 'root', '', 'bloodbank');

    $pe_id=$_GET['id'];
	
	$sqr="SELECT * FROM a_r_donner WHERE pe_id='".$pe_id."'";
	$search_result =filtertable($sqr);
    $row = mysqli_fetch_array($search_result);
	$id=$row['r_id'];
	
	$query="DELETE  FROM a_r_donner WHERE pe_id='".$pe_id."'";
     
	mysqli_query($db,$query);
	 
   
	
	if($query){ ?>
   <center>Successful<a href="view_accpect_request.php?id=<?php echo $id?>"><br>Return</br></a></center> 
   <?php }
	
	

?> 
