<?php
$db_name="bloodbank";
$host_username="root";
$host_password="";
$host="localhost";

function filtertable($query){
	$connect= mysqli_connect("localhost","root","","bloodbank");
	$filter_result=mysqli_query($connect,$query);
	return $filter_result;
}


    $user_name=$_GET['id'];

	$query="SELECT * FROM donner WHERE id='".$user_name."'";
	$search_result =filtertable($query);
    $row = mysqli_fetch_array($search_result);
    $name=$row['name'];
	$pas=$row['password'];
	$img=$row['image'];
	$id=$row['id'];
	$div=$row['division'];
	$em=$row['email'];
	$loc=$row['location'];
	$num=$row['c_number'];
	$gro=$row['b_group'];
	$da=$row['l_date'];
	$ag=$row['age'];
	$se=$row['sex'];
	
	
   $query="SELECT * FROM a_r_donner WHERE  r_id='".$id."'";
   $search_result =filtertable($query);
   
?>
<!DOCTYPE>
<html>
<head>
<title>Blood Bank</title>
<link rel="icon" href="image/bicon.jpg" type="image/x-icon">
<link href="../css/style5.css" rel="stylesheet" type="text/css" />
</head>
<body>

<div class="header">
 <a href='login.php'><img ' class="img-1" src="../connection/images/<?php echo $row['image'];?>" ></a>
</div>
<center><h1>Welcome <?php echo "$name";?> </h1> </center>

    <nav>
       <ul>
		<li><a  href="home/index.php">Home</a></li>
		<li><a  href="user_account2.php?id=<?php echo $row['id']?>">Profile</a></li>
        <li><a  href="user_admin.php?id=<?php echo $id?>">Admin Information</a></li>
        <li><a  href="user_overal_request.php?id=<?php echo $id?>">Pending Request</a>
		<li><a  href="view_accpect_request.php?id=<?php echo $id?>">	View Accepted Request</a> </li>
		<li><a  href="edit_user_account.php?id=<?php echo $user_name?>">Edit Account</a> </li>
	    <li><a  href="user_blood_status.php?id=<?php echo $user_name?>">Blood Status</a> </li> 
	    <li><a  href="../index.php">Logout</a> </li> 
		</ul>
         
      </ul>
    </nav>
	
<article >
<table>

<h2>Pending Request</h2>
<br>
<table>
<tr>
      
      <th>Doner Id</th>
	  <th>Doner Name</th>
	  <th>Accepted Id</th>
      <th>Accepted Name</th>
      <th>Donation Date</th>
	  <th>Accepted Gender</th>
	  <th>Accepted Number</th>
	  <th>Accepted Location</th>
	  <th>Blood Group</th>
      <th>Status</th>
	  <th>Donation Information</th>
	  <th>Remove</th>
	
     

</tr> 
<?php while($rec=mysqli_fetch_array($search_result)){ ?>
<tr> 
<td> <?php echo $rec['r_id'];?></td>
<td> <?php echo $rec['r_name'];?></td>
<td> <?php echo $rec['pe_id'];?></td>
<td> <?php echo $rec['pe_name'];?></td>
<td> <?php echo $rec['don_date'];?></td>
<td> <?php echo $rec['pe_sex'];?></td>
<td> <?php echo $rec['pe_number'];?></td>
<td> <?php echo $rec['don_location'];?></td>
<td> <?php echo $rec['b_group'];?></td>
<td> <?php if( "Accept" != $rec['status']){ echo "Pending";} else {echo "Accept";}?></td>
<td> <a href='donation_information.php?id=<?php echo $rec['pe_id']?>'>Submit</a></td>
<td> <a href='user_request_dalete2.php?id=<?php echo $rec['pe_id']?>'>Delete</a></td>
</tr>
<?php }?>

</table ><br>
            
  </article >
 
</body>
</html>
	   



