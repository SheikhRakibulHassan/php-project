<?php
$db_name="bloodbank";
$host_username="root";
$host_password="";
$host="localhost";

function filtertable($query){
	$connect= mysqli_connect("localhost","root","","bloodbank");
	$filter_result=mysqli_query($connect,$query);
	return $filter_result;
}

if(isset($_POST["submit"])){

if(!empty($_POST['user_name']) && !empty($_POST['password'])) {
	$user_name=$_POST['user_name'];
	$password=$_POST['password'];
	
	$query="SELECT * FROM donner WHERE name='".$user_name."' AND password='".$password."'";
	$search_result =filtertable($query);
  $row = mysqli_fetch_array($search_result);
    $name=$row['name'];
	$pas=$row['password'];
	$img=$row['image'];
	$id=$row['id'];
	$div=$row['division'];
	$em=$row['email'];
	$loc=$row['location'];
	$num=$row['c_number'];
	$gro=$row['b_group'];
	$da=$row['l_date'];
	$ag=$row['age'];
	$se=$row['sex'];
	$status=$row['status'];
if( ($user_name==$name) &&($password==$pas) && ($status=='Accept') ){
	
?>
<!DOCTYPE>
<html>
<head>
<title>Blood Bank</title>
<link rel="icon" href="image/bicon.jpg" type="image/x-icon">
<link href="../css/style2.css" rel="stylesheet" type="text/css" />
</head>
<body>

<div class="header">
 <a href='login.php'><img ' class="img-1" src="../connection/images/<?php echo $row['image'];?>" ></a>
</div>
<center><h1>Welcome <?php echo "$name";?> </h1> </center>

    <nav>
       <ul>
		<li><a  href="home/index.php">Home</a></li>
		<li><a  href="user_account2.php?id=<?php echo $row['id']?>">Profile</a></li>
        <li><a  href="user_admin.php?id=<?php echo $id?>">Admin Information</a></li>
        <li><a  href="user_overal_request.php?id=<?php echo $id?>">Pending Request</a>
		<li><a  href="view_accpect_request.php?id=<?php echo $id?>">	View Accepted Request</a> </li>
		<li><a  href="eligibilty.php">Edit Account</a> </li>
	    <li><a  href="user_blood_status.php?id=<?php echo $user_name?>">Blood Status</a> </li> 
	    <li><a  href="../index.php">Logout</a> </li> 
		</ul>
         
      </ul>
    </nav>
	
<article >
<table>

<h2>Basic Information</h2>
<?php if($gro=="AB+" || $gro=="AB-"){?>
<div class="Menu">
 <h4 class="fornt"><?php echo "$gro";?><h4>
</div>
<?php } else {?>

<div class="Menu">
 <h4 class="for" ><?php echo "$gro";?><h4>
</div>
<?php } ?>

<tr>
      <td>Full Name</td>
      <td><?php echo "$name";?></td>
</tr>

<tr>
      <td>Contact Number</td>
      <td><?php echo "$num";?></td>
</tr>

<tr>
      <td>Email Address</td>
      <td><?php echo "$em";?></td>
</tr>

<tr>
      <td>Doner Id</td>
      <td><?php echo "$id";?></td>
</tr>
 
<tr>
      <td>Password</td>
      <td><a href='login.php'>Change password</a></td>
</tr>

</table ><br>

<br><table>

<h2>Additional Information</h2>

<tr>
      <td>Present Adress</td>
      <td><?php echo "$loc, $div.";?></td>
</tr>

<tr>
      <td>Blood Donate Last Date</td>
      <td><?php echo "$da";?></td>
</tr>

<tr>
      <td>Gender</td>
      <td><?php echo "$se";?></td>
</tr>

<tr>
      <td>Age</td>
      <td><?php echo "$ag";?></td>
</tr>
 
</table>
             



  </article >
 
</body>
</html>
	   
<?php }

else{
	 echo "<center><h1>Wrong Password or Name or not Valid</b><a href='../login.php'><br>check</br></a></center>";;
}
}
else{
	 echo "<center><h1>Make sure Name or Passwoed not empty</b><a href='../login.php'><br>check</br></a></center>";;
}
}?>


