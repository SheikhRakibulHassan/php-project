<?php
session_start();
$db_name="bloodbank";
$host_username="root";
$host_password="";
$host="localhost";

function filtertable($query){
	$connect= mysqli_connect("localhost","root","","bloodbank");
	$filter_result=mysqli_query($connect,$query);
	return $filter_result;
}


    $user_name=$_GET['id'];
	$_SESSION["id1"]= $user_name;
	
    $query="SELECT * FROM donner WHERE id='".$user_name."'";
    $search_result =filtertable($query);
    $row = mysqli_fetch_array($search_result);
    $name=$row['name'];
	$pas=$row['password'];
	$img=$row['image'];
	$id=$row['id'];
	$div=$row['division'];
	$em=$row['email'];
	$loc=$row['location'];
	$num=$row['c_number'];
	$gro=$row['b_group'];
	$da=$row['l_date'];
	$ag=$row['age'];
	$se=$row['sex'];
	
   $query="SELECT * FROM o_donner ";
   $search_result =filtertable($query);
   
   $query1="SELECT * FROM o_donner ";
   $search_result1 =filtertable($query1);
   
   $query2="SELECT * FROM o_donner";
   $search_result2 =filtertable($query2);
   
   $query3="SELECT * FROM o_donner";
   $search_result3 =filtertable($query3);
   
   $query4="SELECT * FROM o_donner";
   $search_result4 =filtertable($query4);
   
   $query5="SELECT * FROM o_donner";
   $search_result5 =filtertable($query5);
   
   $query6="SELECT * FROM o_donner";
   $search_result6 =filtertable($query6);
   
   $query7="SELECT * FROM o_donner";
   $search_result7 =filtertable($query7);
	
   $query8="SELECT * FROM o_donner";
   $search_result8 =filtertable($query8);
   
   $query9="SELECT * FROM o_donner";
   $search_result9 =filtertable($query9);
   
   $query10="SELECT * FROM o_donner";
   $search_result10 =filtertable($query10);
	
   $query11="SELECT * FROM o_donner";
   $search_result11 =filtertable($query11);
   
   $query12="SELECT * FROM a_r_donner where r_id= '".$user_name."' ";
   $search_result12 =filtertable($query12);
   $rtt=mysqli_fetch_array($search_result12);
   $da= $rtt['don_date'];
  // echo $da;
   if($da != null){
   $da2 = date('Y-m-d', strtotime($da . " + 90 day"));
   //echo $da2;
   }
   else{
	   $da2=0;
   }
  // echo $da2;
?>
<!DOCTYPE>
<html>
<head>
<title>Blood Bank</title>
<link rel="icon" href="image/bicon.jpg" type="image/x-icon">
<link href="../css/style3.css" rel="stylesheet" type="text/css" />
</head>
<body>

<div class="header">
 <a href='login.php'><img ' class="img-1" src="../connection/images/<?php echo $row['image'];?>" ></a>
</div>
<center><h1>Welcome <?php echo "$name";?> </h1> </center>

    <nav>
       <ul>
		<li><a  href="home/index.php">Home</a></li>
		<li><a  href="user_account2.php?id=<?php echo $row['id']?>">Profile</a></li>
        <li><a  href="user_admin.php?id=<?php echo $id?>">Admin Information</a></li>
        <li><a  href="user_overal_request.php?id=<?php echo $id?>">Pending Request</a>
		<li><a  href="view_accpect_request.php?id=<?php echo $id?>">	View Accepted Request</a> </li>
		<li><a  href="edit_user_account.php?id=<?php echo $user_name?>">Edit Account</a> </li>
	    <li><a  href="user_blood_status.php?id=<?php echo $user_name?>">Blood Status</a> </li> 
	    <li><a  href="../index.php">Logout</a> </li> 
		</ul>
         
      </ul>
    </nav>
	
<article >
<table>
<tr>
      <td>Person Id:</td>
	  <?php while($rec=mysqli_fetch_array($search_result)){if ($gro == $rec['p_b_group']){?>
      <td><?php echo $rec['pe_id'];?></td>
	  <?php }}?>
</tr>

<tr>
      <td>Person Name:</td>
	  <?php while($rec=mysqli_fetch_array($search_result1)){ if ($gro == $rec['p_b_group']){?>
      <td><?php echo $rec['p_name'];?></td>
	  <?php }}?>
</tr>

<tr>
      <td>Division:</td>
	  <?php while($rec=mysqli_fetch_array($search_result2)){ if ($gro == $rec['p_b_group']){?>
      <td><?php echo $rec['p_division'];?></td>
	  <?php }}?>
</tr>

<tr>
      <td>Email:</td>
	  <?php while($rec=mysqli_fetch_array($search_result3)){if ($gro == $rec['p_b_group']){?>
      <td><?php echo $rec['p_email'];?></td>
	  <?php }}?>
</tr>
<tr>
      <td>Location:</td>
	  <?php while($rec=mysqli_fetch_array($search_result4)){if ($gro == $rec['p_b_group']){?>
      <td><?php echo $rec['p_location'];?></td>
	  <?php }}?>
</tr>
<tr>
      <td>Number:</td>
	  <?php while($rec=mysqli_fetch_array($search_result5)){if ($gro == $rec['p_b_group']){?>
      <td><?php echo $rec['p_number'];?></td>
	  <?php }}?>
</tr>
<tr>
      <td>Blood Group:</td>
	  <?php while($rec=mysqli_fetch_array($search_result6)){if ($gro == $rec['p_b_group']){?>
      <td><?php echo $rec['p_b_group'];?></td>
	  <?php }}?>
</tr>
<tr>
      <td>Request Date:</td>
	  <?php while($rec=mysqli_fetch_array($search_result7)){if ($gro == $rec['p_b_group']){?>
      <td><?php echo $rec['p_date'];?></td>
	  <?php }} ?>
</tr>
<tr>
      <td>Age:</td>
	  <?php while($rec=mysqli_fetch_array($search_result8)){if ($gro == $rec['p_b_group']){?>
      <td><?php echo $rec['age'];?></td>
	  <?php }}?>
</tr>
<tr>
      <td>Sex:</td>
	  <?php while($rec=mysqli_fetch_array($search_result9)){if ($gro == $rec['p_b_group']){?>
      <td><?php echo $rec['sex'];?></td>
	  <?php }}?>
</tr>



<tr>
      <td>Want to Donate:</td>
	  <?php while($rec=mysqli_fetch_array($search_result10)){if ($gro == $rec['p_b_group']){$da4= $rec['p_date'];
              $da3 = date('Y-m-d', strtotime($da4."+0 day"));  if($da2 < $da3) { ?>
      <td><a  href="user_request_accpect_ovaral.php?id=<?php echo $rec['pe_id']?>">Acepect</a></td>
	  <?php }}}?>
</tr>

</table ><br>
            
  </article >
 
</body>
</html>
	   



