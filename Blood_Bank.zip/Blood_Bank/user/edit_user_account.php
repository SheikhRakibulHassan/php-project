<?php
session_start();
$db_name="bloodbank";
$host_username="root";
$host_password="";
$host="localhost";

function filtertable($query){
	$connect= mysqli_connect("localhost","root","","bloodbank");
	$filter_result=mysqli_query($connect,$query);
	return $filter_result;
}


    $user_name=$_GET['id'];
	$_SESSION["id2"]= $user_name;
	
    $query="SELECT * FROM donner WHERE id='".$user_name."'";
    $search_result =filtertable($query);
    $row = mysqli_fetch_array($search_result);
    $name=$row['name'];
	$pas=$row['password'];
	$img=$row['image'];
	$id=$row['id'];
	$div=$row['division'];
	$em=$row['email'];
	$loc=$row['location'];
	$num=$row['c_number'];
	$gro=$row['b_group'];
	$da=$row['l_date'];
	$ag=$row['age'];
	$se=$row['sex'];
	
   $query="SELECT * FROM o_donner ";
   $search_result =filtertable($query);
   
   $query1="SELECT * FROM o_donner ";
   $search_result1 =filtertable($query1);
   
   $query2="SELECT * FROM o_donner";
   $search_result2 =filtertable($query2);
   
   $query3="SELECT * FROM o_donner";
   $search_result3 =filtertable($query3);
   
   $query4="SELECT * FROM o_donner";
   $search_result4 =filtertable($query4);
   
   $query5="SELECT * FROM o_donner";
   $search_result5 =filtertable($query5);
   
   $query6="SELECT * FROM o_donner";
   $search_result6 =filtertable($query6);
   
   $query7="SELECT * FROM o_donner";
   $search_result7 =filtertable($query7);
	
   $query8="SELECT * FROM o_donner";
   $search_result8 =filtertable($query8);
   
   $query9="SELECT * FROM o_donner";
   $search_result9 =filtertable($query9);
   
   $query10="SELECT * FROM o_donner";
   $search_result10 =filtertable($query10);
	
   $query11="SELECT * FROM o_donner";
   $search_result11 =filtertable($query11);
   
?>
<!DOCTYPE>
<html>
<head>
<title>Blood Bank</title>
<link rel="icon" href="image/bicon.jpg" type="image/x-icon">
<link href="../css/style4.css" rel="stylesheet" type="text/css" />
</head>
<body>

<div class="header">
 <a href='login.php'><img ' class="img-1" src="../connection/images/<?php echo $row['image'];?>" ></a>
</div>
<center><h1>Welcome <?php echo "$name";?> </h1> </center>

    <nav>
       <ul>
		<li><a  href="home/index.php">Home</a></li>
		<li><a  href="user_account2.php?id=<?php echo $row['id']?>">Profile</a></li>
        <li><a  href="user_admin.php?id=<?php echo $id?>">Admin Information</a></li>
        <li><a  href="user_overal_request.php?id=<?php echo $id?>">Pending Request</a>
		<li><a  href="view_accpect_request.php?id=<?php echo $id?>">	View Accepted Request</a> </li>
		<li><a  href="edit_user_account.php?id=<?php echo $user_name?>">Edit Account</a> </li>
	    <li><a  href="user_blood_status.php?id=<?php echo $user_name?>">Blood Status</a> </li> 
	    <li><a  href="../index.php">Logout</a> </li> 
		</ul>
         
      </ul>
    </nav>
	
<article >
<center><form id="form_444844" class="appnitro"  method="POST" enctype="multipart/form-data" action="../connection/update_doner_info.php";>
				
Name:<br>
<input name="name" type="text" id="name" value="<?php echo $name ;?>" required>
<br>
<br>
Division:<br><select name="division" >
<option value="Dhaka"
<?php if($div == 'Dhaka'){
echo "selected";}?>
>Dhaka</option>
<option value="Sylhet" 
<?php if($div == 'Sylhet'){
echo "selected";}?>
>Sylhet</option>
<option value="Mymensingh"
<?php if($div == 'Mymensingh'){
echo "selected";}?>
>Mymensingh</option>
<option value="Chittagong"
<?php if($div == 'Chittagong'){
echo "selected";}?>
>Chittagong</option>
<option value="Barisal"
<?php if($div == 'Barisal'){
echo "selected";}?>
>Barisal</option>
<option value="Khulna"
<?php if($div == 'Khulna'){
echo "selected";}?>
>Khulna</option>
<option value="Rajshahi"
<?php if($div == 'Rajshahi'){
echo "selected";}?>
>Rajshahi</option>
<option value="Rangpur"
<?php if($div == 'Rangpur'){
echo "selected";}?>
>Rangpur</option>
</select>
<br>
<br>
Email Id:<br>
<input name="email" type="email" id="email" value="<?php echo $em ;?>" >
<br>
<br>
Location:<br>
<input name="location" type="text" id="location" value="<?php echo $loc ;?>" required>
<br>
<br>
Contact Number:<br>
<input name="c_number" type="number" id="c_number" value="<?php echo $num ;?>"  required>
<br>
<br>
Blood group:<br><select name="b_group" required>
<option value="A+"
<?php if($gro == 'A+'){
echo "selected";}?>
>A+</option>
<option value="A-"
<?php if($gro == 'A-'){
echo "selected";}?>
>A-</option>
<option value="B+"
<?php if($gro == 'B+'){
echo "selected";}?>
>B+</option>
<option value="B-"
<?php if($gro == 'B-'){
echo "selected";}?>
>B-</option>
<option value="O+"
<?php if($gro == 'O+'){
echo "selected";}?>
>O+</option>
<option value="O-"
<?php if($gro == 'O-'){
echo "selected";}?>
>O-</option>
<option value="AB+"
<?php if($gro == 'AB+'){
echo "selected";}?>
>AB+</option>
<option value="AB-"
<?php if($gro == 'AB-'){
echo "selected";}?>
>AB-</option>
</select>
<br>
<br>
Age:<br>
<input name="age" type="number" id="age" value="<?php echo $ag ;?>" required>
<br>
<br>
<input type="submit" name="Submit" value="Submit">

</form></center>
            
  </article >
 
</body>
</html>
	   



