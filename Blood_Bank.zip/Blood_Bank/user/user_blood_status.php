 <?php
 
$db_name="bloodbank";
$host_username="root";
$host_password="";
$host="localhost";

   
    $doner=$_GET['id'];
	
    $query="SELECT * FROM donner WHERE id='".$doner."'";
    $search_result =filtertable($query);
    $row = mysqli_fetch_array($search_result);
    $name=$row['name'];
	$pas=$row['password'];
	$img=$row['image'];
	$id=$row['id'];
	$div=$row['division'];
	$em=$row['email'];
	$loc=$row['location'];
	$num=$row['c_number'];
	$gro=$row['b_group'];
	$da=$row['l_date'];
	$ag=$row['age'];
	$se=$row['sex'];
	
	
	$query2="SELECT * FROM `bloodstatus` WHERE d_id='".$doner."' ";
    $search_result2 =filtertable($query2);

function filtertable($query){
	$connect= mysqli_connect("localhost","root","","bloodbank");
	$filter_result=mysqli_query($connect,$query);
	return $filter_result;
}




?>
 <!DOCTYPE>
<html>
<head>
<title>Blood Bank</title>
 <link rel="icon" href="image/bicon.jpg" type="image/x-icon">
<link href="../css/style5.css" rel="stylesheet" type="text/css" />
</head>
<body>

<div class="header">
 <a href='login.php'><img ' class="img-1" src="../connection/images/<?php echo $row['image'];?>" ></a>
</div>
<center><h1>Welcome <?php echo "$name";?> </h1> </center>

    <nav>
       <ul>
		<li><a  href="home/index.php">Home</a></li>
		<li><a  href="user_account2.php?id=<?php echo $id?>">Profile</a></li>
        <li><a  href="user_admin.php?id=<?php echo $id?>">Admin Information</a></li>
        <li><a  href="user_overal_request.php?id=<?php echo $id?>">Pending Request</a>
		<li><a  href="view_accpect_request.php?id=<?php echo $id?>">View Accepted Request</a> </li>
		<li><a  href="edit_user_account.php?id=<?php echo $id?>">Edit Account</a> </li>
	    <li><a  href="user_blood_status.php?id=<?php echo $id?>">Blood Status</a> </li> 
	    <li><a  href="../index.php">Logout</a> </li> 
		</ul>
         
      </ul>
         
      </ul>
    </nav>




<article >	   
<center>
<h2>Doner Blood Report</h2><br>
<table>
<tr>
      
      <th>Doner ID</th>
	  <th>Doner Name</th>
	  <th>Syphilis</th>
      <th>HBV</th>
      <th>HIV</th>
	  <th>HCV</th>
	  <th>HEV</th>
	  <th>HTLV</th>
      <th>Malaria</th>
     
</tr> 
<?php while($rall=mysqli_fetch_array($search_result2)){?>
<tr> 
<td> <?php echo $rall['d_id'];?></td>
<td> <?php echo $rall['d_name'];?></td>
<td> <?php echo $rall['syphilis'];?></td>
<td> <?php echo $rall['hbv'];?></td>
<td> <?php echo $rall['hiv'];?></td>
<td> <?php echo $rall['hcv'];?></td>
<td> <?php echo $rall['hev'];?></td>
<td> <?php echo $rall['htlv'];?></td>
<td> <?php echo $rall['malaria'];?></td>
</tr>
<?php }?>
</table></center>
</article >
</body>
</html>