<?php
	
	function filtertable($query){
	$connect= mysqli_connect("localhost","root","","bloodbank");
	$filter_result=mysqli_query($connect,$query);
	return $filter_result;
}
	
	$db = mysqli_connect('localhost', 'root', '', 'bloodbank');

    $pe_id=$_GET['id'];
	
	$query="SELECT * FROM r_donner WHERE pe_id='".$pe_id."'";
    $search_result =filtertable($query);
    $rec=mysqli_fetch_array($search_result);
   
    $id=$rec['r_id'];
	
    $sql = "DELETE  FROM r_donner WHERE pe_id='".$pe_id."'";
	mysqli_query($db,$sql);
	 
   
	
	if($sql){ ?>
   <center>Successful<a href="user_request.php?id=<?php echo $id?>"><br>Return</br></a></center> 
   <?php }
	

?> 
