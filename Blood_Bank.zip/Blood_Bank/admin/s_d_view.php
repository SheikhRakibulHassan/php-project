  <?php
 
$db_name="bloodbank";
$host_username="root";
$host_password="";
$host="localhost";

   $query2="SELECT * FROM admin ";
	$search_result2 =filtertable($query2);
    $row = mysqli_fetch_array($search_result2);
    $name=$row['a_name'];
	$pas=$row['password'];
	$id=$row['a_id'];
	$div=$row['a_ocupation'];
	$em=$row['a_email'];
	$num=$row['a_number'];
	$gro=$row['a_blood_group'];
	$da=$row['d_birth'];
	$se=$row['a_sex'];
	
	$query="SELECT * FROM `a_r_donner` ";
    $search_result =filtertable($query);

function filtertable($query){
	$connect= mysqli_connect("localhost","root","","bloodbank");
	$filter_result=mysqli_query($connect,$query);
	return $filter_result;
}




?>
 <!DOCTYPE>
<html>
<head>
<title>Blood Bank</title>
 <link rel="icon" href="image/bicon.jpg" type="image/x-icon">
<link href="../css/style5.css" rel="stylesheet" type="text/css" />
</head>
<body>


<center><h1>Welcome <?php echo "$name";?> </h1> </center>

    <nav>
       <ul>
		<li><a  href="index.php">Home</a></li>
		<li><a  href="user_account2.php?id=<?php echo $row['id']?>">Profile</a></li>
        <li><a  href="s_view.php?id=<?php echo $id?>">View User</a></li>
        <li><a  href="s_d_view.php?id=<?php echo $id?>">View User Donation</a>
		<li><a  href="creating_organization.php?id=<?php echo $id?>">Organijation Account</a> </li>
		<li><a  href="organization_view.php?id=<?php echo $id?>">View Organijation Account</a> </li>
		<li><a  href="edit_admin.php?id=<?php echo $id?>">Edith Profile</a> </li>
	    <li><a  href="../index.php">Logout</a> </li> 
		</ul>
         
      </ul>
    </nav>




<article >	   
<center>
<h2>Donetion List</h2><br>
<table>
<tr>
      
      <th>Doner Id</th>
	  <th>Doner Name</th>
	  <th>Request Id</th>
      <th>Request Name</th>
      <th>Donation Date</th>
	  <th>Request Gender</th>
	  <th>Request Number</th>
	  <th>Request Location</th>
	  <th>Status</th>
	  <th>Donation Information</th>
	
     

</tr> 
<?php while($row=mysqli_fetch_array($search_result)){?>
<tr> 
<td> <?php echo $row['r_id'];?></td>
<td> <?php echo $row['r_name'];?></td>
<td> <?php echo $row['pe_id'];?></td>
<td> <?php echo $row['pe_name'];?></td>
<td> <?php echo $row['don_date'];?></td>
<td> <?php echo $row['pe_sex'];?></td>
<td> <?php echo $row['pe_number'];?></td>
<td> <?php echo $row['don_location'];?></td>
<?php if( "Accept" != $row['status']){?>
<td><a href='../connection/update_accpected.php?id=<?php echo $row['pe_id']?>'>Pending</a></td>
<?php } else {?>
<td><?php echo $row['status'];?></td>
<?php }?>
<td><a href='info_view.php?id=<?php echo $row['pe_id']?>'>Information Check</a></td>
</tr>
<?php }?>
</table></center>
</article >
</body>
</html>