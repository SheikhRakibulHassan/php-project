<?php
session_start();
$db_name="bloodbank";
$host_username="root";
$host_password="";
$host="localhost";

function filtertable($query){
	$connect= mysqli_connect("localhost","root","","bloodbank");
	$filter_result=mysqli_query($connect,$query);
	return $filter_result;
}


    $user_name=$_GET['id'];
	$_SESSION["id2"]= $user_name;
	$query2="SELECT * FROM admin ";
	$search_result2 =filtertable($query2);
    $row = mysqli_fetch_array($search_result2);
    $name=$row['a_name'];
	$pas=$row['password'];
	$id=$row['a_id'];
	$div=$row['a_ocupation'];
	$em=$row['a_email'];
	$num=$row['a_number'];
	$gro=$row['a_blood_group'];
	$da=$row['d_birth'];
	$se=$row['a_sex'];
	
 
   
?>
<!DOCTYPE>
<html>
<head>
<title>Blood Bank</title>
<link rel="icon" href="image/bicon.jpg" type="image/x-icon">
<link href="../css/style4.css" rel="stylesheet" type="text/css" />
<script>
    function PreviewImage(upname, prv_id) {
        var oFReader = new FileReader();
        oFReader.readAsDataURL(document.getElementsByName(upname)[0].files[0]);

        oFReader.onload = function (oFREvent) {
            document.getElementById(prv_id).src = oFREvent.target.result;
        };
    };
  
</script>
</head>
<body>


<center><h1>Welcome <?php echo "$name";?> </h1> </center>

  <nav>
       <ul>
		<li><a  href="index.php">Home</a></li>
		<li><a  href="user_account2.php?id=<?php echo $row['id']?>">Profile</a></li>
        <li><a  href="s_view.php?id=<?php echo $id?>">View User</a></li>
        <li><a  href="s_d_view.php?id=<?php echo $id?>">View User Donation</a>
		<li><a  href="creating_organization.php?id=<?php echo $id?>">Organijation Account</a> </li>
		<li><a  href="organization_view.php?id=<?php echo $id?>">View Organijation Account</a> </li>
		<li><a  href="edit_admin.php?id=<?php echo $id?>">Edith Profile</a> </li> 
	    <li><a  href="../index.php">Logout</a> </li> 
		</ul>
         
      </ul>
    </nav>
	
<article >
<center><form id="form_444844" class="appnitro"  method="POST" enctype="multipart/form-data" action="../connection/organization_insert.php";>
				
Organization Id:<br>
<input name="o_id" type="text" id="o_id" value="<?php echo uniqid();?>" readonly>
<br>
<br>
Organization Name:<br>
<input name="o_name" type="text" id="o_name"  required>
<br>
<br>
Organization Password:<br>
<input name="password" type="password" id="password" required>
<br>
<br>
Organization Email:<br>
<input name="o_email" type="email" id="o_email"  >
<br>
<br>
Organization Location:<br>
<input name="o_location" type="text" id="o_location"  required>
<br>
<br>
Organization Number:<br>
<input name="o_number" type="text" id="o_number"  pattern="\d{11}"  
       maxlength="11" required>
<br>
<br>
Organization Logo:<br>
<img id="logo_preview" src="../image/hunt-4.jpg" style="height:150px; width:150px; border:2px red solid;"><br><br>  
<input type="file" name="personal_image" id="personal_image" onchange="PreviewImage('personal_image', 'logo_preview')"> 
<br>
<input type="submit" name="Submit" value="Submit">

</form></center>
            
  </article >
 
</body>
</html>
	   



