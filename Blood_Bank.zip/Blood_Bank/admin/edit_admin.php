<?php
session_start();
$db_name="bloodbank";
$host_username="root";
$host_password="";
$host="localhost";

function filtertable($query){
	$connect= mysqli_connect("localhost","root","","bloodbank");
	$filter_result=mysqli_query($connect,$query);
	return $filter_result;
}


    $user_name=$_GET['id'];
	$_SESSION["id2"]= $user_name;
	$query2="SELECT * FROM admin ";
	$search_result2 =filtertable($query2);
    $row = mysqli_fetch_array($search_result2);
    $name=$row['a_name'];
	$pas=$row['password'];
	$id=$row['a_id'];
	$div=$row['a_ocupation'];
	$em=$row['a_email'];
	$num=$row['a_number'];
	$gro=$row['a_blood_group'];
	$da=$row['d_birth'];
	$se=$row['a_sex'];
	
 
   
?>
<!DOCTYPE>
<html>
<head>
<title>Blood Bank</title>
<link rel="icon" href="image/bicon.jpg" type="image/x-icon">
<link href="../css/style4.css" rel="stylesheet" type="text/css" />
</head>
<body>

<center><h1>Welcome <?php echo "$name";?> </h1> </center>

  <nav>
       <ul>
		<li><a  href="index.php">Home</a></li>
		<li><a  href="user_account2.php?id=<?php echo $row['id']?>">Profile</a></li>
        <li><a  href="s_view.php?id=<?php echo $id?>">View User</a></li>
        <li><a  href="s_d_view.php?id=<?php echo $id?>">View User Donation</a>
		<li><a  href="creating_organization.php?id=<?php echo $id?>">Organijation Account</a> </li>
		<li><a  href="organization_view.php?id=<?php echo $id?>">View Organijation Account</a> </li>
		<li><a  href="edit_admin.php?id=<?php echo $id?>">Edith Profile</a> </li>
	    <li><a  href="../index.php">Logout</a> </li> 
		</ul>
         
      </ul>
    </nav>
	
<article >
<center><form id="form_444844" class="appnitro"  method="POST" enctype="multipart/form-data" action="../connection/update_admin.php";>
				
Admin Id:<br>
<input name="a_id" type="text" id="a_id" value="<?php echo $id ?>" required>
<br>
<br>
Admin Name:<br>
<input name="a_name" type="text" id="a_name" value="<?php echo $name ?>" required>
<br>
<br>
Admin Email:<br>
<input name="a_email" type="text" id="a_email" value="<?php echo $em ?>" required>
<br>
<br>
Admin Number:<br>
<input name="a_number" type="number" id="a_number" value="<?php echo $num ?>" required>
<br>
<br>
Admin Ocupation:<br>
<input name="a_ocupation" type="text" id="o_ocupation" value="<?php echo $div ?>" required>
<br>
<br>
Admin Blood Group:<br>
<input name="a_blood_group" type="text" id="a_blood_group" value="<?php echo $gro ?>" required>
<br>
<br>
<input type="submit" name="Submit" value="Submit">

</form></center>
            
  </article >
 
</body>
</html>
	   



