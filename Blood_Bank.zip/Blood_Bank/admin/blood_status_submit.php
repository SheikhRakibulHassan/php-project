<?php
session_start();
$db_name="bloodbank";
$host_username="root";
$host_password="";
$host="localhost";

function filtertable($query){
	$connect= mysqli_connect("localhost","root","","bloodbank");
	$filter_result=mysqli_query($connect,$query);
	return $filter_result;
}


    $user_name=$_GET['id'];
	$_SESSION["id2"]= $user_name;
	$query2="SELECT * FROM admin ";
	$search_result2 =filtertable($query2);
    $row = mysqli_fetch_array($search_result2);
    $name=$row['a_name'];
	$pas=$row['password'];
	$id=$row['a_id'];
	$div=$row['a_ocupation'];
	$em=$row['a_email'];
	$num=$row['a_number'];
	$gro=$row['a_blood_group'];
	$da=$row['d_birth'];
	$se=$row['a_sex'];
	
	$user_name=$_GET['id'];

	$query="SELECT * FROM donner WHERE id='".$user_name."'";
	$search_result =filtertable($query);
    $rec = mysqli_fetch_array($search_result);
    $n_name=$rec['name'];
	$n_id=$rec['id'];
 
   
?>
<!DOCTYPE>
<html>
<head>
<title>Blood Bank</title>
<link rel="icon" href="image/bicon.jpg" type="image/x-icon">
<link href="../css/style4.css" rel="stylesheet" type="text/css" />
</head>
<body>

<center><h1>Welcome <?php echo "$name";?> </h1> </center>

    <nav>
       <ul>
		<li><a  href="index.php">Home</a></li>
		<li><a  href="user_account2.php?id=<?php echo $row['id']?>">Profile</a></li>
        <li><a  href="s_view.php?id=<?php echo $id?>">View User</a></li>
        <li><a  href="s_d_view.php?id=<?php echo $id?>">View User Donation</a>
		<li><a  href="creating_organization.php?id=<?php echo $id?>">Organijation Account</a> </li>
		<li><a  href="organization_view.php?id=<?php echo $id?>">View Organijation Account</a> </li>
		<li><a  href="edit_admin.php?id=<?php echo $id?>">Edith Profile</a> </li> 
	    <li><a  href="../index.php">Logout</a> </li> 
		</ul>
         
      </ul>
    </nav>
	
<article >
<center><form id="form_444844" class="appnitro"  method="POST" enctype="multipart/form-data" action="../connection/bloodreport_insert.php";>
				
Doner Id:<br>
<input name="d_id" type="text" id="d_id" value="<?php echo $n_id?>" required>
<br>
<br>
Doner Name:<br>
<input name="d_name" type="text" id="d_name" value="<?php echo $n_name?>"  required>
<br>
<br>
Syphilis Report:<br><select name="syphilis">
<option value="Positive">Positive</option>
<option value="Negative">Negative</option>
</select>
<br>
<br>
HBV Report:<br><select name="hbv">
<option value="Positive">Positive</option>
<option value="Negative">Negative</option>
</select>
<br>
<br>
HIV Report:<br><select name="hiv">
<option value="Positive">Positive</option>
<option value="Negative">Negative</option>
</select>
<br>
<br>
HCV Report:<br><select name="hcv">
<option value="Positive">Positive</option>
<option value="Negative">Negative</option>
</select>
<br>
<br>
HEV Report:<br><select name="hev">
<option value="Positive">Positive</option>
<option value="Negative">Negative</option>
</select>
<br>
<br>
HTLV Report:<br><select name="htlv">
<option value="Positive">Positive</option>
<option value="Negative">Negative</option>
</select>
<br>
<br>
Malaria Report:<br><select name="malaria">
<option value="Positive">Positive</option>
<option value="Negative">Negative</option>
</select>
<br>
<br>
<input type="submit" name="Submit" value="Submit">

</form></center>
            
  </article >
 
</body>
</html>
	   



