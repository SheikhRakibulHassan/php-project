<?php
	
	function filtertable($query){
	$connect= mysqli_connect("localhost","root","","bloodbank");
	$filter_result=mysqli_query($connect,$query);
	return $filter_result;
}
	
	$db = mysqli_connect('localhost', 'root', '', 'bloodbank');
	
	$query2="SELECT * FROM admin ";
	$search_result2 =filtertable($query2);
    $row = mysqli_fetch_array($search_result2);
    $name=$row['a_name'];
	$pas=$row['password'];
	$id=$row['a_id'];
	$div=$row['a_ocupation'];
	$em=$row['a_email'];
	$num=$row['a_number'];
	$gro=$row['a_blood_group'];
	$da=$row['d_birth'];
	$se=$row['a_sex'];

    $o_id=$_GET['id'];
	
    $sql = "DELETE  FROM organization WHERE o_id='".$o_id."'";
	$sql2 = "DELETE  FROM medical WHERE doner_id='".$o_id."'";
	$sql3 = "DELETE  FROM a_r_donner WHERE r_id='".$o_id."'";
	$sql4 =  "DELETE  FROM blood_quantity WHERE b_id='".$o_id."'";
	mysqli_query($db,$sql);
	mysqli_query($db,$sql2);
	mysqli_query($db,$sql3);
	mysqli_query($db,$sql4);
	 
   
	
	if($sql){ ?>
    <center>Successful<a href="organization_view.php?id=<?php echo $id?>"><br>Return</br></a></center>
   <?php }
	

?> 
