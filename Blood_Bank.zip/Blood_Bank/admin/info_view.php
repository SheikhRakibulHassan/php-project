 <?php
 
$db_name="bloodbank";
$host_username="root";
$host_password="";
$host="localhost";

function filtertable($query){
	$connect= mysqli_connect("localhost","root","","bloodbank");
	$filter_result=mysqli_query($connect,$query);
	return $filter_result;
}

    $pe_id=$_GET['id'];

   $query2="SELECT * FROM admin ";
	$search_result2 =filtertable($query2);
    $row = mysqli_fetch_array($search_result2);
    $name=$row['a_name'];
	$pas=$row['password'];
	$id=$row['a_id'];
	$div=$row['a_ocupation'];
	$em=$row['a_email'];
	$num=$row['a_number'];
	$gro=$row['a_blood_group'];
	$da=$row['d_birth'];
	$se=$row['a_sex'];
	
	$query3="SELECT * FROM `medical ";
    $search_result3 =filtertable($query3);


?>
 <!DOCTYPE>
<html>
<head>
<title>Blood Bank</title>
 <link rel="icon" href="image/bicon.jpg" type="image/x-icon">
<link href="../css/style5.css" rel="stylesheet" type="text/css" />
</head>
<body>


<center><h1>Welcome <?php echo "$name";?> </h1> </center>

   <nav>
       <ul>
		<li><a  href="index.php">Home</a></li>
		<li><a  href="user_account2.php?id=<?php echo $row['id']?>">Profile</a></li>
        <li><a  href="s_view.php?id=<?php echo $id?>">View User</a></li>
        <li><a  href="s_d_view.php?id=<?php echo $id?>">View User Donation</a>
		<li><a  href="creating_organization.php?id=<?php echo $id?>">Organijation Account</a> </li>
		<li><a  href="organization_view.php?id=<?php echo $id?>">View Organijation Account</a> </li>
		<li><a  href="edit_admin.php?id=<?php echo $id?>">Edith Profile</a> </li> 
	    <li><a  href="../index.php">Logout</a> </li> 
		</ul>
         
      </ul>
    </nav>




<article >	   
<center>
<h2>Donation Information</h2><br>
<table>
<tr>
      
      <th>Doner name</th>
	  <th>Doner Id</th>
	  <th>Patient Name</th>
	  <th>Patient Id</th>
      <th>Medical Name</th>
      <th>Doctor Name</th>
	  <th>Doctor Number </th>
	  <th>Doctor Email</th>
</tr> 
<?php while($rec=mysqli_fetch_array($search_result3)){ if($pe_id== $rec['patient_id']){?>
<tr> 
<td> <?php echo $rec['doner_name'];?></td>
<td> <?php echo $rec['doner_id'];?></td>
<td> <?php echo $rec['patient_name'];?></td>
<td> <?php echo $rec['patient_id'];?></td>
<td> <?php echo $rec['medical_name'];?></td>
<td> <?php echo $rec['doctor_name'];?></td>
<td> <?php echo $rec['doctor_number'];?></td>
<td> <?php echo $rec['doctor_email'];?></td>
</tr>
<?php }}?>
</table></center>
</article >
</body>
</html>