-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 17, 2019 at 05:03 AM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bloodbank`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `a_id` varchar(50) NOT NULL,
  `a_name` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `d_birth` varchar(50) NOT NULL,
  `a_email` varchar(50) NOT NULL,
  `a_number` varchar(50) NOT NULL,
  `a_sex` varchar(50) NOT NULL,
  `a_ocupation` varchar(50) NOT NULL,
  `a_blood_group` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`a_id`, `a_name`, `password`, `d_birth`, `a_email`, `a_number`, `a_sex`, `a_ocupation`, `a_blood_group`) VALUES
('0015', 'Sheikh Rakibul Hassan', '15103296', '19-05-1996', 'rh113980@yahoo.com', '+8801752063078', 'Male', 'CSE Engineer', 'B+');

-- --------------------------------------------------------

--
-- Table structure for table `a_r_donner`
--

CREATE TABLE `a_r_donner` (
  `r_id` varchar(50) NOT NULL,
  `r_name` varchar(50) NOT NULL,
  `pe_id` varchar(50) NOT NULL,
  `pe_name` varchar(59) NOT NULL,
  `don_date` date NOT NULL,
  `pe_sex` varchar(50) NOT NULL,
  `pe_number` varchar(50) NOT NULL,
  `don_location` varchar(50) NOT NULL,
  `b_group` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `a_r_donner`
--

INSERT INTO `a_r_donner` (`r_id`, `r_name`, `pe_id`, `pe_name`, `don_date`, `pe_sex`, `pe_number`, `don_location`, `b_group`, `status`) VALUES
('5c1d4c826f', 'Sheikh Rakibul Hassan', '5c1d4d6422ed8', 'Nayam', '2018-12-21', 'Male', '89887677878', 'cangotia, Dhaka.', 'A+', ''),
('5c1d4c826f', 'Sheikh Rakibul Hassan', '5c1d4d7bc6ebc', 'Barisal', '2018-09-21', 'Male', '89887677878', 'cangotia, Dhaka.', 'A+', 'Accept'),
('5c1d917b19670', 'Badhon Blood Bank', '5c1d4d917caa4', 'fewfs', '2019-12-21', 'Male', '89887677878', 'Gajipur, Dhaka.', 'A+', ''),
('5c1d917b19670', 'Badhon Blood Bank', '5c1d930c09620', 'Nazma', '2018-12-22', 'Female', '89887677878', 'Gajipur, Dhaka.', 'AB-', ''),
('5c1d917b19670', 'Badhon Blood Bank', '5c1d9400e2519', 'Nayam', '2018-12-22', 'Male', '89887677878', 'ghfkj, Dhaka.', 'AB-', ''),
('5c1d917b19670', 'Badhon Blood Bank', '5c1dd672461ff', 'Sojib Al Mamun', '2018-12-22', 'Male', '89887677878', 'Gajipur, Dhaka.', 'A+', '');

-- --------------------------------------------------------

--
-- Table structure for table `bloodstatus`
--

CREATE TABLE `bloodstatus` (
  `d_id` varchar(50) NOT NULL,
  `d_name` varchar(50) NOT NULL,
  `syphilis` varchar(100) NOT NULL,
  `hbv` varchar(59) NOT NULL,
  `hiv` varchar(50) NOT NULL,
  `hcv` varchar(50) NOT NULL,
  `hev` varchar(50) NOT NULL,
  `htlv` varchar(50) NOT NULL,
  `malaria` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bloodstatus`
--

INSERT INTO `bloodstatus` (`d_id`, `d_name`, `syphilis`, `hbv`, `hiv`, `hcv`, `hev`, `htlv`, `malaria`) VALUES
('5c1d4c826f', ' Sheikh Rakibul Hassan', 'Negative', 'Negative', 'Negative', ' Negative', 'Negative', 'Negative', 'Negative');

-- --------------------------------------------------------

--
-- Table structure for table `blood_quantity`
--

CREATE TABLE `blood_quantity` (
  `aaa` varchar(50) NOT NULL,
  `a` varchar(50) NOT NULL,
  `bbb` varchar(50) NOT NULL,
  `b` varchar(50) NOT NULL,
  `ooo` varchar(50) NOT NULL,
  `o` varchar(50) NOT NULL,
  `aabb` varchar(50) NOT NULL,
  `ab` varchar(50) NOT NULL,
  `b_id` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `blood_quantity`
--

INSERT INTO `blood_quantity` (`aaa`, `a`, `bbb`, `b`, `ooo`, `o`, `aabb`, `ab`, `b_id`) VALUES
('8', '9', '10', '12', '13', '10', '6', '9', '5c1d917b19670'),
('0', '0', '0', '0', '0', '0', '0', '0', '5c1d91a29585a'),
('0', '0', '0', '0', '0', '0', '0', '0', '5c1d91d6bab02');

-- --------------------------------------------------------

--
-- Table structure for table `donner`
--

CREATE TABLE `donner` (
  `id` varchar(10) NOT NULL,
  `name` varchar(50) NOT NULL,
  `password` varchar(10) NOT NULL,
  `division` varchar(50) NOT NULL,
  `email` varchar(30) NOT NULL,
  `location` varchar(100) NOT NULL,
  `c_number` varchar(20) NOT NULL,
  `b_group` varchar(10) NOT NULL,
  `l_date` date NOT NULL,
  `age` int(20) NOT NULL,
  `sex` varchar(50) NOT NULL,
  `status` varchar(10) NOT NULL,
  `image` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `donner`
--

INSERT INTO `donner` (`id`, `name`, `password`, `division`, `email`, `location`, `c_number`, `b_group`, `l_date`, `age`, `sex`, `status`, `image`) VALUES
('5c1d4c826f', 'Sheikh Rakibul Hassan', '15103296', 'Khulna', 'rh113980@gmail.com', 'Nowapara', '01752063078', 'A+', '2018-12-21', 23, 'Male', 'Accept', 'Capture.PNG'),
('5c1d4cbeaa', 'Sojib Al Mamun', '12345', 'Rajshahi', 'sojib@gmail.com', 'Ullapara', '01756097866', 'B+', '2018-12-21', 21, 'Male', 'Accept', '34088206_807423282789941_8301738532636983296_n.jpg'),
('5c1d4d0e9d', 'Jakaria ', '12345', 'Dhaka', 'dggd@gmail.com', 'Gajipur', '01986888888', 'A+', '2018-12-21', 21, 'Male', 'Accept', 'Capture1.PNG'),
('5c1d92c2df', 'Nurul Huda', '12345', 'Dhaka', 'dggd@gmail.com', 'Nowapara', '01752063078', 'A+', '2018-12-22', 28, 'Male', '', 'ChobiSits.png');

-- --------------------------------------------------------

--
-- Table structure for table `medical`
--

CREATE TABLE `medical` (
  `doner_name` varchar(50) NOT NULL,
  `doner_id` varchar(50) NOT NULL,
  `patient_name` varchar(50) NOT NULL,
  `patient_id` varchar(50) NOT NULL,
  `medical_name` varchar(50) NOT NULL,
  `doctor_name` varchar(50) NOT NULL,
  `doctor_number` varchar(50) NOT NULL,
  `doctor_email` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `medical`
--

INSERT INTO `medical` (`doner_name`, `doner_id`, `patient_name`, `patient_id`, `medical_name`, `doctor_name`, `doctor_number`, `doctor_email`) VALUES
('Sheikh Rakibul Hassan', '5c1d4c826f', 'Barisal', '5c1d4d7bc6ebc', 'Apolo Hospital', ' Dr. Masum Kumar', '22323424244', 'Kubra@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `organization`
--

CREATE TABLE `organization` (
  `o_id` varchar(50) NOT NULL,
  `o_name` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `o_email` varchar(50) NOT NULL,
  `o_location` varchar(50) NOT NULL,
  `o_number` varchar(50) NOT NULL,
  `img` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `organization`
--

INSERT INTO `organization` (`o_id`, `o_name`, `password`, `o_email`, `o_location`, `o_number`, `img`) VALUES
('5c1d917b19670', 'Badhon Blood Bank', '12345', 'Badhon@gmail.com', 'Dhaka', '01690453277', 'images34.jpg'),
('5c1d91a29585a', 'Shohan Blood Bank', '12345', 'shohan@gmail.com', 'Dhaka', '01879654322', 'images56.jpg'),
('5c1d91d6bab02', 'Rakib Blood Bank', '12345', 'Rakib@gmail.com', 'Dhaka', '01546878743', 'POTD_chick_3597497k.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `o_donner`
--

CREATE TABLE `o_donner` (
  `pe_id` varchar(50) NOT NULL,
  `p_name` varchar(50) NOT NULL,
  `p_division` varchar(50) NOT NULL,
  `p_email` varchar(50) NOT NULL,
  `p_location` varchar(50) NOT NULL,
  `p_number` varchar(50) NOT NULL,
  `p_b_group` varchar(50) NOT NULL,
  `p_date` date NOT NULL,
  `age` varchar(50) NOT NULL,
  `sex` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`a_id`);

--
-- Indexes for table `a_r_donner`
--
ALTER TABLE `a_r_donner`
  ADD PRIMARY KEY (`pe_id`);

--
-- Indexes for table `bloodstatus`
--
ALTER TABLE `bloodstatus`
  ADD PRIMARY KEY (`d_id`);

--
-- Indexes for table `blood_quantity`
--
ALTER TABLE `blood_quantity`
  ADD PRIMARY KEY (`b_id`);

--
-- Indexes for table `donner`
--
ALTER TABLE `donner`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `medical`
--
ALTER TABLE `medical`
  ADD PRIMARY KEY (`patient_id`);

--
-- Indexes for table `organization`
--
ALTER TABLE `organization`
  ADD PRIMARY KEY (`o_id`);

--
-- Indexes for table `o_donner`
--
ALTER TABLE `o_donner`
  ADD PRIMARY KEY (`pe_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
