
<!doctype html>
<html>
<title>Blood Bank</title>
 <link rel="icon" href="images/bicon.jpg" type="image/x-icon">
<style>
body {
    background-color:#FCFCFC;
    margin: 4px 4px;
   
}
ul{
    list-style-type: none;
    margin: 0;
    padding: 3 15;
    overflow: hidden;
    background-color: #3F6699;
	
}

li {
    float: left;
	margin:10px 3px;
}

li a {
    display: block;
    color: white;
	margin:0px 30px;
    text-align: center;
    padding: 10px 20px;
    text-decoration: none;
}

li a:hover {
    background-color: #111;

}

nav {
    
    background-color: #f2f2f2;
    margin:100px 250px;
  
}




input[type=text], input[type=password] {
    width: 100%;
    padding: 12px 50px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    box-sizing: border-box;
}

input[type=submit]{
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    width: 10%;
}


.imgcontainer {
    text-align: center;
    margin: 24px 0 12px 0;
}

img.avatar {
    width: 20%;
    border-radius: 10%;
}
table ,tr, td{
    border: 2px solid #f2f2f2;
    color: black;
	margin: 0px 200px;
text-decoration: none;
}
.dropbtn {
    background-color:  #3F6699;
    color: white;
    padding: 10px;
    font-size: 15px;
    border: none;
    cursor: pointer;
}

.dropdown {
  
    display: inline-block;
	margin:10px 0px;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #3F6699;
    min-width: 80px;
}

.dropdown-content a {
    color: white;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
}

.dropdown-content a:hover {background-color: Black}

.dropdown:hover .dropdown-content {
    display: block;
}

</style>
<center><img src="image/blood4.jpg" border="" alt="Logo" style="width:900px;height:140px;"></center>

      <h1 style="color:black;text-align: center;">Automated Blood Bank System</h1>
     <center> 
       <ul>
		<li><a  href="index.php">Home</a>
             <li><a  href="search.php">Search Donners</a></li>
              <li><a  href="Donner_reg.php">Register As Donor</a>
            <li><a  href="p_request.php">Request Blood</a> </li>
		   <li><a  href="eligibilty.php">Blood Tips</a> </li>
			<li><a  href="contact.php">Contact Us</a> </li>
		 <div class="dropdown">
            <button class="dropbtn">Login</button>
             <div class="dropdown-content">
                    
                 <a href="login.php">Donor</a>
                 <a href="login2.php">Admin</a>
                  <a href="login3.php">Organization</a>
                   </div> 
				
			</ul>
         
      </ul></center>

<nav><center><h2>Organization Login</h2></center>
<form action="organization/organization_account.php" method="post">
<nav class="imgcontainer">
    <img src="image/login.png" style="width:300px;height:200px;" alt="Avatar" class="avatar">
<table>

<body>
<tr>
<td ><b>Organization Name</b></td>
<td><b>:</b></td>
<td > <input name="user_name" type="text"></td>
</tr>
</body>
<body>
<tr>
<td ><b>Password</b></td>
<td><b>:</b></td>
<td > <input name="password" type="password"></td>
</tr>
</body>


</table>
<input type="submit"name="submit"value="submit">
</form></nav></center>
</html>
