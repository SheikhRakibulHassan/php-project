<?php


    function filtertable($query){
	$connect= mysqli_connect("localhost","root","","bloodbank");
	$filter_result=mysqli_query($connect,$query);
	return $filter_result;
    }
	
	$query2="SELECT * FROM admin ";
	$search_result2 =filtertable($query2);
    $row = mysqli_fetch_array($search_result2);
    $name=$row['a_name'];
	$pas=$row['password'];
	$id=$row['a_id'];
	$div=$row['a_ocupation'];
	$em=$row['a_email'];
	$num=$row['a_number'];
	$gro=$row['a_blood_group'];
	$da=$row['d_birth'];
	$se=$row['a_sex'];
	
	
		// connect to the database
	$db = mysqli_connect('localhost', 'root', '', 'bloodbank');

	// if register button is clicked

	if(isset($_POST['Submit'])){
		
    $id= $_POST['o_id'];
    $name=$_POST['o_name'];
    $password=trim($_POST['password']);
    $email=$_POST['o_email'];
    $location=$_POST['o_location'];
    $number=$_POST['o_number'];
	
	$image = $_FILES['personal_image']['name'];
	$target = "images/".basename($image);
	
	move_uploaded_file($_FILES['personal_image']['tmp_name'], $target);
	
    
    $sql = "INSERT INTO organization (o_id,o_name,password,o_email,o_location,o_number,img) VALUES ('$id', '$name', '$password', '$email', '$location', '$number','$image')";
	mysqli_query($db,$sql);
	$sql2 = "INSERT INTO blood_quantity (b_id,aaa,a,bbb,b,ooo,o,aabb,ab) VALUES ('$id', '0', '0', '0', '0', '0','0','0','0')"; 
	mysqli_query($db,$sql2);
	if($sql){?>
   <center>Successful<a href="../admin/creating_organization.php?id=<?php echo $id?>"><br>Return</br></a></center>
   <?php	
	}
	
	}
	?> 
