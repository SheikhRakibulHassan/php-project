<?php
	$username = "";
	$email = "";
	$errors = array();
		// connect to the database
	$db = mysqli_connect('localhost', 'root', '', 'bloodbank');

	// if register button is clicked

	if(isset($_POST['Submit'])){
		
    $aa= $_POST['did'];
    $c=$_POST['dn'];
    $cc=$_POST['ddd'];
    $name=$_POST['email'];
    $bl=$_POST['area'];
    $am=$_POST['cno'];
    $da=$_POST['bgrp'];
    $q=$_POST['date'];
    $qqq=$_POST['bbb'];
    $s=$_POST['sex'];
	$pas=trim($_POST['dnnd']);
	$passw=trim($_POST['dnndd']);
	
	$image = $_FILES['personal_image']['name'];
	$target = "images/".basename($image);
	
	move_uploaded_file($_FILES['personal_image']['tmp_name'], $target);
	if($pas == $passw)
    {
    
    $sql = "INSERT INTO donner (id,name,password,division, email,location,c_number,b_group,l_date,age,sex,image) VALUES ('$aa', '$c', '$pas', '$cc', '$name', '$bl', '$am', '$da', '$q', '$qqq', '$s','$image')";
	mysqli_query($db,$sql);
	 
	
	if($sql){
    echo "<center><h1>Successful</b><a href='../Donner_reg.php'><br>Add Another</br></a></center>";
    echo "<BR>";
    }
	else {
    echo "<center><h1>problem occuer</b><a href='../Donner_reg.php'><br>Solved</br></a></center>";
    }	
	
    }
    else {
    echo "<center><h1>Password is not match</b><a href='../Donner_reg.php'><br>Correct password</br></a></center>";
    }	

	}
?> 
