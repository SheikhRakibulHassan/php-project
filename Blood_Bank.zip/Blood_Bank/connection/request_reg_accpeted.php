<?php
	$db = mysqli_connect('localhost', 'root', '', 'bloodbank');

	// if register button is clicked

	if(isset($_POST['Submit'])){
		
    $aa= $_POST['doner_id'];
    $c=$_POST['doner_name'];
    $cc=$_POST['person_id'];
    $name=$_POST['person_name'];
    $bl=$_POST['d_date'];
    $am=$_POST['sex'];
    $da=$_POST['Contact'];
    $q=$_POST['Location'];
    
	$sql = "INSERT INTO a_r_donner (r_id,r_name,pe_id,pe_name,don_date,pe_sex,pe_number,don_location) VALUES ('$aa', '$c', '$cc','$name', '$bl', '$am', '$da', '$q')";
	mysqli_query($db,$sql);
	 
	 
    $sql2 = "DELETE  FROM r_donner WHERE pe_id='".$cc."'";
	mysqli_query($db,$sql2);
	
	if($sql && $sql2){?>
    <center>Successful<a href="../user_request.php?id=<?php echo $aa?>"><br>Return</br></a></center>
    <?php
    }	
	
    	

	}
?> 
