<?php
	$db = mysqli_connect('localhost', 'root', '', 'bloodbank');

	// if register button is clicked
function filtertable($query){
	$connect= mysqli_connect("localhost","root","","bloodbank");
	$filter_result=mysqli_query($connect,$query);
	return $filter_result;
}
	
	
	
	if(isset($_POST['Submit'])){
		
    $aa= $_POST['doner_id'];
    $c=$_POST['doner_name'];
    $cc=$_POST['person_id'];
    $name=$_POST['person_name'];
    $bl=$_POST['d_date'];
    $am=$_POST['sex'];
    $da=$_POST['Contact'];
    $q=$_POST['Location'];
	$b_group=$_POST['b_group'];
    
	$sql = "INSERT INTO a_r_donner (r_id,r_name,pe_id,pe_name,don_date,pe_sex,pe_number,don_location,b_group) VALUES ('$aa', '$c', '$cc','$name', '$bl', '$am', '$da', '$q','$b_group')";
	mysqli_query($db,$sql);
	
	$query="select * from blood_quantity WHERE b_id='$aa' ";
    $search_result =filtertable($query);
	$row=mysqli_fetch_array($search_result);
	if($b_group=="A+"){
		$amount=$row['aaa'];
		$amount2=$amount-1;
		$sql4 = "UPDATE blood_quantity set aaa='$amount2' where b_id='$aa'";
		mysqli_query($db,$sql4);
	}
		if($b_group=="A-"){
		$amount=$row['a'];
		$amount2=$amount-1;
		$sql4 = "UPDATE blood_quantity set a='$amount2' where b_id='$aa'";
		mysqli_query($db,$sql4);
	}
	if($b_group=="B+"){
		$amount=$row['bbb'];
		$amount2=$amount-1;
		$sql4 = "UPDATE blood_quantity set bbb='$amount2' where b_id='$aa'";
		mysqli_query($db,$sql4);
	}
	if($b_group=="B-"){
		$amount=$row['b'];
		$amount2=$amount-1;
		$sql4 = "UPDATE blood_quantity set b='$amount2' where b_id='$aa'";
		mysqli_query($db,$sql4);
	}
	if($b_group=="O+"){
		$amount=$row['ooo'];
		$amount2=$amount-1;
		$sql4 = "UPDATE blood_quantity set ooo='$amount2' where b_id='$aa'";
		mysqli_query($db,$sql4);
	}
		if($b_group=="O-"){
		$amount=$row['aaa'];
		$amount2=$amount-1;
		$sql4 = "UPDATE blood_quantity set aaa='$amount2' where b_id='$aa'";
		mysqli_query($db,$sql4);
	}
	if($b_group=="AB+"){
		$amount=$row['aabb'];
		$amount2=$amount-1;
		$sql4 = "UPDATE blood_quantity set aabb='$amount2' where b_id='$aa'";
		mysqli_query($db,$sql4);
	}
	if($b_group=="AB-"){
		$amount=$row['ab'];
		$amount2=$amount-1;
		$sql4 = "UPDATE blood_quantity set ab='$amount2' where b_id='$aa'";
		mysqli_query($db,$sql4);
	}
	 
    $sql2 = "DELETE  FROM o_donner WHERE pe_id='".$cc."'";
	mysqli_query($db,$sql2);
	
	if($sql && $sql2){?>
    <center>Successful<a href="../organization/blood_quanty_view.php?id=<?php echo $aa?>"><br>Return</br></a></center>
    <?php
    }	
	
    	

	}
?> 
