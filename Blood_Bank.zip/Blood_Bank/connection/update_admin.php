<?php
	$username = "";
	$email = "";
	$errors = array();
		// connect to the database
	$db = mysqli_connect('localhost', 'root', '', 'bloodbank');

	// if register button is clicked

	if(isset($_POST['Submit'])){
		
    $admin_id= $_POST['a_id'];
    $admin_name=$_POST['a_name'];
    $admin_email=$_POST['a_email'];
    $admin_number=$_POST['a_number'];
    $admin_ocupation=$_POST['a_ocupation'];
    $admin_b_group=$_POST['a_blood_group'];
    
    $sql2 = "UPDATE admin set a_name='$admin_name',a_email='$admin_email',a_number='$admin_number',a_ocupation='$admin_ocupation',a_blood_group='$admin_b_group' where a_id='$admin_id'";
	mysqli_query($db,$sql2);
	 
	
	if($sql2){?>
	<center><h1>Successful</b><a href="../admin/user_account2.php?id=<?php echo $admin_id ?>"><br>Return</br></a></center>
   
   <?php }
	}
	
    
?> 
