<?php
	session_start();
	$db = mysqli_connect('localhost', 'root', '', 'bloodbank');
	
    
	// if register button is clicked

	if(isset($_POST['Submit'])){
		
	$user_id=$_SESSION["id2"];
	
    $name= $_POST['name'];
    $division=$_POST['division'];
    $email=$_POST['email'];
    $location=$_POST['location'];
    $c_number=$_POST['c_number'];
    $b_group=$_POST['b_group'];
    $age=$_POST['age'];
	
    
    $sql = "UPDATE  donner set name='$name', division='$division',email='$email', location='$location', c_number='$c_number', b_group='$b_group' , age='$age' where id='$user_id'";
	mysqli_query($db,$sql);
	 
	
	if($sql){?>
    <center><h1>Successful</b><a href="../user/edit_user_account.php?id=<?php echo $user_id ;?>"><br>Return</br></a></center>
    <?php
	}
	
   
	}
?> 
