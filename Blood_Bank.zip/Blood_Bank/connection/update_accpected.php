<?php
	session_start();
	$db = mysqli_connect('localhost', 'root', '', 'bloodbank');
	
    
	// if register button is clicked
	$id=$_GET['id'];
    $status= "Accept";
    
    $sql = "UPDATE a_r_donner set status='$status' where pe_id='$id'";
	mysqli_query($db,$sql);
	 
	
	if($sql){?>
    <center><h1>Successful</b><a href="../admin/s_d_view.php"><br>Return</br></a></center>
    <?php
	}
	
   
?> 
