<?php
	$username = "";
	$email = "";
	$errors = array();
		// connect to the database
	$db = mysqli_connect('localhost', 'root', '', 'bloodbank');

	// if register button is clicked

	if(isset($_POST['Submit'])){
		
    $organization_id= $_POST['o_id'];
    $organization_name=$_POST['o_name'];
    $organization_email=$_POST['o_email'];
    $organization_number=$_POST['o_number'];
    $organization_location=$_POST['o_location'];
    
    $sql2 = "UPDATE organization set o_name='$organization_name',o_email='$organization_email',o_number='$organization_number',o_location='$organization_location' where o_id='$organization_id'";
	mysqli_query($db,$sql2);
	 
	
	if($sql2){?>
	<center><h1>Successful</b><a href="../organization/organization_account2.php?id=<?php echo $organization_id ?>"><br>Return</br></a></center>
   
   <?php }
	}
	
    
?> 
