<?php
	$username = "";
	$email = "";
	$errors = array();
		// connect to the database
	$db = mysqli_connect('localhost', 'root', '', 'bloodbank');

	// if register button is clicked

	if(isset($_POST['Submit'])){
		
    $aa= $_POST['did'];
    $c=$_POST['dn'];
    $cc=$_POST['ddd'];
    $name=$_POST['email'];
    $bl=$_POST['area'];
    $am=$_POST['cno'];
    $da=$_POST['bgrp'];
    $q=$_POST['date'];
    $qqq=$_POST['bbb'];
    $s=$_POST['sex'];
  
    $sql = "INSERT INTO r_donner (r_id,r_name,pe_id,name,location,c_number,b_group,r_date,age,sex) VALUES ('$aa','$c','$cc','$name', '$bl', '$am', '$da', '$q', '$qqq', '$s')";
	mysqli_query($db,$sql);
	 
	
	if($sql){
    echo "<center><h1>Successful</b><a href='../search.php'><br>Add Another</br></a></center>";
    echo "<BR>";
    
    }

    else {
    echo "ERROR";
    }	

	}
?> 
