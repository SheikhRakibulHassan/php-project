<?php
	session_start();
	$db = mysqli_connect('localhost', 'root', '', 'bloodbank');
	
    
	// if register button is clicked
	$id=$_GET['id'];
    $status= "Accept";
    
    $sql = "UPDATE donner set status='$status' where id='$id'";
	mysqli_query($db,$sql);
	 
	
	if($sql){?>
    <center><h1>Successful</b><a href="../admin/s_view.php"><br>Return</br></a></center>
    <?php
	}
	
   
?> 
