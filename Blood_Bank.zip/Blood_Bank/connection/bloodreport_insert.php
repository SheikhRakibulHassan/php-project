<?php
	function filtertable($query){
	$connect= mysqli_connect("localhost","root","","bloodbank");
	$filter_result=mysqli_query($connect,$query);
	return $filter_result;
    }
	
		// connect to the database
	$db = mysqli_connect('localhost', 'root', '', 'bloodbank');

	// if register button is clicked

	if(isset($_POST['Submit'])){
		
    $doner_id= $_POST['d_id'];
    $doner_name=$_POST['d_name'];
    $syphilis=$_POST['syphilis'];
    $hbv=$_POST['hbv'];
    $hiv=$_POST['hiv'];
    $hcv=$_POST['hcv'];
    $hev=$_POST['hev'];
    $htlv=$_POST['htlv'];
	$malaria=$_POST['malaria'];
	
	
    
	$query2="SELECT * FROM bloodstatus ";
	$search_result2 =filtertable($query2);
    while($row=mysqli_fetch_array($search_result2)){ if($doner_id == $row['d_id']){$id=$doner_id;}}
	if($doner_id == $id){	
    $sql2 = "UPDATE bloodstatus set syphilis='$syphilis',hbv='$hbv',hiv='$hiv',hcv='$hcv',hev='$hev',htlv='$htlv',malaria='$malaria' where d_id='$doner_id'";
	mysqli_query($db,$sql2);
	if($sql2){?>
	<center><h1>Successful</b><a href="../admin/blood_status_submit.php?id=<?php echo $doner_id ?>"><br>Return</br></a></center>
   
	<?php }}else{
    
    $sql = "INSERT INTO bloodstatus (d_id,d_name,syphilis,hbv,hiv,hcv,hev,htlv,malaria) VALUES ('$doner_id', ' $doner_name', '$syphilis', '$hbv', '$hiv', ' $hcv', '$hev', '$htlv', '$malaria')";
	mysqli_query($db,$sql);
	 
	
	if($sql){?>
	<center><h1>Successful</b><a href="../admin/blood_status_submit.php?id=<?php echo $doner_id ?>"><br>Return</br></a></center>
   
	<?php }}
	}
	
    
?> 
