<?php
	$username = "";
	$email = "";
	$errors = array();
		// connect to the database
	$db = mysqli_connect('localhost', 'root', '', 'bloodbank');

	// if register button is clicked

	if(isset($_POST['Submit'])){
		
    $doner_name= $_POST['name'];
    $doner_id=$_POST['d_id'];
    $patient_name=$_POST['p_name'];
    $patient_id=$_POST['p_id'];
    $medical_name=$_POST['medical'];
    $doctor_name=$_POST['doctor'];
    $doctor_number=$_POST['d_number'];
    $doctor_email=$_POST['d_email'];
    
	
	
    
    $sql = "INSERT INTO medical (doner_name,doner_id,patient_name,patient_id,medical_name,doctor_name,doctor_number,doctor_email) VALUES ('$doner_name', '$doner_id', '$patient_name', '$patient_id', '$medical_name', ' $doctor_name', '$doctor_number', '$doctor_email')";
	mysqli_query($db,$sql);
	 
	
	if($sql){?>
	<center><h1>Successful</b><a href="../user/view_accpect_request.php?id=<?php echo $doner_id ?>"><br>Return</br></a></center>
   
   <?php }
	}
	
    
?> 
