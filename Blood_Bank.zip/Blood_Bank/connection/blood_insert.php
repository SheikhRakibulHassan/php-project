<?php


    function filtertable($query){
	$connect= mysqli_connect("localhost","root","","bloodbank");
	$filter_result=mysqli_query($connect,$query);
	return $filter_result;
    }
	
	
	
	
		// connect to the database
	$db = mysqli_connect('localhost', 'root', '', 'bloodbank');

	// if register button is clicked

	if(isset($_POST['Submit'])){
		
    $id= $_POST['b_id'];
    $aaa=$_POST['aaa'];
    $a=$_POST['a'];
    $bbb=$_POST['bbb'];
    $b=$_POST['b'];
    $ooo=$_POST['ooo'];
	$o=$_POST['o'];
	$aabb=$_POST['aabb'];
    $ab=$_POST['ab'];
	
	
	
    
    $sql = "UPDATE  blood_quantity set aaa='$aaa', a='$a',bbb='$bbb', b='$b',ooo='$ooo', o='$o' , aabb='$aabb',ab='$ab' where b_id='$id'";
	mysqli_query($db,$sql);
	 
	
	if($sql){?>
   <center>Successful<a href="../organization/blood_quanty_view.php?id=<?php echo $id?>"><br>Return</br></a></center>
   <?php	
	}
	
	}
	?> 
