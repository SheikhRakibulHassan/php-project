 <!DOCTYPE>
<html>
<head>
<title>Blood Bank</title>
 <link rel="icon" href="image/bicon.jpg" type="image/x-icon">
<link href="css/style.css" rel="stylesheet" type="text/css" />
</head>
<body>

<center><img src="image/blood4.jpg" border="" alt="Logo" style="width:900px;height:140px;"></center>

      <h1 style="color:black;text-align: center;">Automated Blood Bank System</h1>
     <center> 
       <ul>
		<li><a  href="index.php">Home</a>
             <li><a  href="search.php">Search Donners</a></li>
              <li><a  href="Donner_reg.php">Register As Donor</a>
           <li><a  href="p_request.php">Request Blood</a> </li>
		   <li><a  href="eligibilty.php">Blood Tips</a> </li>
			<li><a  href="contact.php">Contact Us</a> </li>
		 <div class="dropdown">
            <button class="dropbtn">Login</button>
             <div class="dropdown-content">
                    
                 <a href="login.php">Donor</a>
                 <a href="login2.php">Admin</a>
                 <a href="login3.php">Organization</a>
                   </div> 
				
			</ul>
         
      </ul></center>


	   



<center><nav><form id="form_444844" class="appnitro"  method="POST" action="connection/request_reg_c.php";>
				
<h3>Application for Blood Donner</h3>
<h3>Note: If your live in Bangladesh then only Request</h3>
<h4>
Persone Id:<br>
<input name="did" type="text" id="did"  value="<?php echo uniqid();?>" readonly >
<br>
<br>
Persone Name:<br>
<input name="dn" type="text" id="dn" required>
<br>
<br>
Division:<br><select name="ddd" >
<option value="Dhaka">Dhaka</option>
<option value="Sylhet">Sylhet</option>
<option value="Mymensingh">Mymensingh</option>
<option value="Chittagong">Chittagong</option>
<option value="Barisal">Barisal</option>
<option value="Khulna">Khulna</option>
<option value="Rajshahi">Rajshahi</option>
<option value="Rangpur">Rangpur</option>
</select>
<br>
<br>
Email Id:<br>
<input name="email" type="email" id="email">
<br>
<br>
Location:<br >
<input name="area" type="text" id="area" required>
<br>
<br>
Contact Number:<br>
<input name="cno" type="text" id="cno"   pattern="\d{11}"  
       maxlength="11" required>
<br>
<br>
Blood group:<br><select name="bgrp" required>
<option value="A+">A+</option>
<option value="A-">A-</option>
<option value="B+">B+</option>
<option value="B-">B-</option>
<option value="O+">O+</option>
<option value="O-">O-</option>
<option value="AB+">AB+</option>
<option value="AB-">AB-</option>
</select>
<br>
<br>
Blood Request Date:<br>
<input name="date" type="date" value="<?php echo date('Y-m-d'); ?>" id="date" readonly="">
<br>
<br>
Age:<br>
<input name="bbb" type="text" id="bgrp">
<br>
<br>
Sex:<br>
<input value= "Male" name="sex" type="checkbox" id="sex">Male
<input value= "Female" name="sex" type="checkbox" id="sex">Female
<input value= "Others" name="sex" type="checkbox" id="sex">Others
<br>
<br>
</h4>
<input type="submit" name="Submit" value="Submit">

</form></nav></center>


</body>
</html>
