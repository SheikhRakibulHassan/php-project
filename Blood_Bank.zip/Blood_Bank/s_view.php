 <?php
 
$db_name="bloodbank";
$host_username="root";
$host_password="";
$host="localhost";

if (isset($_POST['search'])){
	
	$da=$_POST['did'];
	$daa=$_POST['dn'];
	$query="SELECT * FROM `donner` WHERE b_group='$da' and division='$daa'";
    $search_result =filtertable($query);
	}

function filtertable($query){
	$connect= mysqli_connect("localhost","root","","bloodbank");
	$filter_result=mysqli_query($connect,$query);
	return $filter_result;
}




?>
 <!DOCTYPE>
<html>
<head>
<title>Blood Bank</title>
 <link rel="icon" href="image/bicon.jpg" type="image/x-icon">
<link href="css/style.css" rel="stylesheet" type="text/css" />
</head>
<body>


<center><img src="image/blood4.jpg" border="" alt="Logo" style="width:900px;height:140px;"></center>

      <h1 style="color:black;text-align: center;">Automated Blood Bank System</h1>
     <center> 
       <ul>
		<li><a  href="index.php">Home</a>
             <li><a  href="search.php">Search Donners</a></li>
              <li><a  href="Donner_reg.php">Register As Donor</a>
            <li><a  href="p_request.php">Request Blood</a> </li>
		   <li><a  href="eligibilty.php">Blood Tips</a> </li>
			<li><a  href="contact.php">Contact Us</a> </li>
		 <div class="dropdown">
            <button class="dropbtn">Login</button>
             <div class="dropdown-content">
                    
                 <a href="login.php">Donor</a>
                 <a href="login2.php">Admin</a>
                 <a href="login3.php">Organization</a>
                   </div> 
				
			</ul>
         
      </ul></center>


</body>
</html>
	   
<center>
<h2>Result of your search</h2>
<table>
<tr>
      
      <th>ID</th>
	  <th>Name</th>
      <th>Division</th>
      <th>Location</th>
	  <th>Blood Group</th>
      <th>Last Date Of Donation</th>
      <th>Age</th>  
      <th>Sex</th>
	  <th>Picture</th>
	  <th>Request Bar</th>
     

</tr> 
<?php while($row=mysqli_fetch_array($search_result)){?>
<tr> 
<td> <?php echo $row['id'];?></td>
<td> <?php echo $row['name'];?></td>
<td> <?php echo $row['division'];?></td>
<td> <?php echo $row['location'];?></td>
<td> <?php echo $row['b_group'];?></td>
<td> <?php echo $row['l_date'];?></td>
<td> <?php echo $row['age'];?></td>
<td> <?php echo $row['sex'];?></td>
<td>
    <img id="logo_preview" src="connection/images/<?php echo $row['image'];?>" style="height:50px; width:50px; border:1px green solid;">
    </td>
<td><a href='user_blood_status.php?id=<?php echo $row['id']?>'>Blood Status</a></td>
</tr>
<?php }?>
</table></center>




