<?php
$db_name="bloodbank";
$host_username="root";
$host_password="";
$host="localhost";

function filtertable($query){
	$connect= mysqli_connect("localhost","root","","bloodbank");
	$filter_result=mysqli_query($connect,$query);
	return $filter_result;
}

if(isset($_POST["submit"])){

if(!empty($_POST['user_name']) && !empty($_POST['password'])) {
	$user_name=$_POST['user_name'];
	$password=$_POST['password'];
	
	$query2="SELECT * FROM organization WHERE o_name='".$user_name."' AND password='".$password."'";
	$search_result2 =filtertable($query2);
    $row = mysqli_fetch_array($search_result2);
	$id=$row['o_id'];
    $name=$row['o_name'];
	$pas=$row['password'];
	$em=$row['o_email'];
	$loc=$row['o_location'];
	$num=$row['o_number'];
if( ($name==$name) &&($password==$pas)){
	
?>
<!DOCTYPE>
<html>
<head>
<title>Blood Bank</title>
<link rel="icon" href="image/bicon.jpg" type="image/x-icon">
<link href="../css/style2.css" rel="stylesheet" type="text/css" />
</head>
<body>

<div class="header">
 <a href='login.php'><img ' class="img-1" src="../connection/images/<?php echo $row['img'];?>" ></a>
</div>
<center><h1>Welcome <?php echo "$name";?> </h1> </center>

   
    <nav>
       <ul>
		<li><a  href="home/index.php">Home</a></li>
		<li><a  href="organization_account2.php?id=<?php echo $id;?>">Profile</a></li>
        <li><a  href="blood_quanty_view.php?id=<?php echo $id?>">Blood Quantity View</a>
		<li><a  href="select_pending_Request.php?id=<?php echo $id?>">Pending Request</a> </li>
		<li><a  href="view_accpect_request.php?id=<?php echo $id?>">View Accepted Request</a></li>
	    <li><a  href="edit_organization.php?id=<?php echo $id?>">Edit Account</a> </li> 
	    <li><a  href="../index.php">Logout</a> </li> 
		</ul>
         
      </ul>
    </nav>
	
<article >
<center>
<table>
<h2>Basic Information</h2>

<tr>
      <td>Organization Name</td>
      <td><?php echo "$name";?></td>
</tr>

<tr>
      <td>Organization Number</td>
      <td><?php echo "$num";?></td>
</tr>

<tr>
      <td>Email Address</td>
      <td><?php echo "$em";?></td>
</tr>

<tr>
      <td>Organization Id</td>
      <td><?php echo "$id";?></td>
</tr>
 
<tr>
      <td>Password</td>
      <td><a href='login.php'>Change password</a></td>
</tr>
<tr>
      <td>Organization Location</td>
      <td><?php echo "$loc.";?></td>
</tr>

</table >
</center>
             
</article >
 
</body>
</html>
	   
<?php 
}

else{
	 echo "<center><h1>Wrong Password or Name</b><a href='../login3.php'><br>check</br></a></center>";;
}

}
else{
	 echo "<center><h1>Make sure Name or Passwoed not empty</b><a href='../login3.php'><br>check</br></a></center>";;
}
}?>


