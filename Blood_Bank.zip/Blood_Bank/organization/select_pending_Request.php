  <?php
session_start();
$db_name="bloodbank";
$host_username="root";
$host_password="";
$host="localhost";

    $user_name=$_GET['id'];
	$_SESSION["id3"]=$user_name;
  
	$query="SELECT * FROM organization WHERE o_id='".$user_name."'";
	$search_result =filtertable($query);
    $row = mysqli_fetch_array($search_result);
	$id=$row['o_id'];
    $name=$row['o_name'];
	$pas=$row['password'];
	$em=$row['o_email'];
	$loc=$row['o_location'];
	$num=$row['o_number'];
	
	$query="SELECT * FROM `blood_quantity`WHERE b_id='".$user_name."' ";
    $search_result =filtertable($query);

function filtertable($query){
	$connect= mysqli_connect("localhost","root","","bloodbank");
	$filter_result=mysqli_query($connect,$query);
	return $filter_result;
}




?>
 <!DOCTYPE>
<html>
<head>
<title>Blood Bank</title>
 <link rel="icon" href="image/bicon.jpg" type="image/x-icon">
<link href="../css/style5.css" rel="stylesheet" type="text/css" />
</head>
<body>

<div class="header">
 <a href='login.php'><img ' class="img-1" src="../connection/images/<?php  echo $row['img'];?>" ></a>
</div>

<center><h1>Welcome <?php echo "$name";?> </h1> </center>

 
     <nav>
       <ul>
		<li><a  href="home/index.php">Home</a></li>
		<li><a  href="organization_account2.php?id=<?php echo $id;?>">Profile</a></li>
        <li><a  href="blood_quanty_view.php?id=<?php echo $id?>">Blood Quantity View</a>
		<li><a  href="select_pending_Request.php?id=<?php echo $id?>">Pending Request</a> </li>
		<li><a  href="view_accpect_request.php?id=<?php echo $id?>">View Accepted Request</a></li>
	    <li><a  href="edit_organization.php?id=<?php echo $id?>">Edit Account</a> </li> 
	    <li><a  href="../index.php">Logout</a> </li> 
		</ul>
         
      </ul>
    </nav>




<article >	   
<center><form id="form_444844" class="appnitro"  method="POST" action="pending_request.php";>
				
<h3>Search Blood Request According Blood Group </h3>
<br>
Blood Group:<br><select name="did">
<option value="A+">A+</option>
<option value="A-">A-</option>
<option value="B+">B+</option>
<option value="B-">B-</option>
<option value="O+">O+</option>
<option value="O-">O-</option>
<option value="AB+">AB+</option>
<option value="AB-">AB-</option>
</select>
<br>
<br>
<input type="submit" name="search" value="Search">

</form></center>
</article >
</body>
</html>