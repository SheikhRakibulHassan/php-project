<?php
$db_name="bloodbank";
$host_username="root";
$host_password="";
$host="localhost";

function filtertable($query){
	$connect= mysqli_connect("localhost","root","","bloodbank");
	$filter_result=mysqli_query($connect,$query);
	return $filter_result;
}


	$user_name=$_GET['id'];
	
	$query="SELECT * FROM organization WHERE o_id='".$user_name."'";
	$search_result =filtertable($query);
    $row = mysqli_fetch_array($search_result);
	$id=$row['o_id'];
    $name=$row['o_name'];
	$pas=$row['password'];
	$em=$row['o_email'];
	$loc=$row['o_location'];
	$num=$row['o_number'];
    
	$sql="SELECT * FROM blood_quantity WHERE b_id='".$user_name."'";
	$search=filtertable($sql);
	$rtt = mysqli_fetch_array($search);
	$aaa=$rtt['aaa'];
	$a=$rtt['a'];
	$bbb=$rtt['bbb'];
	$b=$rtt['b'];
	$ccc=$rtt['ooo'];
	$c=$rtt['o'];
	$aabb=$rtt['aabb'];
	$ab=$rtt['ab'];
	
?>
<!DOCTYPE>
<html>
<head>
<title>Blood Bank</title>
<link rel="icon" href="image/bicon.jpg" type="image/x-icon">
<link href="../css/style4.css" rel="stylesheet" type="text/css" />
</head>
<body>

<div class="header">
 <a href='login.php'><img ' class="img-1" src="../connection/images/<?php  echo $row['img'];?>" ></a>
</div>
<center><h1>Welcome <?php echo "$name";?> </h1> </center>

  
    <nav>
       <ul>
		<li><a  href="home/index.php">Home</a></li>
		<li><a  href="organization_account2.php?id=<?php echo $id;?>">Profile</a></li>
        <li><a  href="blood_quanty_view.php?id=<?php echo $id?>">Blood Quantity View</a>
		<li><a  href="select_pending_Request.php?id=<?php echo $id?>">Pending Request</a> </li>
		<li><a  href="view_accpect_request.php?id=<?php echo $id?>">View Accepted Request</a></li>
	    <li><a  href="edit_organization.php?id=<?php echo $id?>">Edit Account</a> </li> 
	    <li><a  href="../index.php">Logout</a> </li> 
		</ul>
         
      </ul>
    </nav>
	
<article >
<center><form id="form_444844" class="appnitro"  method="POST" enctype="multipart/form-data" action="../connection/blood_insert.php";>

Blood Id:<br>
<input name="b_id" type="text" id="b_id" value="<?php echo $id?>" required>
<br>
<br>				
A+ Blood:<br>
<input name="aaa" type="number" id="aaa"   value="<?php echo $aaa?>" required>
<br>
<br>
A- Blood:<br>
<input name="a" type="number" id="a" value="<?php echo $a?>" required>
<br>
<br>
B+ Blood:<br>
<input name="bbb" type="number" id="bbb" value="<?php echo $bbb?>" required>
<br>
<br>
B- Blood:<br>
<input name="b" type="number" id="b" value="<?php echo $b?>"  >
<br>
<br>
O+ Blood:<br>
<input name="ooo" type="number" id="ooo"  value="<?php echo $ccc?>" required>
<br>
<br>
O- Blood:<br>
<input name="o" type="number" id="o" value="<?php echo $c?>" required>
<br>
<br>
AB+ Blood:<br>
<input name="aabb" type="number" id="aabb" value="<?php echo $aabb?>" required>
<br>
<br>
AB- Blood:<br>
<input name="ab" type="number" id="ab" value="<?php echo $ab?>" required>
<br>
<br>

<input type="submit" name="Submit" value="Submit">

</form></center>
             
</article >
 
</body>
</html>
	   


