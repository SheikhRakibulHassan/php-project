<?php
session_start();
$db_name="bloodbank";
$host_username="root";
$host_password="";
$host="localhost";

function filtertable($query){
	$connect= mysqli_connect("localhost","root","","bloodbank");
	$filter_result=mysqli_query($connect,$query);
	return $filter_result;
}


    $user_name2=$_GET['id'];
	$user_name=$_SESSION["id3"];
	
    $query="SELECT * FROM organization WHERE o_id='".$user_name."'";
	$search_result =filtertable($query);
    $row = mysqli_fetch_array($search_result);
	$id=$row['o_id'];
    $name=$row['o_name'];
	$pas=$row['password'];
	$em=$row['o_email'];
	$loc=$row['o_location'];
	$num=$row['o_number'];
	
   
  
   
   $query2="SELECT * FROM o_donner WHERE pe_id='".$user_name2."'";
   $search_result2 =filtertable($query2);
   $rec=mysqli_fetch_array($search_result2);
	 
	
   $person_id=$rec['pe_id'];
   $person_name=$rec['p_name'];
   $person_sex=$rec['sex'];
   $person_location=$rec['p_location'];
   $person_division=$rec['p_division'];
   $donation_date=$rec['p_date'];
   $person_number=$rec['p_number'];
   $blood_Group=$rec['p_b_group'];
   
?>
<!DOCTYPE>
<html>
<head>
<title>Blood Bank</title>
<link rel="icon" href="image/bicon.jpg" type="image/x-icon">
<link href="../css/style4.css" rel="stylesheet" type="text/css" />
</head>
<body>

<div class="header">
 <a href='login.php'><img ' class="img-1" src="../connection/images/<?php  echo $row['img'];?>" ></a>
</div>
<center><h1>Welcome <?php echo "$name";?> </h1> </center>

  
     <nav>
       <ul>
		<li><a  href="home/index.php">Home</a></li>
		<li><a  href="organization_account2.php?id=<?php echo $id;?>">Profile</a></li>
        <li><a  href="blood_quanty_view.php?id=<?php echo $id?>">Blood Quantity View</a>
		<li><a  href="select_pending_Request.php?id=<?php echo $id?>">Pending Request</a> </li>
		<li><a  href="view_accpect_request.php?id=<?php echo $id?>">View Accepted Request</a></li>
	    <li><a  href="edit_organization.php?id=<?php echo $id?>">Edit Account</a> </li> 
	    <li><a  href="../index.php">Logout</a> </li> 
		</ul>
         
      </ul>
    </nav>
	
<article >
<center><form id="form_444844" class="appnitro"  method="POST" action="../connection/request_reg_accpeted_ovaral.php";>
				
<h4>
Doner Id:<br>
<input name="doner_id" type="text" id="doner_id"  value="<?php echo $id;?>" readonly >
<br>
<br>
Doner Name:<br>
<input name="doner_name" type="text" id="doner_name" value="<?php echo $name;?>" readonly>
<br>
<br>
Persone Id:<br>
<input name="person_id" type="text" id="person_id" value="<?php echo $person_id;?>" readonly>
<br>
<br>
Persone Name:<br>
<input name="person_name" type="text" id="person_name" value="<?php echo $person_name;?>" readonly>
<br>
<br>
Donation Date:<br>
<input name="d_date" type="date" id="d_date" value="<?php echo $donation_date;?>" readonly>
<br>
<br>
Persone Gender:<br>
<input name="sex" type="text" id="sex" value="<?php echo $person_sex;?>" readonly>
<br>
<br>
Persone Contact Number:<br>
<input name="Contact" type="text" id="Contact" value="<?php echo $person_number;?>" readonly>
<br>
<br>
Donation Location:<br>
<input name="Location" type="text" id="Location" value="<?php echo "$person_location, $person_division.";?>" readonly>
<br>
<br>
Blood Group:<br>
<input name="b_group" type="text" id="b_group" value="<?php echo "$blood_Group";?>" readonly>
<br>
<br>
</h4>
<input type="submit" name="Submit" value="Submit">

</form></center>
            
  </article >
 
</body>
</html>
	   



