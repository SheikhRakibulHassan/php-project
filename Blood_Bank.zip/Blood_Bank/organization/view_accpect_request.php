<?php
$db_name="bloodbank";
$host_username="root";
$host_password="";
$host="localhost";

function filtertable($query){
	$connect= mysqli_connect("localhost","root","","bloodbank");
	$filter_result=mysqli_query($connect,$query);
	return $filter_result;
}


    $user_name=$_GET['id'];
	
    $query="SELECT * FROM organization WHERE o_id='".$user_name."'";
	$search_result =filtertable($query);
    $row = mysqli_fetch_array($search_result);
	$id=$row['o_id'];
    $name=$row['o_name'];
	$pas=$row['password'];
	$em=$row['o_email'];
	$loc=$row['o_location'];
	$num=$row['o_number'];
	
	
   $query="SELECT * FROM a_r_donner WHERE  r_id='".$id."'";
   $search_result =filtertable($query);
   
   $query1="SELECT * FROM a_r_donner WHERE r_id='".$id."'";
   $search_result1 =filtertable($query1);
   
   $query2="SELECT * FROM a_r_donner WHERE r_id='".$id."'";
   $search_result2 =filtertable($query2);
   
   $query3="SELECT * FROM a_r_donner WHERE r_id='".$id."'";
   $search_result3 =filtertable($query3);
   
   $query4="SELECT * FROM a_r_donner WHERE r_id='".$id."'";
   $search_result4 =filtertable($query4);
   
   $query5="SELECT * FROM a_r_donner WHERE r_id='".$id."'";
   $search_result5 =filtertable($query5);
   
   $query6="SELECT * FROM a_r_donner WHERE r_id='".$id."'";
   $search_result6 =filtertable($query6);
   
   $query7="SELECT * FROM a_r_donner WHERE r_id='".$id."'";
   $search_result7 =filtertable($query7);
	
   $query8="SELECT * FROM a_r_donner WHERE r_id='".$id."'";
   $search_result8 =filtertable($query8);
   
?>
<!DOCTYPE>
<html>
<head>
<title>Blood Bank</title>
<link rel="icon" href="image/bicon.jpg" type="image/x-icon">
<link href="../css/style5.css" rel="stylesheet" type="text/css" />
</head>
<body>

<div class="header">
 <a href='login.php'><img ' class="img-1" src="../connection/images/<?php  echo $row['img'];?>" ></a>
</div>
<center><h1>Welcome <?php echo "$name";?> </h1> </center>

  <nav>
       <ul>
		<li><a  href="home/index.php">Home</a></li>
		<li><a  href="organization_account2.php?id=<?php echo $id;?>">Profile</a></li>  
        <li><a  href="blood_quanty_view.php?id=<?php echo $id?>">Blood Quantity View</a>
		<li><a  href="select_pending_Request.php?id=<?php echo $id?>">Pending Request</a> </li>
		<li><a  href="view_accpect_request.php?id=<?php echo $id?>">View Accepted Request</a></li>
	    <li><a  href="edit_organization.php?id=<?php echo $id?>">Edit Account</a> </li> 
	    <li><a  href="../index.php">Logout</a> </li> 
		</ul>
         
      </ul>
    </nav>
	
<article >
<table>

<h2>Pending Request</h2>
<br>
<table>
<tr>
      
      <th>Organization Id</th>
	  <th>Organization Name</th>
	  <th>Accepted Id</th>
      <th>Accepted Name</th>
      <th>Donation Date</th>
	  <th>Accepted Gender</th>
	  <th>Accepted Number</th>
	  <th>Accepted Location</th>
	  <th>Blood Group</th>
      <th>Status</th>
	  <th>Donation Information</th>
	
     

</tr> 
<?php while($rec=mysqli_fetch_array($search_result)){ ?>
<tr> 
<td> <?php echo $rec['r_id'];?></td>
<td> <?php echo $rec['r_name'];?></td>
<td> <?php echo $rec['pe_id'];?></td>
<td> <?php echo $rec['pe_name'];?></td>
<td> <?php echo $rec['don_date'];?></td>
<td> <?php echo $rec['pe_sex'];?></td>
<td> <?php echo $rec['pe_number'];?></td>
<td> <?php echo $rec['don_location'];?></td>
<td> <?php echo $rec['b_group'];?></td>
<td> <?php if( "Accept" != $rec['status']){ echo "Pending";} else {echo "Accept";}?></td>
<td> <a href='donation_information.php?id=<?php echo $rec['pe_id']?>'>Submit</a></td>
</tr>
<?php }?>

</table ><br>
            
  </article >
 
</body>
</html>
	   



