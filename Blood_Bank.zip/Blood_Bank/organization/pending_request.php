  <?php
 session_start();
$db_name="bloodbank";
$host_username="root";
$host_password="";
$host="localhost";


function filtertable($query){
	$connect= mysqli_connect("localhost","root","","bloodbank");
	$filter_result=mysqli_query($connect,$query);
	return $filter_result;
}

    $user_name=$_SESSION["id3"];
	
    $query="SELECT * FROM organization WHERE o_id='".$user_name."'";
	$search_result =filtertable($query);
    $row = mysqli_fetch_array($search_result);
	$id=$row['o_id'];
    $name=$row['o_name'];
	$pas=$row['password'];
	$em=$row['o_email'];
	$loc=$row['o_location'];
	$num=$row['o_number'];
	
  if (isset($_POST['search'])){
	  
	
   $da=$_POST['did'];
	
   $query="SELECT * FROM o_donner WHERE p_b_group='".$da."'";
   $search_result =filtertable($query);
   
   $query1="SELECT * FROM o_donner WHERE p_b_group='".$da."' ";
   $search_result1 =filtertable($query1);
   
   $query2="SELECT * FROM o_donner WHERE p_b_group='".$da."'";
   $search_result2 =filtertable($query2);
   
   $query3="SELECT * FROM o_donner WHERE p_b_group='".$da."'";
   $search_result3 =filtertable($query3);
   
   $query4="SELECT * FROM o_donner WHERE p_b_group='".$da."'";
   $search_result4 =filtertable($query4);
   
   $query5="SELECT * FROM o_donner WHERE p_b_group='".$da."'";
   $search_result5 =filtertable($query5);
   
   $query6="SELECT * FROM o_donner WHERE p_b_group='".$da."'";
   $search_result6 =filtertable($query6);
   
   $query7="SELECT * FROM o_donner WHERE p_b_group='".$da."'";
   $search_result7 =filtertable($query7);
	
   $query8="SELECT * FROM o_donner WHERE p_b_group='".$da."'";
   $search_result8 =filtertable($query8);
   
   $query9="SELECT * FROM o_donner WHERE p_b_group='".$da."'";
   $search_result9 =filtertable($query9);
   
   $query10="SELECT * FROM o_donner WHERE p_b_group='".$da."'";
   $search_result10 =filtertable($query10);
	
   $query11="SELECT * FROM o_donner WHERE p_b_group='".$da."'";
   $search_result11 =filtertable($query11);
}

?>
 <!DOCTYPE>
<html>
<head>
<title>Blood Bank</title>
 <link rel="icon" href="image/bicon.jpg" type="image/x-icon">
<link href="../css/style3.css" rel="stylesheet" type="text/css" />
</head>
<body>

<div class="header">
 <a href='login.php'><img ' class="img-1" src="../connection/images/<?php  echo $row['img'];?>" ></a>
</div>

<center><h1>Welcome <?php echo "$name";?> </h1> </center>

 
      <nav>
       <ul>
		<li><a  href="home/index.php">Home</a></li>
		<li><a  href="organization_account2.php?id=<?php echo $id;?>">Profile</a></li>
        <li><a  href="blood_quanty_view.php?id=<?php echo $id?>">Blood Quantity View</a>
		<li><a  href="select_pending_Request.php?id=<?php echo $id?>">Pending Request</a> </li>
		<li><a  href="view_accpect_request.php?id=<?php echo $id?>">View Accepted Request</a></li>
	    <li><a  href="edit_organization.php?id=<?php echo $id?>">Edit Account</a> </li> 
	    <li><a  href="../index.php">Logout</a> </li> 
		</ul>
         
      </ul>
    </nav>



<article >	   
<table>
<tr>
      <td>Person Id:</td>
	  <?php while($rec=mysqli_fetch_array($search_result)){?>
      <td><?php echo $rec['pe_id'];?></td>
	  <?php }?>
</tr>

<tr>
      <td>Person Name:</td>
	  <?php while($rec=mysqli_fetch_array($search_result1)){?>
      <td><?php echo $rec['p_name'];?></td>
	  <?php }?>
</tr>

<tr>
      <td>Division:</td>
	  <?php while($rec=mysqli_fetch_array($search_result2)){ ?>
      <td><?php echo $rec['p_division'];?></td>
	  <?php }?>
</tr>

<tr>
      <td>Email:</td>
	  <?php while($rec=mysqli_fetch_array($search_result3)){?>
      <td><?php echo $rec['p_email'];?></td>
	  <?php }?>
</tr>
<tr>
      <td>Location:</td>
	  <?php while($rec=mysqli_fetch_array($search_result4)){?>
      <td><?php echo $rec['p_location'];?></td>
	  <?php }?>
</tr>
<tr>
      <td>Number:</td>
	  <?php while($rec=mysqli_fetch_array($search_result5)){?>
      <td><?php echo $rec['p_number'];?></td>
	  <?php }?>
</tr>
<tr>
      <td>Blood Group:</td>
	  <?php while($rec=mysqli_fetch_array($search_result6)){?>
      <td><?php echo $rec['p_b_group'];?></td>
	  <?php }?>
</tr>
<tr>
      <td>Request Date:</td>
	  <?php while($rec=mysqli_fetch_array($search_result7)){?>
      <td><?php echo $rec['p_date'];?></td>
	  <?php }?>
</tr>
<tr>
      <td>Age:</td>
	  <?php while($rec=mysqli_fetch_array($search_result8)){?>
      <td><?php echo $rec['age'];?></td>
	  <?php }?>
</tr>
<tr>
      <td>Sex:</td>
	  <?php while($rec=mysqli_fetch_array($search_result9)){?>
      <td><?php echo $rec['sex'];?></td>
	  <?php }?>
</tr>
<tr>
      <td>Want to Donate:</td>
	  <?php while($rec=mysqli_fetch_array($search_result10)){?>
      <td><a  href="accpect_pending_request.php?id=<?php echo $rec['pe_id']?>">Acepect</a></td>
	  <?php }?>
</tr>
</table ><br>
</article >
</body>
</html>