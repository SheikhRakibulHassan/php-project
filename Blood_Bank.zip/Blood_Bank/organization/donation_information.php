<?php
session_start();
$db_name="bloodbank";
$host_username="root";
$host_password="";
$host="localhost";

function filtertable($query){
	$connect= mysqli_connect("localhost","root","","bloodbank");
	$filter_result=mysqli_query($connect,$query);
	return $filter_result;
}


    $user_name=$_GET['id'];
	
	$query10="SELECT * FROM a_r_donner WHERE pe_id='".$user_name."'";
    $search_result10 =filtertable($query10);
    $roll = mysqli_fetch_array($search_result10);
	$doner_id=$roll['r_id'];
	$doner_name=$roll['r_name'];
	$persone_id=$roll['pe_id'];
	$persone_name=$roll['pe_name'];
	
$query="SELECT * FROM organization WHERE o_id='".$doner_id."'";
	$search_result =filtertable($query);
    $row = mysqli_fetch_array($search_result);
	$id=$row['o_id'];
    $name=$row['o_name'];
	$pas=$row['password'];
	$em=$row['o_email'];
	$loc=$row['o_location'];
	$num=$row['o_number'];
	
  
?>
<!DOCTYPE>
<html>
<head>
<title>Blood Bank</title>
<link rel="icon" href="image/bicon.jpg" type="image/x-icon">
<link href="../css/style4.css" rel="stylesheet" type="text/css" />
</head>
<body>

<div class="header">
 <a href='login.php'><img ' class="img-1" src="../connection/images/<?php  echo $row['img'];?>" ></a>
</div>
<center><h1>Welcome <?php echo "$name";?> </h1> </center>

   <nav>
       <ul>
		<li><a  href="home/index.php">Home</a></li>
		<li><a  href="organization_account2.php?id=<?php echo $id;?>">Profile</a></li>
        <li><a  href="blood_quanty_view.php?id=<?php echo $id?>">Blood Quantity View</a>
		<li><a  href="select_pending_Request.php?id=<?php echo $id?>">Pending Request</a> </li>
		<li><a  href="view_accpect_request.php?id=<?php echo $id?>">View Accepted Request</a></li>
	    <li><a  href="edit_organization.php?id=<?php echo $id?>">Edit Account</a> </li> 
	    <li><a  href="../index.php">Logout</a> </li> 
		</ul>
         
      </ul>
    </nav>
	
<article >
<center><form id="form_444844" class="appnitro"  method="POST" enctype="multipart/form-data" action="../connection/medical_insert2.php";>
				
Organization Name:<br>
<input name="name" type="text" id="name" value="<?php echo $doner_name ;?>" required>
<br>
<br>
Organization Id:<br>
<input name="d_id" type="text" id="d_id" value="<?php echo $doner_id ;?>" required>
<br>
<br>
Patient Name:<br>
<input name="p_name" type="text" id="p_name" value="<?php echo $persone_name ;?>" >
<br>
<br>
Patient Id:<br>
<input name="p_id" type="text" id="p_id" value="<?php echo $persone_id ;?>" required>
<br>
<br>
Medical Name:<br>
<input name="medical" type="text" id="medical"  required>
<br>
<br>
Doctor Name:<br>
<input name="doctor" type="text" id="doctor"   required>
<br>
<br>
Doctor Number:<br>
<input name="d_number" type="text" id="d_number"  pattern="\d{11}"  
       maxlength="11" required>
<br>
<br>
Doctor Email:<br>
<input name="d_email" type="email" id="d_email" required>
<br>
<br>
<input type="submit" name="Submit" value="Submit">

</form></center>
            
  </article >
 
</body>
</html>
	   



