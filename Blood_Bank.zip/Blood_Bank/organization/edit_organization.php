<?php
session_start();
$db_name="bloodbank";
$host_username="root";
$host_password="";
$host="localhost";

function filtertable($query){
	$connect= mysqli_connect("localhost","root","","bloodbank");
	$filter_result=mysqli_query($connect,$query);
	return $filter_result;
}


    $user_name=$_GET['id'];
	$_SESSION["id2"]= $user_name;
	
	$query="SELECT * FROM organization WHERE o_id='".$user_name."'";
	$search_result =filtertable($query);
    $row = mysqli_fetch_array($search_result);
	$id=$row['o_id'];
    $name=$row['o_name'];
	$pas=$row['password'];
	$em=$row['o_email'];
	$loc=$row['o_location'];
	$num=$row['o_number'];
	
	
 
   
?>
<!DOCTYPE>
<html>
<head>
<title>Blood Bank</title>
<link rel="icon" href="image/bicon.jpg" type="image/x-icon">
<link href="../css/style4.css" rel="stylesheet" type="text/css" />
</head>
<body>
<div class="header">
 <a href='login.php'><img ' class="img-1" src="../connection/images/<?php  echo $row['img'];?>" ></a>
</div>
<center><h1>Welcome <?php echo "$name";?> </h1> </center>

 <nav>
       <ul>
		<li><a  href="home/index.php">Home</a></li>
		<li><a  href="organization_account2.php?id=<?php echo $id;?>">Profile</a></li>
        <li><a  href="blood_quanty_view.php?id=<?php echo $id?>">Blood Quantity View</a>
		<li><a  href="select_pending_Request.php?id=<?php echo $id?>">Pending Request</a> </li>
		<li><a  href="view_accpect_request.php?id=<?php echo $id?>">View Accepted Request</a></li>
	    <li><a  href="edit_organization.php?id=<?php echo $id?>">Edit Account</a> </li> 
	    <li><a  href="../index.php">Logout</a> </li> 
		</ul>
         
      </ul>
    </nav>
	
<article >
<center><form id="form_444844" class="appnitro"  method="POST" enctype="multipart/form-data" action="../connection/update_organization.php";>
				
Organization Id:<br>
<input name="o_id" type="text" id="o_id" value="<?php echo $id ?>" required>
<br>
<br>
Organization Name:<br>
<input name="o_name" type="text" id="o_name" value="<?php echo $name ?>" required>
<br>
<br>
Organization Email:<br>
<input name="o_email" type="text" id="o_email" value="<?php echo $em ?>" required>
<br>
<br>
Oganization Number:<br>
<input name="o_number" type="number" id="o_number" value="<?php echo $num ?>" required>
<br>
<br>
Oganization Location:<br>
<input name="o_location" type="text" id="o_location" value="<?php echo $loc ?>" required>
<br>
<br>

<input type="submit" name="Submit" value="Submit">

</form></center>
            
  </article >
 
</body>
</html>
	   



