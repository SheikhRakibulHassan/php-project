  <?php
 
$db_name="bloodbank";
$host_username="root";
$host_password="";
$host="localhost";

   $user_name=$_GET['id'];
	
	$query="SELECT * FROM organization WHERE o_id='".$user_name."'";
	$search_result =filtertable($query);
    $row = mysqli_fetch_array($search_result);
	$id=$row['o_id'];
    $name=$row['o_name'];
	$pas=$row['password'];
	$em=$row['o_email'];
	$loc=$row['o_location'];
	$num=$row['o_number'];
	
	$query="SELECT * FROM `blood_quantity`WHERE b_id='".$user_name."' ";
    $search_result =filtertable($query);

function filtertable($query){
	$connect= mysqli_connect("localhost","root","","bloodbank");
	$filter_result=mysqli_query($connect,$query);
	return $filter_result;
}




?>
 <!DOCTYPE>
<html>
<head>
<title>Blood Bank</title>
 <link rel="icon" href="image/bicon.jpg" type="image/x-icon">
<link href="../css/style5.css" rel="stylesheet" type="text/css" />
</head>
<body>

<div class="header">
 <a href='login.php'><img ' class="img-1" src="../connection/images/<?php  echo $row['img'];?>" ></a>
</div>

<center><h1>Welcome <?php echo "$name";?> </h1> </center>

 
    
     <nav>
       <ul>
		<li><a  href="home/index.php">Home</a></li>
		<li><a  href="organization_account2.php?id=<?php echo $id;?>">Profile</a></li>
        <li><a  href="blood_quanty_view.php?id=<?php echo $id?>">Blood Quantity View</a>
		<li><a  href="select_pending_Request.php?id=<?php echo $id?>">Pending Request</a> </li>
		<li><a  href="view_accpect_request.php?id=<?php echo $id?>">View Accepted Request</a></li>
	    <li><a  href="edit_organization.php?id=<?php echo $id?>">Edit Account</a> </li> 
	    <li><a  href="../index.php">Logout</a> </li> 
		</ul>
         
      </ul>
    </nav>




<article >	   
<center>
<h2>Donetion List</h2><br>
<table>
<tr>
      
      <th>Organization Id</th>
	  <th>A+ Blood</th>
	  <th>A- Blood</th>
      <th>B+ Blood</th>
      <th>B- Blood</th>
	  <th>O+ Blood</th>
	  <th>O- Blood</th>
	  <th>AB+ Blood</th>
	  <th>AB- Blood</th>
	  <th>Update</th>
</tr> 
<?php while($row=mysqli_fetch_array($search_result)){?>
<tr> 
<td> <?php echo $row['b_id'];?></td>
<td> <?php echo $row['aaa'];?></td>
<td> <?php echo $row['a'];?></td>
<td> <?php echo $row['bbb'];?></td>
<td> <?php echo $row['b'];?></td>
<td> <?php echo $row['ooo'];?></td>
<td> <?php echo $row['o'];?></td>
<td> <?php echo $row['aabb'];?></td>
<td> <?php echo $row['ab'];?></td>
<td><a href='blood_quanty.php?id=<?php echo $user_name;?> '>Edit</a></td>
</tr>
<?php }?>
</table></center>
</article >
</body>
</html>